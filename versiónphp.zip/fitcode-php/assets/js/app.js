(() => {
  'use strict';
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const BASE = $('meta[name="fc-base"]')?.content || '';
  const TOKEN = $('meta[name="fc-token"]')?.content || '';

  $$('.toast').forEach((t, i) => {
    const close = () => { t.style.opacity = '0'; t.style.transform = 'translateY(-6px)'; t.style.transition = '.25s'; setTimeout(() => t.remove(), 260); };
    $('.toast-x', t)?.addEventListener('click', close);
    setTimeout(close, 6000 + i * 600);
  });

  $$('input.upper, textarea.upper').forEach(el => {
    el.addEventListener('input', () => {
      const s = el.selectionStart, e = el.selectionEnd;
      const v = el.value.toLocaleUpperCase('es-MX').replace(/[^A-ZÁÉÍÓÚÜÑ\s'.-]/g, '');
      if (v !== el.value) { el.value = v; try { el.setSelectionRange(s, e); } catch (_) {} }
    });
  });

  $$('[data-digits]').forEach(el => el.addEventListener('input', () => {
    el.value = el.value.replace(/\D/g, '').slice(0, +el.dataset.digits || 99);
  }));

  $$('[data-date]').forEach(el => {
    const ageEl = el.dataset.ageFor ? document.getElementById(el.dataset.ageFor) : null;
    const tipo = el.dataset.tipo;
    const hint = el.closest('.field')?.querySelector('.hint');
    const original = hint?.textContent;
    el.addEventListener('input', () => {
      let d = el.value.replace(/\D/g, '').slice(0, 8);
      if (d.length > 4) d = d.slice(0, 2) + '/' + d.slice(2, 4) + '/' + d.slice(4);
      else if (d.length > 2) d = d.slice(0, 2) + '/' + d.slice(2);
      el.value = d;
      el.classList.remove('invalid', 'valid');
      if (hint) { hint.textContent = original; hint.classList.remove('err'); }
      const m = d.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
      if (!m) { if (ageEl) ageEl.value = ''; return; }
      const [_, dd, mm, yy] = m.map(Number);
      const dt = new Date(yy, mm - 1, dd);
      const now = new Date();
      if (dt.getDate() !== dd || dt.getMonth() !== mm - 1 || dt > now || yy < 1900) {
        el.classList.add('invalid');
        if (hint) { hint.textContent = 'Fecha no válida.'; hint.classList.add('err'); }
        if (ageEl) ageEl.value = '';
        return;
      }
      let age = now.getFullYear() - yy;
      if (now.getMonth() < mm - 1 || (now.getMonth() === mm - 1 && now.getDate() < dd)) age--;
      if (ageEl) ageEl.value = age;
      const fueraDeRango = (tipo === 'MAYOR' && age < 18) || (tipo === 'MENOR' && age >= 18);
      el.classList.add(fueraDeRango ? 'invalid' : 'valid');
      if (fueraDeRango && hint) {
        hint.textContent = tipo === 'MAYOR' ? 'La edad indica que eres menor de edad: regresa y elige “Menor de edad”.' : 'La edad indica mayoría de edad: regresa y elige “Mayor de edad”.';
        hint.classList.add('err');
      }
    });
    if (el.value) el.dispatchEvent(new Event('input'));
  });

  $$('.otp').forEach(box => {
    const cells = $$('input', box);
    const hidden = document.getElementById(box.dataset.target);
    const btn = box.closest('form')?.querySelector('[type=submit]');
    const sync = () => {
      const v = cells.map(c => c.value).join('');
      if (hidden) hidden.value = v;
      cells.forEach(c => c.classList.toggle('filled', !!c.value));
      if (btn) btn.disabled = v.length !== 6;
    };
    cells.forEach((c, i) => {
      c.addEventListener('input', () => {
        c.value = c.value.replace(/\D/g, '').slice(-1);
        if (c.value && cells[i + 1]) cells[i + 1].focus();
        sync();
      });
      c.addEventListener('keydown', ev => {
        if (ev.key === 'Backspace' && !c.value && cells[i - 1]) { cells[i - 1].focus(); cells[i - 1].value = ''; sync(); }
        if (ev.key === 'ArrowLeft' && cells[i - 1]) cells[i - 1].focus();
        if (ev.key === 'ArrowRight' && cells[i + 1]) cells[i + 1].focus();
      });
      c.addEventListener('paste', ev => {
        const d = (ev.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6);
        if (!d) return;
        ev.preventDefault();
        d.split('').forEach((ch, j) => { if (cells[j]) cells[j].value = ch; });
        (cells[d.length] || cells[5]).focus();
        sync();
      });
    });
    sync();
    if (box.classList.contains('shake')) setTimeout(() => box.classList.remove('shake'), 500);
  });

  $$('.drop').forEach(drop => {
    const input = $('input[type=file]', drop);
    const title = $('strong', drop), sub = $('small', drop);
    const t0 = title.textContent, s0 = sub.textContent;
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, () => drop.classList.add('over')));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, () => drop.classList.remove('over')));
    input.addEventListener('change', () => {
      $('.drop-thumb', drop)?.remove();
      const f = input.files[0];
      if (!f) { drop.classList.remove('has-file'); title.textContent = t0; sub.textContent = s0; return; }
      if (f.size > 5 * 1024 * 1024) { alert('El archivo supera los 5 MB.'); input.value = ''; return input.dispatchEvent(new Event('change')); }
      drop.classList.add('has-file');
      title.textContent = f.name;
      sub.textContent = (f.size / 1024).toFixed(0) + ' KB · listo';
      if (f.type.startsWith('image/')) {
        const img = document.createElement('img');
        img.className = 'drop-thumb'; img.alt = '';
        img.src = URL.createObjectURL(f);
        drop.appendChild(img);
      }
    });
  });

  $$('[data-toggle-when]').forEach(sel => {
    const run = () => {
      const v = sel.value;
      $$(`[data-show-if="${sel.id}"]`).forEach(box => {
        const vals = box.dataset.values ? box.dataset.values.split('|') : null;
        const on = vals ? vals.includes(v) : (v && v !== sel.dataset.toggleWhen);
        box.classList.toggle('hidden', !on);
        $$('input, select, textarea', box).forEach(i => { if (i.dataset.req !== undefined) i.required = on; });
      });
    };
    sel.addEventListener('change', run); run();
  });

  $$('[data-signature]').forEach(wrap => {
    const canvas = $('canvas', wrap), out = $('input[type=hidden]', wrap);
    const ctx = canvas.getContext('2d');
    let drawing = false, dirty = false, last = null;
    const fit = () => {
      const r = canvas.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
      const prev = dirty ? canvas.toDataURL() : null;
      canvas.width = r.width * dpr; canvas.height = r.height * dpr;
      ctx.scale(dpr, dpr);
      ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#c8ff2e';
      if (prev) { const im = new Image(); im.onload = () => ctx.drawImage(im, 0, 0, r.width, r.height); im.src = prev; }
    };
    const pos = ev => { const r = canvas.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
    canvas.addEventListener('pointerdown', ev => { drawing = true; last = pos(ev); canvas.setPointerCapture(ev.pointerId); });
    canvas.addEventListener('pointermove', ev => {
      if (!drawing) return;
      const p = pos(ev);
      ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.lineTo(p.x, p.y); ctx.stroke();
      last = p; dirty = true;
    });
    const end = () => {
      if (!drawing) return; drawing = false;
      if (!dirty) return;
      const tmp = document.createElement('canvas'); tmp.width = canvas.width; tmp.height = canvas.height;
      const t = tmp.getContext('2d'); t.drawImage(canvas, 0, 0);
      t.globalCompositeOperation = 'source-in'; t.fillStyle = '#0b0e14'; t.fillRect(0, 0, tmp.width, tmp.height);
      out.value = tmp.toDataURL('image/png');
      wrap.classList.add('signed');
      $('[data-sig-status]', wrap).textContent = 'Firma capturada ✓';
    };
    canvas.addEventListener('pointerup', end); canvas.addEventListener('pointerleave', end);
    $('[data-sig-clear]', wrap)?.addEventListener('click', () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height); dirty = false; out.value = '';
      $('[data-sig-status]', wrap).textContent = 'Firma dentro del recuadro';
    });
    const tabs = $$('.sig-tabs button', wrap);
    tabs.forEach(b => b.addEventListener('click', () => {
      tabs.forEach(x => x.classList.toggle('on', x === b));
      $$('[data-sig-pane]', wrap).forEach(p => p.classList.toggle('hidden', p.dataset.sigPane !== b.dataset.pane));
      if (b.dataset.pane === 'draw') requestAnimationFrame(fit);
    }));
    fit(); window.addEventListener('resize', fit);
  });

  $$('[data-password]').forEach(input => {
    const meter = $(input.dataset.password + ' .pw-meter i');
    const rules = $$(input.dataset.password + ' [data-rule]');
    const tests = {
      len: v => v.length >= 8, lower: v => /[a-z]/.test(v), upper: v => /[A-Z]/.test(v),
      num: v => /\d/.test(v), sym: v => /[^a-zA-Z0-9]/.test(v),
    };
    input.addEventListener('input', () => {
      const v = input.value; let ok = 0;
      rules.forEach(li => { const pass = tests[li.dataset.rule](v); li.classList.toggle('ok', pass); ok += pass; });
      const pct = (ok / 5) * 100 + (v.length >= 12 && ok === 5 ? 0 : 0);
      if (meter) { meter.style.width = pct + '%'; meter.style.background = ok < 3 ? 'var(--bad)' : ok < 5 ? 'var(--warn)' : 'var(--accent)'; }
    });
  });
  $$('[data-match]').forEach(c => {
    const other = document.getElementById(c.dataset.match);
    const hint = c.closest('.field')?.querySelector('.hint');
    const run = () => {
      if (!c.value) { c.classList.remove('invalid', 'valid'); if (hint) hint.textContent = ''; return; }
      const ok = c.value === other.value;
      c.classList.toggle('invalid', !ok); c.classList.toggle('valid', ok);
      if (hint) { hint.textContent = ok ? 'Las contraseñas coinciden.' : 'No coinciden.'; hint.classList.toggle('err', !ok); }
    };
    c.addEventListener('input', run); other.addEventListener('input', run);
  });
  $$('.peek').forEach(b => b.addEventListener('click', () => {
    const i = b.parentElement.querySelector('input');
    i.type = i.type === 'password' ? 'text' : 'password';
    b.setAttribute('aria-pressed', i.type === 'text');
  }));

  $$('[data-clock]').forEach(el => setInterval(() => {
    el.textContent = new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });
  }, 15000));

  $$('.ring[data-pct]').forEach(r => {
    const bar = $('.bar', r), len = 2 * Math.PI * 70;
    bar.style.strokeDasharray = len; bar.style.strokeDashoffset = len;
    requestAnimationFrame(() => setTimeout(() => { bar.style.strokeDashoffset = len * (1 - r.dataset.pct / 100); }, 120));
  });

  $$('form').forEach(f => f.addEventListener('submit', () => {
    const b = f.querySelector('[type=submit]');
    if (b && f.checkValidity()) setTimeout(() => { b.disabled = true; b.dataset.busy = '1'; }, 0);
  }));

  const auto = $('[data-autorefresh]');
  if (auto) setTimeout(() => location.reload(), (+auto.dataset.autorefresh || 15) * 1000);

  $$('form').forEach(f => {
    const p = $('[name=peso]', f), e = $('[name=estatura]', f), out = $('[data-imc-out]', f), cat = $('[data-imc-cat]', f);
    if (!p || !e || !out) return;
    const edad = +(f.dataset.edad || 30);
    const run = () => {
      const pe = parseFloat(p.value), es = parseFloat(e.value) / 100;
      if (!(pe > 0 && es > 0)) { out.textContent = '—'; if (cat) cat.textContent = ''; return; }
      const v = Math.round(pe / (es * es) * 10) / 10;
      out.textContent = v;
      if (cat) cat.textContent = edad < 18 ? 'Menor de edad: se interpreta con percentiles OMS' : v < 18.5 ? 'Bajo peso' : v < 25 ? 'Peso normal' : v < 30 ? 'Sobrepeso' : 'Obesidad';
    };
    p.addEventListener('input', run); e.addEventListener('input', run); run();
  });

  const ccNum = $('#cc-num');
  if (ccNum) {
    const brand = $('#cc-brand'), cvv = $('#cc-cvv'), exp = $('#cc-exp');
    const marca = n => /^4/.test(n) ? 'VISA' : /^(5[1-5]|2[2-7])/.test(n) ? 'MASTERCARD' : /^3[47]/.test(n) ? 'AMEX' : null;
    ccNum.addEventListener('input', () => { const d = ccNum.value.replace(/\D/g, '').slice(0, 16); ccNum.value = d.replace(/(.{4})/g, '$1 ').trim(); const b = marca(d); brand.textContent = b || 'TARJETA'; brand.classList.toggle('on', !!b); cvv.maxLength = b === 'AMEX' ? 4 : 3; });
    exp.addEventListener('input', () => { let d = exp.value.replace(/\D/g, '').slice(0, 4); if (d.length > 2) d = d.slice(0, 2) + '/' + d.slice(2); exp.value = d; });
    cvv.addEventListener('input', () => { cvv.value = cvv.value.replace(/\D/g, ''); });
  }
  $$('form[data-processing]').forEach(f => f.addEventListener('submit', () => { const o = $('#processing'); if (o) o.classList.remove('hidden'); }));

  $$('[data-confirm]').forEach(el => el.addEventListener('submit', ev => { if (!confirm(el.dataset.confirm)) ev.preventDefault(); }));

  $$('a[data-newtab]').forEach(a => a.target = '_blank');

  $$('input[data-live-search]').forEach(i => { let t; i.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => i.form.submit(), 450); }); const v = i.value; i.focus(); i.setSelectionRange(v.length, v.length); });

  const scan = $('[data-scan]');
  if (scan) { scan.focus(); document.addEventListener('keydown', ev => { if (document.activeElement === document.body && /^[a-z0-9]$/i.test(ev.key)) scan.focus(); }); }
})();
