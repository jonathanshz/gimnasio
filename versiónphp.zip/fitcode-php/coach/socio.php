<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$st = requiere_staff(['instructor']);
$id = (int)($_GET['id'] ?? 0);
$s = Socios::porId($id) ?? redirect('coach/index.php');
$uid = (int)$st['usuario_id'];
$base = "coach/socio.php?id=$id";

if (es_post()) {
    csrf_verificar();
    $acc = $_POST['accion'] ?? '';
    if ($acc === 'perfil') {
        if ($e = guardar_perfil($id, $_POST, $uid)) { flash('error', $e); redirect("$base&tab=objetivo"); }
        flash('ok', 'Objetivo guardado. Revisa la rutina sugerida y asígnala.'); redirect("$base&tab=rutina");
    }
    if ($acc === 'medicion') {
        if ($e = validar_medicion($_POST)) flash('error', $e);
        else { $r = Mediciones::registrar($id, $_POST, $uid); flash('ok', 'Medición registrada. IMC: ' . num($r['imc']) . '.'); }
        redirect($base);
    }
    if ($acc === 'asignar' && ($F = datos_fitness($s))) {
        Rutinas::asignar_plan($id, generar_plan($F), $st);
        flash('ok', 'Rutina asignada. El socio ya la ve en su portal.'); redirect("$base&tab=rutina");
    }
    if ($acc === 'finalizar') {
        $a = Rutinas::asignada($id);
        if ($a && (int)$a['id'] === (int)($_POST['rutina_id'] ?? 0)) { Rutinas::finalizar((int)$a['id']); flash('ok', 'Rutina finalizada.'); }
        redirect("$base&tab=rutina");
    }
    redirect($base);
}

$F = datos_fitness($s);
$TABS = ['progreso' => 'Progreso e IMC', 'rutina' => 'Rutina', 'nutricion' => 'Nutrición sugerida', 'objetivo' => 'Objetivo'];
$tab = isset($TABS[$_GET['tab'] ?? '']) ? $_GET['tab'] : 'progreso';
if (!$F) $tab = 'objetivo';
staff_inicio('Ficha de entrenamiento', 'coach', $st); ?>
<a class="btn btn-ghost btn-sm" href="<?= url('coach/index.php') ?>" style="margin-bottom:16px"><?= icon('back', 16) ?> Mis socios</a>
<section class="card corners rise" style="margin-bottom:18px"><div class="row row-between" style="gap:16px;flex-wrap:wrap">
  <div class="person"><span class="avatar" style="width:50px;height:50px"><?= e(mb_substr($s['nombre'], 0, 1) . mb_substr($s['apellido_paterno'], 0, 1)) ?></span>
    <div><h2 class="title" style="font-size:22px;margin:0"><?= e($s['nombre_completo']) ?></h2><small class="mono"><?= e($s['usuario']) ?> · <?= $s['edad'] ?> años · <?= e($s['sexo']) ?></small></div></div>
  <?php if ($s['enfermedad_cronica'] !== 'NINGUNA'): ?><?= alerta('warn', 'alert', 'Condición médica: <strong>' . e($s['enfermedad_cronica'] === 'OTRA' ? $s['enfermedad_otra'] : (CAT_ENF[$s['enfermedad_cronica']] ?? $s['enfermedad_cronica'])) . '</strong>. Ajusta intensidad.', ' style="margin:0"') ?><?php endif; ?>
</div></section>
<?php
echo '<nav class="tabs">'; foreach ($TABS as $k => $n) echo '<a class="' . ($k === $tab ? 'on' : '') . '" href="' . url("$base&tab=$k") . '">' . $n . '</a>'; echo '</nav>';
$hid = '';
if ($tab === 'objetivo') {
    $meds = Mediciones::porSocio($id);
    echo onboarding_html(Expedientes::obtener($id), end($meds) ?: null, (int)$s['edad'], 'perfil', $hid, $F ? 'Ajustar objetivo del socio' : 'El socio aún no define objetivo');
} elseif ($tab === 'progreso') {
    echo progreso_html($F, (int)$s['edad'], 'medicion', $hid);
} elseif ($tab === 'rutina') {
    $a = Rutinas::asignada($id);
    if ($a) echo rutina_asignada_html($a) . '<form method="post" style="margin:-6px 0 18px" data-confirm="¿Finalizar la rutina actual?">' . csrf_field() . '<input type="hidden" name="accion" value="finalizar"><input type="hidden" name="rutina_id" value="' . $a['id'] . '"><button class="btn btn-sm">' . icon('check', 14) . ' Finalizar rutina actual</button></form>';
    $boton = '<form method="post">' . csrf_field() . '<input type="hidden" name="accion" value="asignar"><button class="btn btn-primary btn-sm">' . icon('check', 16) . ($a ? ' Reemplazar por esta' : ' Asignar al socio') . '</button></form>';
    echo plan_html(generar_plan($F), $boton);
} else {
    echo nutricion_html(plan_nutricional($F));
}
shell_fin();
