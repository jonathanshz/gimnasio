<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$st = requiere_staff(['instructor']);
$q = trim($_GET['q'] ?? '');
$sinRutina = 0; foreach (Socios::buscar('') as $s) if (!Rutinas::asignada((int)$s['id'])) $sinRutina++;
staff_inicio('Mis socios', 'coach', $st); ?>
<div class="grid g-3" style="margin-bottom:22px">
  <div class="card kpi rise"><span class="label">Socios</span><strong><?= count(Socios::buscar('')) ?></strong></div>
  <div class="card kpi rise rise-2"><span class="label">Sin rutina asignada</span><strong style="color:<?= $sinRutina ? 'var(--warn)' : 'inherit' ?>"><?= $sinRutina ?></strong></div>
  <div class="card kpi rise rise-3"><span class="label">En el gimnasio ahora</span><strong><?= Asistencias::kpisHoy()['dentro'] ?></strong></div>
</div>
<?= lista_socios_html($q, 'coach/socio.php', true) ?>
<p class="hint" style="margin-top:16px">Abre la ficha de un socio para registrar mediciones, ajustar su objetivo y asignarle la rutina semanal sugerida.</p>
<?php shell_fin();
