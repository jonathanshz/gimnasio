<?php
require __DIR__ . '/includes/bootstrap.php';
if (socio_actual()) redirect('portal/inicio.php');

$error = null; $id = '';
$nuevo = $_SESSION['nuevo_usuario'] ?? null; unset($_SESSION['nuevo_usuario']);
if (es_post()) {
    csrf_verificar();
    $id = trim($_POST['identificador'] ?? ''); $pw = (string)($_POST['password'] ?? '');
    if ($id === '' || $pw === '') $error = 'Escribe tu usuario, correo o número y tu contraseña.';
    else {
        $r = Socios::login($id, $pw);
        if ($r['ok']) { flash('ok', "Bienvenid@, {$r['socio']['nombre']}. Tu código de acceso está listo."); redirect('portal/inicio.php'); }
        if (!empty($r['sin_verificar'])) {
            $_SESSION['verif'] = ['tipo' => 'socio', 'id' => (int)$r['socio']['id'], 'usuario' => $r['socio']['usuario']];
            flash('error', 'Antes de entrar, verifica tu correo.'); redirect('verificar.php');
        }
        $error = $r['error'];
    }
}
$k = Asistencias::kpisHoy();
$libres = count(array_filter(Equipos::listar(), fn($m) => $m['disponibilidad'] === 'LIBRE'));
$activos = (int)qv("SELECT COUNT(DISTINCT socio_id) FROM membresias WHERE estado = 'activa' AND fecha_inicio <= ? AND fecha_fin >= ?", [hoy(), hoy()]);

layout_inicio('Bienvenida'); ?>
<div class="welcome">
  <section class="hero">
    <div class="hero-scan" aria-hidden="true"></div><div class="hero-ring" aria-hidden="true"></div>
    <div class="hero-top rise"><?= logo() ?><span class="chip mono"><span class="dot dot-live"></span>ABIERTO · 05:00 — 23:00</span></div>
    <div>
      <p class="kicker rise rise-2">Bienvenid@ a</p>
      <h1 class="hero-title rise rise-2" aria-label="FIT CODE"><span>FIT</span><span class="outline">CODE<span class="lime" aria-hidden="true"></span></span></h1>
      <p class="hero-sub rise rise-3">Tu entrenamiento, tu acceso y tu progreso en un solo código. Entra, escanea y entrena.</p>
      <div class="hero-stats rise rise-4"><div><strong class="mono"><?= $activos ?></strong><small>Socios activos</small></div><div><strong class="mono"><?= $libres ?></strong><small>Máquinas libres ahora</small></div><div><strong class="mono"><?= $k['dentro'] ?></strong><small>Entrenando ahora</small></div></div>
    </div>
    <p class="dim mono" style="font-size:11px;letter-spacing:.1em;margin:40px 0 0">FIT CODE © <?= date('Y') ?> · ACCESO DIGITAL</p>
  </section>
  <section class="auth-side"><div class="panel rise rise-3">
    <p class="kicker">Socios</p><h2 class="title">Inicia sesión</h2><p class="lead">Usa tu usuario, correo o número de teléfono.</p>
    <?php if ($nuevo): ?><div class="user-reveal corners"><span class="label">Correo verificado · tu usuario es</span><span class="mono"><?= e($nuevo) ?></span></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-bad" role="alert" style="margin-bottom:18px"><?= icon('alert', 18) ?><span><?= e($error) ?></span></div><?php endif; ?>
    <form method="post" class="form" novalidate><?= csrf_field() ?>
      <div class="field"><label for="identificador">Usuario, correo o número</label>
        <div class="input-wrap"><?= icon('user', 18) ?><input class="input" id="identificador" name="identificador" value="<?= e($id ?: $nuevo) ?>" autocomplete="username" placeholder="ANAPP-150398 · ana@correo.mx · 5512345678" <?= $nuevo ? '' : 'autofocus' ?>></div></div>
      <div class="field"><label for="password">Contraseña</label>
        <div class="input-wrap"><?= icon('lock', 18) ?><input class="input" type="password" id="password" name="password" autocomplete="current-password" placeholder="••••••••" <?= $nuevo ? 'autofocus' : '' ?>><button type="button" class="peek" aria-label="Mostrar contraseña"><?= icon('eye', 18) ?></button></div></div>
      <button class="btn btn-primary btn-block" type="submit">Entrar <?= icon('arrow', 18) ?></button>
    </form>
    <div class="divider" style="margin:26px 0 18px">¿Primera vez?</div>
    <a href="<?= url('registro/codigo.php') ?>" class="btn btn-ghost btn-block"><?= icon('key', 18) ?> Registrarme con mi código de recepción</a>
    <p class="hint" style="text-align:center;margin-top:14px">El código de 6 dígitos se entrega únicamente en la recepción del gimnasio.</p>
    <p class="hint" style="text-align:center;margin-top:30px"><a class="link" href="<?= url('personal/index.php') ?>">Acceso para personal (recepción, coaches y administración)</a></p>
    <?= demo_box('Socia activa: <span class="mono">ANAPP-150398</span> · <span class="mono">Socio#2026</span><br>Por vencer: <span class="mono">LUISRM-020901</span> · Vencida (menor): <span class="mono">SOFIAHL-110510</span>') ?>
  </div></section>
</div>
<?php layout_fin();
