<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
require ROOT_PATH . '/includes/registro.php';
$r = reg_requiere('tipo', 'datos_ok');
$d = $r['datos'];
$usuario = Socios::generarUsuario($d['nombre'], $d['apellido_paterno'], $d['apellido_materno'], $d['fecha_iso']);
$E = []; $email = ''; $tel = $d['tel_contacto'];

if (es_post()) {
    csrf_verificar();
    $email = mb_strtolower(trim($_POST['email'] ?? '')); $tel = preg_replace('/\D/', '', $_POST['telefono'] ?? ''); $pw = (string)($_POST['password'] ?? '');
    if (!validar_email($email)) $E['email'] = 'Escribe un correo válido.'; elseif (Socios::existeEmail($email)) $E['email'] = 'Ese correo ya está registrado.';
    if (!preg_match('/^\d{10}$/', $tel)) $E['telefono'] = 'El número debe tener 10 dígitos.'; elseif (Socios::existeTelefono($tel)) $E['telefono'] = 'Ese número ya está registrado.';
    if ($f = validar_password($pw)) $E['password'] = 'La contraseña necesita: ' . implode(', ', $f) . '.';
    elseif ($pw !== ($_POST['password2'] ?? '')) $E['password2'] = 'Las contraseñas no coinciden.';
    elseif (stripos($pw, explode('-', $usuario)[0]) !== false) $E['password'] = 'No uses tu nombre de usuario dentro de la contraseña.';
    if (!$E) {
        $s = Socios::crear($d + ['usuario' => $usuario, 'email' => $email, 'telefono' => $tel, 'tipo' => $r['tipo'], 'password' => $pw], $r['docs'] ?? [], (int)$r['codigo_id']);
        unset($_SESSION['reg']);
        $_SESSION['verif'] = ['tipo' => 'socio', 'id' => (int)$s['id'], 'usuario' => $s['usuario'], 'registro' => true];
        redirect('verificar.php');
    }
}
layout_inicio('Crea tu cuenta'); ?>
<div class="reg-page"><?php reg_cabecera(4); ?><div class="reg-body"><div class="panel rise" style="max-width:520px">
  <p class="kicker">Paso 4 de 5</p><h2 class="title">Crea tu cuenta</h2><p class="lead">Generamos tu usuario con tu nombre y fecha de nacimiento. Completa tus datos de acceso.</p>
  <div class="user-reveal corners"><span class="label">Tu usuario asignado</span><span class="mono"><?= e($usuario) ?></span><p class="hint" style="margin:10px 0 0">Nombre + iniciales de apellidos + fecha (DDMMAA). También podrás entrar con tu correo o número.</p></div>
  <form method="post" class="form" novalidate><?= csrf_field() ?>
    <div class="field"><label for="email">Correo electrónico <span class="req">*</span></label><div class="input-wrap"><?= icon('file', 18) ?><input class="input" type="email" id="email" name="email" value="<?= e($email) ?>" autocomplete="email" placeholder="tucorreo@ejemplo.com"></div><?= err($E, 'email') ?><p class="hint">Te enviaremos un código para verificarlo.</p></div>
    <div class="field"><label for="tel">Número de teléfono <span class="req">*</span></label><div class="input-wrap"><?= icon('user', 18) ?><input class="input mono" id="tel" name="telefono" value="<?= e($tel) ?>" inputmode="tel" data-digits="10"></div><?= err($E, 'telefono') ?></div>
    <?= campo_password() . err($E, 'password') ?>
    <div class="field"><label for="pw2">Confirmar contraseña <span class="req">*</span></label><div class="input-wrap"><?= icon('lock', 18) ?><input class="input" type="password" id="pw2" name="password2" autocomplete="new-password" data-match="pw"></div><p class="hint"></p><?= err($E, 'password2') ?></div>
    <button class="btn btn-primary btn-block" type="submit"><?= icon('check', 18) ?> Crear cuenta y verificar correo</button>
  </form>
</div></div></div>
<?php layout_fin();
