<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
require ROOT_PATH . '/includes/registro.php';
if (socio_actual()) redirect('portal/inicio.php');

$err = null;
if (es_post()) {
    csrf_verificar();
    $r = Codigos::validar(preg_replace('/\s/', '', $_POST['codigo'] ?? ''));
    if ($r['ok']) {
        $_SESSION['reg'] = ['codigo_id' => $r['id'], 't' => time()];
        flash('ok', 'Código validado. Continuemos con tu registro.');
        redirect('registro/tipo.php');
    }
    $err = $r['error'];
}
layout_inicio('Código de registro'); ?>
<div class="reg-page"><?php reg_cabecera(1); ?><div class="reg-body"><div class="panel rise">
  <p class="kicker">Paso 1 de 5</p><h2 class="title">Tu código de recepción</h2>
  <p class="lead">Por seguridad y privacidad del gimnasio, solo puedes registrarte con el código único de 6 dígitos que te entregan en recepción.</p>
  <form method="post" class="form card corners" autocomplete="off"><?= csrf_field() ?>
    <input type="hidden" name="codigo" id="codigo"><span class="label">Código único</span>
    <div class="otp<?= $err ? ' shake' : '' ?>" data-target="codigo"><?php for ($i = 0; $i < 6; $i++): ?><input inputmode="numeric" maxlength="1" aria-label="Dígito <?= $i + 1 ?>"<?= $i ? '' : ' autofocus' ?>><?php endfor; ?></div>
    <?php if ($err): ?><p class="hint err" role="alert" style="margin:0"><?= e($err) ?></p><?php endif; ?>
    <button class="btn btn-primary btn-block" type="submit" disabled>Validar código <?= icon('arrow', 18) ?></button>
  </form>
  <?= alerta('', 'shield', '<span class="muted" style="font-size:13.5px">Prototipo: cualquier combinación de 6 dígitos del 0 al 9 es válida. Recepción genera códigos reales desde su panel.</span>', ' style="margin-top:18px"') ?>
  <p class="hint" style="text-align:center;margin-top:22px">¿Ya tienes cuenta? <a class="link" href="<?= url('index.php') ?>">Inicia sesión</a></p>
</div></div></div>
<?php layout_fin();
