<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
require ROOT_PATH . '/includes/registro.php';
$r = reg_requiere('tipo');
$menor = $r['tipo'] === 'menor';
$v = $r['datos'] ?? []; $docs = $r['docs'] ?? []; $E = [];

if (es_post()) {
    csrf_verificar();
    $v = validar_persona($_POST, $E, $r['tipo']);
    $v['tel_contacto'] = preg_replace('/\D/', '', $_POST['tel_contacto'] ?? '');
    $v['tel_emergencia'] = preg_replace('/\D/', '', $_POST['tel_emergencia'] ?? '');
    $v['tutor_nombre'] = $menor ? mayus($_POST['tutor_nombre'] ?? '') : '';
    if ($menor && !preg_match("/^[A-ZÁÉÍÓÚÜÑ][A-ZÁÉÍÓÚÜÑ '.-]{4,119}$/u", $v['tutor_nombre'])) $E['tutor_nombre'] = 'Escribe el nombre completo del padre, madre o tutor en MAYÚSCULAS.';
    if (!preg_match('/^\d{10}$/', $v['tel_contacto'])) $E['tel_contacto'] = 'Número de contacto a 10 dígitos.';
    if (!preg_match('/^\d{10}$/', $v['tel_emergencia'])) $E['tel_emergencia'] = 'Número de emergencia a 10 dígitos.';
    elseif ($v['tel_emergencia'] === $v['tel_contacto']) $E['tel_emergencia'] = 'Debe ser distinto al número de contacto.';
    $req = ['id_oficial' => $menor ? 'Identificación del menor' : 'Identificación oficial'];
    if ($menor) $req['id_tutor'] = 'Identificación del padre/tutor';
    if ($v['enfermedad_cronica'] && $v['enfermedad_cronica'] !== 'NINGUNA') $req['cert_medico'] = 'Constancia médica'; else unset($docs['cert_medico']);
    procesar_documentos($req, $docs, $E, $menor ? 'firma electrónica del padre/tutor' : 'firma electrónica');
    $_SESSION['reg']['datos'] = $v; $_SESSION['reg']['docs'] = $docs;
    if (!$E) { $_SESSION['reg']['datos_ok'] = true; redirect('registro/cuenta.php'); }
    unset($_SESSION['reg']['datos_ok']);
}
$val = fn($k) => e($v[$k] ?? '');
layout_inicio('Datos de registro'); ?>
<div class="reg-page"><?php reg_cabecera(3); ?><div class="reg-body"><div class="panel panel-wide rise">
  <p class="kicker">Paso 3 de 5 · <?= $menor ? 'Menor de edad' : 'Mayor de edad' ?></p><h2 class="title">Datos del socio</h2>
  <p class="lead">Escribe todo en <strong>MAYÚSCULAS</strong> (el formulario lo convierte automáticamente). Los campos con <span class="accent">*</span> son obligatorios.</p>
  <?php if ($E): ?><div class="alert alert-bad" role="alert" style="margin-bottom:22px"><?= icon('alert', 18) ?><span>Revisa <?= count($E) ?> campo(s) marcados abajo.</span></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="form" novalidate><?= csrf_field() ?>
    <?= bloque_identidad($v, $E, $menor ? '01 · Identidad del menor' : '01 · Identidad', $r['tipo']) ?>
    <fieldset class="fieldset"><legend>02 · Contacto</legend><div class="form-grid">
      <div class="field col-6<?= inv($E, 'tel_contacto') ?>"><label for="tc">Número de contacto <span class="req">*</span></label><input class="input mono" id="tc" name="tel_contacto" value="<?= $val('tel_contacto') ?>" inputmode="tel" data-digits="10" placeholder="10 dígitos"><?= err($E, 'tel_contacto') ?></div>
      <div class="field col-6<?= inv($E, 'tel_emergencia') ?>"><label for="te">Número de emergencia <span class="req">*</span></label><input class="input mono" id="te" name="tel_emergencia" value="<?= $val('tel_emergencia') ?>" inputmode="tel" data-digits="10" placeholder="10 dígitos"><?= err($E, 'tel_emergencia') ?></div>
      <?php if ($menor): ?><div class="field col-12<?= inv($E, 'tutor_nombre') ?>"><label for="tutor">Nombre completo del padre, madre o tutor <span class="req">*</span></label><input class="input upper" id="tutor" name="tutor_nombre" value="<?= $val('tutor_nombre') ?>" maxlength="120"><?= err($E, 'tutor_nombre') ?></div><?php endif; ?>
    </div></fieldset>
    <?= bloque_salud($v, $E, $docs, 'Al indicar una enfermedad crónica, adjunta un documento en el que un médico avale que puedes realizar actividad física.') ?>
    <fieldset class="fieldset"><legend>04 · Documentos y firma</legend><div class="form-grid">
      <div class="col-<?= $menor ? 6 : 12 ?>"><?= campo_upload('id_oficial', $menor ? 'Identificación oficial del menor' : 'Foto de identificación oficial', $menor ? 'Credencial escolar, pasaporte o CURP con foto' : 'INE, pasaporte o licencia · JPG, PNG o PDF', $docs['id_oficial'] ?? null) . err($E, 'id_oficial') ?></div>
      <?php if ($menor): ?><div class="col-6"><?= campo_upload('id_tutor', 'Identificación oficial del padre/tutor', 'INE o pasaporte · JPG, PNG o PDF', $docs['id_tutor'] ?? null) . err($E, 'id_tutor') ?></div><?php endif; ?>
      <div class="col-12"><?= campo_firma($menor ? 'Firma electrónica del padre/tutor' : 'Firma electrónica', !empty($docs['firma'])) . err($E, 'firma') ?>
        <p class="hint"><?= $menor ? 'Al firmar como padre/tutor autorizas la inscripción del menor, confirmas que la información es verídica y aceptas' : 'Al firmar confirmas que la información es verídica y aceptas' ?> el reglamento interno de FIT CODE.</p></div>
    </div></fieldset>
    <div class="actions"><a href="<?= url('registro/tipo.php') ?>" class="btn btn-ghost"><?= icon('back', 18) ?> Cambiar tipo</a><button class="btn btn-primary" type="submit">Continuar <?= icon('arrow', 18) ?></button></div>
  </form>
</div></div></div>
<?php layout_fin();
