<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
require ROOT_PATH . '/includes/registro.php';
reg_requiere();
if (es_post()) {
    csrf_verificar();
    if (in_array($_POST['tipo'] ?? '', ['mayor', 'menor'], true)) {
        $_SESSION['reg']['tipo'] = $_POST['tipo'];
        unset($_SESSION['reg']['datos'], $_SESSION['reg']['datos_ok']);
        redirect('registro/datos.php');
    }
}
layout_inicio('Tipo de registro'); ?>
<div class="reg-page"><?php reg_cabecera(2); ?><div class="reg-body"><div class="panel panel-wide rise">
  <p class="kicker">Paso 2 de 5</p><h2 class="title">¿Quién se va a registrar?</h2>
  <p class="lead">Los socios menores de edad necesitan la identificación y la firma de su padre, madre o tutor.</p>
  <form method="post" class="choice-grid"><?= csrf_field() ?>
    <button class="choice" name="tipo" value="mayor" type="submit"><span class="big">18<small>+ años</small></span><h3>Mayor de edad</h3><p>Registro con tus datos, identificación oficial y tu firma electrónica.</p><span class="go">Continuar <?= icon('arrow', 16) ?></span></button>
    <button class="choice" name="tipo" value="menor" type="submit"><span class="big">−18<small>años</small></span><h3>Menor de edad</h3><p>Identificación del menor y del padre/tutor, más la firma electrónica del padre/tutor.</p><span class="go">Continuar <?= icon('arrow', 16) ?></span></button>
  </form>
</div></div></div>
<?php layout_fin();
