<?php

function icon(string $n, int $size = 20): string
{
    $p = [
        'home'     => '<path d="M3 10.5 12 3l9 7.5V21h-6v-6H9v6H3z"/>',
        'id'       => '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="12" r="2.5"/><path d="M14 10h4M14 14h4"/>',
        'card'     => '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/>',
        'receipt'  => '<path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
        'chart'    => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
        'grid'     => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
        'logout'   => '<path d="M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 17l5-5-5-5M15 12H3"/>',
        'user'     => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
        'users'    => '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.5 3-5.5 7-5.5s7 2 7 5.5M16 4.5a3.5 3.5 0 0 1 0 7M18 14.6c2.4.6 4 2.3 4 5.4"/>',
        'shield'   => '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/>',
        'scan'     => '<path d="M3 7V4h3M18 4h3v3M21 17v3h-3M6 20H3v-3M7 8v8M10 8v8M13 8v8M17 8v8"/>',
        'check'    => '<path d="m5 12 5 5 9-10"/>',
        'alert'    => '<path d="M12 3 2 20h20zM12 10v4M12 17v.5"/>',
        'clock'    => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'search'   => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
        'arrow'    => '<path d="M5 12h14M13 6l6 6-6 6"/>',
        'back'     => '<path d="M19 12H5M11 6l-6 6 6 6"/>',
        'lock'     => '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
        'upload'   => '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
        'file'     => '<path d="M6 2h8l5 5v15H6z"/><path d="M14 2v5h5"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
        'dumbbell' => '<path d="M6 7v10M3 9v6M18 7v10M21 9v6M6 12h12"/>',
        'bolt'     => '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
        'pen'      => '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
        'refresh'  => '<path d="M20 11a8 8 0 0 0-14.9-3M4 4v4h4M4 13a8 8 0 0 0 14.9 3M20 20v-4h-4"/>',
        'print'    => '<path d="M6 9V3h12v6M6 17H4v-7h16v7h-2M7 14h10v7H7z"/>',
        'key'      => '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3"/>',
        'eye'      => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'swap'     => '<path d="M7 4 3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7"/>',
    ][$n] ?? '';
    return '<svg class="ico" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p . '</svg>';
}

function logo(string $clase = ''): string
{
    return '<span class="logo ' . $clase . '"><span class="logo-mark">' . icon('bolt', 16) . '</span><span>FIT<b>CODE</b></span></span>';
}

function layout_inicio(string $titulo, string $clase = ''): void
{ ?><!doctype html>
<html lang="es-MX">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#08090b">
<title><?= e($titulo) ?> · FIT CODE</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;500;800&family=Space+Grotesk:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>?v=<?= APP_VERSION ?>">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><rect width='24' height='24' rx='6' fill='%23c8ff2e'/><path d='M13 3 5 14h6l-1 7 8-11h-6z' fill='%2308090b'/></svg>">
</head>
<body class="<?= e($clase) ?>">
<div class="bg-grid" aria-hidden="true"></div>
<?php
    $f = flashes();
    if ($f) {
        echo '<div class="toasts">';
        foreach ($f as [$t, $m]) echo '<div class="toast toast-' . e($t) . '" role="status">' . icon($t === 'ok' ? 'check' : 'alert', 18) . '<span>' . e($m) . '</span><button type="button" class="toast-x" aria-label="Cerrar">×</button></div>';
        echo '</div>';
    }
}
function layout_fin(): void
{ ?>
<script src="<?= url('assets/js/app.js') ?>?v=<?= APP_VERSION ?>"></script>
</body>
</html><?php
}

const MENU_SOCIO = [
    'inicio' => ['portal/inicio.php', 'home', 'Mi acceso'],
    'asignacion' => ['portal/asignacion.php', 'id', 'Asignación y tipo de membresía'],
    'membresia' => ['portal/membresia.php', 'card', 'Consulta tu membresía'],
    'pagos' => ['portal/pagos.php', 'receipt', 'Pagos, recibos y cambio de plan'],
    'avance' => ['portal/avance.php', 'chart', 'Avance, rutina y nutrición'],
    'maquinas' => ['portal/maquinas.php', 'grid', 'Máquinas disponibles'],
];
function shell_inicio(string $titulo, string $activo, array $menu, string $logoHref, string $tag, string $avatar, string $nombre, string $sub, string $logout, string $chip = ''): void
{
    layout_inicio($titulo, 'app'); ?>
<div class="shell">
  <aside class="side"><a href="<?= url($logoHref) ?>" class="side-logo"><?= logo() ?><?= $tag ? '<span class="tag mono">' . e($tag) . '</span>' : '' ?></a>
    <nav class="side-nav" aria-label="Menú"><?php foreach ($menu as $k => [$h, $ic, $t]): ?><a href="<?= url($h) ?>" class="<?= $k === $activo ? 'on' : '' ?>"><?= icon($ic) ?><span><?= e($t) ?></span></a><?php endforeach; ?></nav>
    <div class="side-user"><div class="avatar"><?= e($avatar) ?></div><div class="side-user-txt"><strong><?= e($nombre) ?></strong><small class="mono"><?= e($sub) ?></small></div>
      <form method="post" action="<?= url($logout) ?>"><?= csrf_field() ?><button class="icon-btn" title="Cerrar sesión" aria-label="Cerrar sesión"><?= icon('logout') ?></button></form></div></aside>
  <main class="main"><header class="topbar"><h1><?= e($titulo) ?></h1><span class="chip mono"><span class="dot dot-live"></span><?= $chip ?: fecha_mx(hoy()) ?></span></header>
<?php
}
function shell_fin(): void { echo '</main></div>'; layout_fin(); }

function portal_inicio(string $titulo, string $activo, array $s): void
{
    shell_inicio($titulo, $activo, MENU_SOCIO, 'portal/inicio.php', '', mb_substr($s['nombre'], 0, 1) . mb_substr($s['apellido_paterno'], 0, 1), $s['nombre'] . ' ' . $s['apellido_paterno'], $s['usuario'], 'logout.php');
}
function staff_inicio(string $titulo, string $activo, array $st): void
{
    $menu = $st['rol'] === 'instructor' ? ['coach' => ['coach/index.php', 'users', 'Mis socios']]
        : ['panel' => ['staff/index.php', 'grid', 'Inicio'], 'usuarios' => ['staff/usuarios.php', 'users', 'Información del usuario'], 'cobros' => ['staff/cobros.php', 'receipt', 'Cobros en efectivo']];
    if (in_array($st['rol'], ['administrador', 'dueno'], true)) $menu['admin'] = ['staff/admin.php', 'shield', 'Acceso administración'];
    shell_inicio($titulo, $activo, $menu, $st['rol'] === 'instructor' ? 'coach/index.php' : 'staff/index.php', $st['rol'] === 'instructor' ? 'COACH' : 'STAFF',
        mb_substr($st['nombre'], 0, 1), $st['nombre_corto'], ROL_NOMBRE[$st['rol']] . ' · ' . $st['numero_empleado'], 'personal/logout.php', date('H:i'));
}

function socio_actual(): ?array { static $s = false; if ($s === false) $s = !empty($_SESSION['socio_id']) ? Socios::porId((int)$_SESSION['socio_id']) : null; return $s; }
function requiere_socio(): array { $s = socio_actual(); if (!$s) { flash('error', 'Inicia sesión para continuar.'); redirect('index.php'); } return $s; }
function staff_actual(): ?array { static $s = false; if ($s === false) $s = !empty($_SESSION['usuario_id']) ? Personal::sesionActiva((int)$_SESSION['usuario_id']) : null; return $s; }
function requiere_staff(array $roles = ['recepcion', 'administrador', 'dueno']): array
{
    $st = staff_actual();
    if (!$st) { flash('error', 'Inicia sesión como personal del gimnasio.'); redirect('personal/index.php'); }
    if (!in_array($st['rol'], $roles, true)) { flash('error', 'Tu rol no tiene acceso a esa sección.'); redirect($st['rol'] === 'instructor' ? 'coach/index.php' : 'staff/index.php'); }
    return $st;
}

function badge(string $e, ?string $txt = null): string
{
    $m = ['activa' => 'ok', 'LIBRE' => 'ok', 'pagado' => 'ok', 'activo' => 'ok', 'permitido' => 'ok', 'pendiente' => 'warn', 'OCUPADA' => 'warn',
        'vencida' => 'bad', 'cancelada' => 'bad', 'rechazado' => 'bad', 'inactivo' => 'bad', 'membresia_vencida' => 'bad', 'sin_membresia' => 'bad', 'codigo_invalido' => 'bad'];
    return '<span class="badge badge-' . ($m[$e] ?? 'mute') . '">' . e(mb_strtoupper(str_replace('_', ' ', $txt ?? $e))) . '</span>';
}
function err(array $E, string $k): string { return isset($E[$k]) ? '<p class="hint err">' . e($E[$k]) . '</p>' : ''; }
function inv(array $E, string $k): string { return isset($E[$k]) ? ' invalid' : ''; }
function opciones(array $cat, ?string $sel): string
{
    $h = '<option value="">Selecciona…</option>';
    foreach ($cat as $c) $h .= '<option' . ($c === $sel ? ' selected' : '') . '>' . e($c) . '</option>';
    return $h;
}
function alerta(string $tipo, string $icono, string $html, string $extra = ''): string { return '<div class="alert alert-' . $tipo . '"' . $extra . '>' . icon($icono, 18) . '<span>' . $html . '</span></div>'; }
function campo_upload(string $name, string $titulo, string $ayuda, ?array $cargado): string
{
    return '<div class="field"><span class="label">' . e($titulo) . ' <span class="req">*</span></span>'
        . '<label class="drop"><span class="drop-ico">' . icon('upload', 18) . '</span><span><strong>Selecciona o arrastra un archivo</strong><small>' . e($ayuda) . '</small></span>'
        . '<input type="file" name="' . e($name) . '" accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/*"></label>'
        . ($cargado ? '<p class="hint" style="color:var(--ok)">✓ Ya cargado (' . e($cargado['nombre']) . '). Puedes reemplazarlo.</p>' : '') . '</div>';
}
function campo_firma(string $titulo, bool $cargada): string
{
    return '<div class="field" data-signature><span class="label">' . $titulo . ' <span class="req">*</span></span>
  <div class="sig-tabs" role="tablist"><button type="button" class="on" data-pane="draw">Dibujar firma</button><button type="button" data-pane="file">Subir imagen</button></div>
  <div data-sig-pane="draw"><div class="sig"><canvas aria-label="Lienzo para firmar"></canvas>
    <div class="sig-bar"><span data-sig-status>Firma dentro del recuadro</span><button type="button" class="btn btn-ghost btn-sm" data-sig-clear>Limpiar</button></div></div>
    <input type="hidden" name="firma_data"></div>
  <div data-sig-pane="file" class="hidden"><label class="drop"><span class="drop-ico">' . icon('pen', 18) . '</span><span><strong>Imagen de la firma</strong><small>PNG o JPG · máx. 5 MB</small></span>
    <input type="file" name="firma_file" accept="image/png,image/jpeg,image/webp"></label></div>'
        . ($cargada ? '<p class="hint" style="color:var(--ok)">✓ Firma ya capturada. Puedes volver a firmar si quieres.</p>' : '') . '</div>';
}
function campo_password(string $id = 'pw', string $label = 'Contraseña'): string
{
    return '<div class="field" id="' . $id . '-box"><label for="' . $id . '">' . $label . ' <span class="req">*</span></label>
  <div class="input-wrap">' . icon('lock', 18) . '<input class="input" type="password" id="' . $id . '" name="password" autocomplete="new-password" data-password="#' . $id . '-box"><button type="button" class="peek" aria-label="Mostrar contraseña">' . icon('eye', 18) . '</button></div>
  <div class="pw-meter"><i></i></div>
  <ul class="pw-rules"><li data-rule="lower">Letras minúsculas (a-z)</li><li data-rule="upper">Al menos una MAYÚSCULA</li><li data-rule="num">Al menos un número</li><li data-rule="sym">Al menos un signo (#$!%*)</li><li data-rule="len">Mínimo 8 caracteres</li></ul></div>';
}
function demo_box(string $html): string { return '<details class="demo-box"><summary>Cuentas de demostración</summary><p>' . $html . '</p></details>'; }
