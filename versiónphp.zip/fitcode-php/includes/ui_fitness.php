<?php

function planes_html(?array $m, bool $conBoton = false): string
{
    $h = '<div class="plans">';
    foreach (Planes::listar() as $p) {
        $actual = $m && (int)$m['tipo_membresia_id'] === (int)$p['id'] && $m['estado_real'] === 'activa';
        $h .= '<article class="plan' . ($actual ? ' current' : '') . '"><h4>' . e($p['nombre']) . '</h4><div class="price">$' . number_format($p['precio']) . ' <small>/ '
            . ($p['duracion_dias'] == 1 ? 'día' : $p['duracion_dias'] . ' días') . '</small></div><p class="hint" style="margin:0">' . e($p['descripcion']) . '</p><ul>';
        foreach ($p['beneficios'] as $b) $h .= '<li>' . e($b) . '</li>';
        $h .= '</ul>';
        if ($conBoton) $h .= '<a class="btn btn-sm ' . ($actual ? '' : 'btn-primary') . '" style="margin-top:auto" href="' . url('portal/pagar.php?plan=' . $p['id']) . '">'
            . ($actual ? 'Renovar' : ($m && $m['estado_real'] === 'activa' ? 'Cambiar a este plan' : 'Contratar')) . '</a>';
        $h .= '</article>';
    }
    return $h . '</div>';
}

function recibo_html(array $r, string $volver): string
{
    $fila = fn($a, $b) => '<div class="r-row"><span class="muted">' . $a . '</span><span>' . $b . '</span></div>';
    return '<section class="card corners receipt rise"><div class="row row-between" style="margin-bottom:20px">' . logo() . '<span class="mono dim">RECIBO</span></div>
  <p class="card-kicker">Folio</p><h2 class="title mono">' . e($r['folio']) . '</h2>'
        . $fila('Socio', e($r['socio'])) . $fila('Usuario', '<span class="mono">' . e($r['socio_usuario']) . '</span>') . $fila('Concepto', e($r['concepto']))
        . ($r['fecha_inicio'] ? $fila('Vigencia', '<span class="mono">' . fecha_mx($r['fecha_inicio']) . ' → ' . fecha_mx($r['fecha_fin']) . '</span>') : '')
        . $fila('Fecha de pago', '<span class="mono">' . fecha_mx($r['pagado_en'], true) . '</span>')
        . $fila('Método', e(METODO_NOMBRE[$r['metodo']] ?? $r['metodo']) . ($r['tarjeta_ultimos4'] ? ' · ' . e($r['tarjeta_marca']) . ' ···· ' . e($r['tarjeta_ultimos4']) : ''))
        . ($r['referencia_pago'] ? $fila('Ficha', '<span class="mono">' . e($r['referencia_pago']) . '</span>') : '')
        . $fila('Atendió', e($r['cajero'] ?: 'Pago en línea'))
        . '<div class="row row-between" style="margin-top:22px"><span class="label">Total pagado</span><span class="r-total">' . dinero($r['monto']) . '</span></div>
  <div style="margin-top:26px;background:#f4f6f2;padding:12px;border-radius:10px">' . barcode_svg($r['folio'], 48, 1.4, '#07080a') . '</div>
  <div class="actions no-print"><a class="btn btn-ghost" href="' . url($volver) . '">' . icon('back', 18) . ' Volver</a><button class="btn btn-primary" type="button" onclick="window.print()">' . icon('print', 18) . ' Imprimir / PDF</button></div></section>';
}

function validar_medicion(array $d): ?string
{
    $p = (float)($d['peso'] ?? 0); $e = (float)($d['estatura'] ?? 0); $g = $d['grasa'] ?? ''; $m = $d['musculo'] ?? '';
    if ($p < 25 || $p > 300) return 'El peso debe estar entre 25 y 300 kg.';
    if ($e < 100 || $e > 230) return 'La estatura debe estar entre 100 y 230 cm.';
    if ($g !== '' && ((float)$g < 3 || (float)$g > 70)) return 'El % de grasa debe estar entre 3 y 70.';
    if ($m !== '' && ((float)$m < 10 || (float)$m > 70)) return 'El % muscular debe estar entre 10 y 70.';
    return null;
}
function guardar_perfil(int $socioId, array $d, ?int $usuarioId): ?string
{
    if (!isset(OBJETIVOS[$d['objetivo'] ?? ''])) return 'Elige un objetivo.';
    if (!isset(NIVELES[$d['nivel'] ?? ''])) return 'Elige tu nivel.';
    $d['dias'] = min(6, max(3, (int)($d['dias'] ?? 3)));
    $d += ['grasa' => '', 'musculo' => ''];
    if ($e = validar_medicion($d)) return $e;
    Expedientes::guardar($socioId, $d, $usuarioId);
    $meds = Mediciones::porSocio($socioId); $u = end($meds) ?: null;
    if (!$u || (float)$u['peso_kg'] !== (float)$d['peso'] || (float)$u['estatura_cm'] !== (float)$d['estatura'] || $d['grasa'] !== '' || $d['musculo'] !== '') {
        Mediciones::registrar($socioId, ['peso' => $d['peso'], 'estatura' => $d['estatura'],
            'grasa' => $d['grasa'] !== '' ? $d['grasa'] : ($u['porcentaje_grasa'] ?? ''), 'musculo' => $d['musculo'] !== '' ? $d['musculo'] : ($u['porcentaje_musculo'] ?? '')], $usuarioId);
    }
    return null;
}
function form_medicion(?array $u, int $edad, string $accion, string $hidden = ''): string
{
    return '<form method="post" class="form" data-edad="' . $edad . '" novalidate>' . csrf_field() . '<input type="hidden" name="accion" value="' . $accion . '">' . $hidden . '
    <div class="form-grid">
      <div class="field col-6"><label for="m-peso">Peso (kg) <span class="req">*</span></label><input class="input mono" id="m-peso" name="peso" inputmode="decimal" value="' . ($u ? num($u['peso_kg']) : '') . '"></div>
      <div class="field col-6"><label for="m-est">Estatura (cm) <span class="req">*</span></label><input class="input mono" id="m-est" name="estatura" inputmode="decimal" value="' . ($u ? num($u['estatura_cm']) : '') . '"></div>
      <div class="field col-6"><label for="m-gr">% de grasa</label><input class="input mono" id="m-gr" name="grasa" inputmode="decimal" placeholder="Opcional"></div>
      <div class="field col-6"><label for="m-mu">% muscular</label><input class="input mono" id="m-mu" name="musculo" inputmode="decimal" placeholder="Opcional"></div>
    </div>
    <div class="imc-live"><span class="label">IMC calculado</span><strong class="mono" data-imc-out>—</strong><span class="hint" data-imc-cat></span></div>
    <button class="btn btn-primary btn-block" type="submit">' . icon('check', 18) . ' Guardar medición</button></form>';
}
function linea_svg(array $meds): string
{
    if (count($meds) < 2) return '<p class="hint">Registra al menos dos mediciones para ver tu gráfica.</p>';
    $series = [['Peso', '#c8ff2e', 'peso_kg'], ['% grasa', '#ffb547', 'porcentaje_grasa'], ['% muscular', '#3fe0a1', 'porcentaje_musculo']];
    $W = 600; $H = 170; $P = 26; $n = count($meds); $svg = '';
    foreach ($series as [, $c, $k]) {
        $vals = array_filter(array_map(fn($m) => $m[$k] === null ? null : (float)$m[$k], $meds), fn($x) => $x !== null);
        if (count($vals) < 2) continue;
        $mn = min($vals); $mx = max($vals); $r = ($mx - $mn) ?: 1; $pts = [];
        foreach ($meds as $i => $m) if ($m[$k] !== null) $pts[] = [$P + $i * ($W - 2 * $P) / ($n - 1), $H - $P - ((float)$m[$k] - $mn) / $r * ($H - 2 * $P)];
        $svg .= '<polyline fill="none" stroke="' . $c . '" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" points="' . implode(' ', array_map(fn($p) => round($p[0], 1) . ',' . round($p[1], 1), $pts)) . '"/>';
        foreach ($pts as $p) $svg .= '<circle cx="' . round($p[0], 1) . '" cy="' . round($p[1], 1) . '" r="3.5" fill="' . $c . '"/>';
    }
    return '<svg viewBox="0 0 ' . $W . ' ' . $H . '" class="linechart" role="img" aria-label="Evolución de mediciones">' . $svg . '</svg><div class="legend">'
        . implode('', array_map(fn($s) => '<span><i style="background:' . $s[1] . '"></i>' . $s[0] . '</span>', $series)) . '</div>';
}
function progreso_html(array $F, int $edad, string $accion, string $hidden = ''): string
{
    $meds = $F['meds']; $u = $F['u']; [$cat, $cls] = categoria_imc((float)$u['imc'], $edad);
    $delta = function (string $k, string $un) use ($meds) {
        $a = array_values(array_filter($meds, fn($m) => $m[$k] !== null));
        if (count($a) < 2) return '<span class="trend">Sin comparación</span>';
        $d = round((float)end($a)[$k] - (float)$a[0][$k], 1); $bueno = $k === 'porcentaje_musculo' ? $d >= 0 : $d <= 0;
        return '<span class="trend" style="color:' . ($bueno ? 'var(--ok)' : 'var(--warn)') . '">' . ($d > 0 ? '▲ +' : '▼ ') . num($d) . "$un desde " . fecha_mx($a[0]['fecha_medicion']) . '</span>';
    };
    $ult = function (string $k) use ($meds) { foreach (array_reverse($meds) as $m) if ($m[$k] !== null) return num($m[$k]); return '—'; };
    $filas = '';
    foreach (array_reverse($meds) as $m) {
        $quien = $m['registrado_por'] ? (Personal::porUsuario((int)$m['registrado_por'])['nombre_corto'] ?? 'Coach') : 'Socio';
        $filas .= '<tr><td>' . fecha_mx($m['fecha_medicion']) . '</td><td class="num">' . num($m['peso_kg']) . ' kg</td><td class="num">' . num($m['imc']) . '</td><td class="num">'
            . ($m['porcentaje_grasa'] !== null ? num($m['porcentaje_grasa']) . '%' : '—') . '</td><td class="num">' . ($m['porcentaje_musculo'] !== null ? num($m['porcentaje_musculo']) . '%' : '—') . '</td><td class="hint">' . e($quien) . '</td></tr>';
    }
    return '<div class="grid g-4" style="margin-bottom:18px">
    <div class="card kpi"><span class="label">Peso</span><strong>' . num($u['peso_kg']) . '<small>kg</small></strong>' . $delta('peso_kg', ' kg') . '</div>
    <div class="card kpi"><span class="label">IMC</span><strong>' . num($u['imc']) . '</strong><span class="trend"><span class="badge badge-' . $cls . '">' . e($cat) . '</span></span></div>
    <div class="card kpi"><span class="label">% grasa</span><strong>' . $ult('porcentaje_grasa') . '<small>%</small></strong>' . $delta('porcentaje_grasa', '%') . '</div>
    <div class="card kpi"><span class="label">% muscular</span><strong>' . $ult('porcentaje_musculo') . '<small>%</small></strong>' . $delta('porcentaje_musculo', '%') . '</div></div>
  <div class="grid g-main">
    <section class="card"><p class="card-kicker">Evolución</p>' . linea_svg($meds) . '
      <div class="table-wrap" style="margin-top:14px"><table class="t"><thead><tr><th>Fecha</th><th class="num">Peso</th><th class="num">IMC</th><th class="num">Grasa</th><th class="num">Músculo</th><th>Registró</th></tr></thead><tbody>' . $filas . '</tbody></table></div></section>
    <section class="card" style="align-self:start"><p class="card-kicker">Registrar cambios</p><h3 class="card-title" style="margin-bottom:14px">Nueva medición</h3>' . form_medicion($u, $edad, $accion, $hidden) . '
      <p class="hint" style="margin-bottom:0">El IMC se recalcula automáticamente con peso y estatura.</p></section></div>';
}
function onboarding_html(?array $exp, ?array $u, int $edad, string $accion, string $hidden, string $titulo): string
{
    $sel = $exp['objetivo_principal'] ?? null; $goals = '';
    foreach (OBJETIVOS as $k => $o) $goals .= '<label class="goal"><input type="radio" name="objetivo" value="' . $k . '"' . ($k === $sel ? ' checked' : '') . '><span>' . icon($o['icono'], 22) . '<strong>' . e($o['nombre']) . '</strong><small>' . e($o['desc']) . '</small></span></label>';
    $niv = ''; foreach (NIVELES as $k => $n) $niv .= '<option value="' . $k . '"' . ($k === ($exp['nivel'] ?? 'principiante') ? ' selected' : '') . '>' . $n . '</option>';
    $dias = ''; foreach ([3, 4, 5, 6] as $n) $dias .= '<option' . ($n === (int)($exp['dias_entrenamiento'] ?? 3) ? ' selected' : '') . '>' . $n . '</option>';
    return '<section class="card corners rise"><p class="card-kicker">' . e($titulo) . '</p><h2 class="title" style="font-size:24px">¿Cuál es tu objetivo?</h2>
  <p class="lead">Con el objetivo, la edad, el peso y la estatura generamos la rutina semanal y un plan nutricional sugerido. Se puede cambiar cuando quieras.</p>
  <form method="post" class="form" data-edad="' . $edad . '" novalidate>' . csrf_field() . '<input type="hidden" name="accion" value="' . $accion . '">' . $hidden . '
    <div class="goals">' . $goals . '</div>
    <div class="form-grid">
      <div class="field col-6"><label for="o-nivel">Nivel de experiencia</label><select class="input" id="o-nivel" name="nivel">' . $niv . '</select></div>
      <div class="field col-6"><label for="o-dias">Días por semana para entrenar</label><select class="input" id="o-dias" name="dias">' . $dias . '</select></div>
      <div class="field col-6"><label for="m-peso">Peso actual (kg)</label><input class="input mono" id="m-peso" name="peso" inputmode="decimal" value="' . ($u ? num($u['peso_kg']) : '') . '"></div>
      <div class="field col-6"><label for="m-est">Estatura (cm)</label><input class="input mono" id="m-est" name="estatura" inputmode="decimal" value="' . ($u ? num($u['estatura_cm']) : '') . '"></div>
      ' . ($u ? '' : '<div class="field col-6"><label for="m-gr">% de grasa (opcional)</label><input class="input mono" id="m-gr" name="grasa" inputmode="decimal"></div><div class="field col-6"><label for="m-mu">% muscular (opcional)</label><input class="input mono" id="m-mu" name="musculo" inputmode="decimal"></div>') . '
    </div>
    <div class="imc-live"><span class="label">IMC calculado</span><strong class="mono" data-imc-out>—</strong><span class="hint" data-imc-cat></span></div>
    <button class="btn btn-primary btn-block" type="submit">' . icon('bolt', 18) . ' Generar plan</button></form></section>';
}

function semana_html(array $plan): string
{
    $h = '<div class="week">';
    foreach ($plan['semana_completa'] as $d) {
        $h .= '<article class="day' . ($d['descanso'] ? ' rest' : '') . '"><header><span class="mono dim">' . mb_strtoupper(mb_substr($d['dia'], 0, 3)) . '</span><strong>' . e($d['enfoque']) . '</strong>'
            . (!empty($d['minutos']) ? '<span class="chip mono">' . $d['minutos'] . ' min</span>' : '') . '</header>';
        if ($d['descanso']) $h .= '<p class="hint" style="margin:0">' . e($d['nota']) . '</p>';
        else {
            $h .= '<ul class="exlist">';
            foreach ($d['ejercicios'] as $x) $h .= '<li><span>' . e($x['nombre']) . '</span><span class="mono">' . $x['series'] . '×' . e($x['reps']) . '<small>' . $x['descanso'] . 's</small></span></li>';
            $h .= '</ul><p class="hint cardio">' . icon('bolt', 14) . ' ' . e($d['cardio']) . '</p>';
        }
        $h .= '</article>';
    }
    return $h . '</div>';
}
function rutina_asignada_html(array $a): string
{
    $h = '<section class="card corners rise" style="margin-bottom:18px"><div class="card-head"><div><p class="card-kicker">Asignada por tu coach</p><h3 class="card-title">' . e($a['nombre']) . '</h3><p class="hint" style="margin:4px 0 0">Coach ' . e($a['coach']) . ' · desde ' . fecha_mx($a['desde']) . '</p></div>' . badge('activa') . '</div><div class="week">';
    foreach ($a['dias'] as $d) {
        $h .= '<article class="day"><header><span class="mono dim">DÍA ' . $d['dia_numero'] . '</span><strong>' . e($d['enfoque']) . '</strong></header><ul class="exlist">';
        foreach ($d['ejercicios'] as $x) $h .= '<li><span>' . e($x['ejercicio']) . '</span><span class="mono">' . $x['series'] . '×' . e($x['repeticiones']) . '<small>' . $x['descanso_segundos'] . 's</small></span></li>';
        $h .= '</ul></article>';
    }
    return $h . '</div></section>';
}
function plan_html(array $plan, string $boton = ''): string
{
    $notas = ''; foreach ($plan['notas'] as $n) $notas .= alerta('', 'alert', '<span class="muted">' . e($n) . '</span>', ' style="margin-bottom:10px"');
    return '<section class="card rise"><div class="card-head"><div><p class="card-kicker">Rutina semanal sugerida</p><h3 class="card-title">' . e($plan['nombre']) . ' · ' . NIVELES[$plan['nivel']] . '</h3></div>' . $boton . '</div>'
        . $notas . semana_html($plan) . '<p class="hint" style="margin-top:16px">' . icon('chart', 14) . ' Progresión: ' . e($plan['progresion']) . ' Calienta 5-10 min antes de cada sesión.</p></section>';
}
function nutricion_html(array $n): string
{
    if ($n['menor']) return alerta('warn', 'alert', 'Para menores de 18 años no generamos metas de calorías: su alimentación debe indicarla su pediatra o un nutriólogo. Guía general: plato del bien comer (½ verduras y frutas, ¼ cereales integrales, ¼ proteína), agua simple y 3 comidas + 2 colaciones.');
    $tot = $n['prot'] * 4 + $n['grasa'] * 9 + $n['carb'] * 4;
    $pct = fn($g, $k) => round($g * $k / $tot * 100);
    $h = alerta('warn', 'alert', '<strong>Plan SUGERIDO, no es una prescripción médica.</strong> Se calcula con fórmulas generales (Mifflin-St Jeor y equivalentes SMAE). Si tienes una enfermedad crónica, estás embarazada o tomas medicamentos, valídalo con un nutriólogo.', ' style="margin-bottom:18px"')
        . '<div class="grid g-4" style="margin-bottom:18px">
    <div class="card kpi"><span class="label">Meta diaria</span><strong>' . number_format($n['kcal']) . '<small>kcal</small></strong><span class="trend">gasto estimado ' . number_format($n['gasto']) . ' kcal</span></div>
    <div class="card kpi"><span class="label">Proteína</span><strong>' . $n['prot'] . '<small>g</small></strong><span class="trend">' . $pct($n['prot'], 4) . '% de la energía</span></div>
    <div class="card kpi"><span class="label">Carbohidratos</span><strong>' . $n['carb'] . '<small>g</small></strong><span class="trend">' . $pct($n['carb'], 4) . '% de la energía</span></div>
    <div class="card kpi"><span class="label">Grasas</span><strong>' . $n['grasa'] . '<small>g</small></strong><span class="trend">' . $pct($n['grasa'], 9) . '% de la energía</span></div></div>'
        . ($n['limitado'] ? '<p class="hint">Se aplicó un mínimo seguro de calorías para no bajar de tu metabolismo basal.</p>' : '')
        . '<div class="grid g-main"><section class="card"><p class="card-kicker">Distribución por comida (equivalentes)</p>';
    foreach ($n['comidas'] as $c) {
        $h .= '<div class="meal"><div class="row row-between"><strong>' . $c['nombre'] . '</strong><span class="mono dim">' . $c['hora'] . ' · ≈' . $c['kcal'] . ' kcal</span></div><div class="eqs">';
        foreach ($c['eq'] as $g => $x) $h .= '<span class="eq">' . num($x) . ' ' . EQ_NOMBRE[$g] . '</span>';
        $h .= '</div><p class="hint" style="margin:6px 0 0">Ejemplo: ' . e($c['ejemplo']) . '</p></div>';
    }
    $h .= '</section><div class="grid" style="align-content:start"><section class="card"><p class="card-kicker">¿Qué es 1 equivalente?</p><dl class="dl" style="grid-template-columns:1fr">';
    foreach (EJEMPLOS as $g => $t) $h .= '<div><dt>' . EQ_NOMBRE[$g] . ' · ' . $n['eq_dia'][$g] . ' al día</dt><dd style="font-weight:400;font-size:13.5px">' . e($t) . '</dd></div>';
    $h .= '</dl></section><section class="card"><p class="card-kicker">Para tu objetivo</p><ul class="benefits">';
    foreach ($n['tips'] as $t) $h .= '<li>' . icon('check', 16) . e($t) . '</li>';
    return $h . '<li>' . icon('check', 16) . 'Agua: ≈ ' . num($n['agua']) . ' L al día.</li></ul></section></div></div>';
}

function lista_socios_html(string $q, string $base, bool $coach): string
{
    $res = Socios::buscar($q);
    $h = '<form class="search-big rise" method="get" role="search" style="margin-bottom:22px">' . icon('search', 20) . '<input class="input" name="q" value="' . e($q) . '" placeholder="Buscar por nombre, apellidos, usuario o código…" aria-label="Buscar socio" data-live-search></form>
<section class="card rise rise-2"><div class="card-head"><div><p class="card-kicker">' . ($q ? 'Resultados para “' . e($q) . '”' : 'Todos los socios') . '</p><h3 class="card-title">' . count($res) . ' socio(s)</h3></div></div>';
    if (!$res) return $h . '<div class="empty">' . icon('search', 32) . 'No se encontraron socios con ese nombre.</div></section>';
    $h .= '<div class="table-wrap"><table class="t"><thead><tr><th>Socio</th>' . ($coach ? '<th>Objetivo</th><th>IMC</th><th>Rutina</th>' : '<th>Código</th><th>Tipo</th><th>Membresía</th>') . '<th></th></tr></thead><tbody>';
    foreach ($res as $s) {
        $h .= '<tr><td><div class="person"><span class="avatar">' . e(mb_substr($s['nombre'], 0, 1) . mb_substr($s['apellido_paterno'], 0, 1)) . '</span><div><strong>' . e($s['nombre_completo']) . '</strong><small class="mono">' . e($s['usuario']) . ' · ' . $s['edad'] . ' años</small></div></div></td>';
        if ($coach) {
            $ex = Expedientes::obtener((int)$s['id']); $meds = Mediciones::porSocio((int)$s['id']); $u = end($meds);
            $h .= '<td>' . ($ex && $ex['objetivo_principal'] ? e(OBJETIVOS[$ex['objetivo_principal']]['nombre']) : '<span class="hint">Sin definir</span>') . '</td><td class="mono">' . ($u ? num($u['imc']) : '—') . '</td><td>' . (Rutinas::asignada((int)$s['id']) ? badge('activa', 'asignada') : '<span class="hint">—</span>') . '</td>';
        } else {
            $m = Membresias::actual((int)$s['id']);
            $h .= '<td class="mono">' . e($s['codigo_credencial']) . '</td><td>' . ($s['tipo_socio'] === 'menor' ? 'Menor' : 'Mayor') . '</td><td>' . ($m ? badge($m['estado_real']) . ($m['estado_real'] === 'activa' ? ' <span class="hint mono">→ ' . fecha_mx($m['fecha_fin']) . '</span>' : '') : badge('mute', 'sin membresía')) . '</td>';
        }
        $h .= '<td><a class="btn btn-sm" href="' . url("$base?id={$s['id']}") . '">Ver ficha ' . icon('arrow', 14) . '</a></td></tr>';
    }
    return $h . '</tbody></table></div></section>';
}
