<?php

function base_url(): string
{
    static $b = null;
    if ($b !== null) return $b;
    $doc = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
    $root = realpath(ROOT_PATH);
    return $b = rtrim(($doc && str_starts_with($root, $doc)) ? str_replace('\\', '/', substr($root, strlen($doc))) : '', '/');
}
function url(string $p = ''): string { return base_url() . '/' . ltrim($p, '/'); }
function redirect(string $p): never { header('Location: ' . url($p)); exit; }
function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function es_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }
function ahora(): string { return date('Y-m-d H:i:s'); }
function hoy(): string { return date('Y-m-d'); }
function mas_minutos(int $m, ?string $desde = null): string { return date('Y-m-d H:i:s', strtotime(($desde ?? ahora()) . " +$m minutes")); }
function mas_dias(string $fecha, int $d): string { return date('Y-m-d', strtotime("$fecha $d days")); }
function dias_entre(string $a, string $b): int { return (int)round((strtotime(substr($b, 0, 10)) - strtotime(substr($a, 0, 10))) / 86400); }
function mayus(?string $s): string { return trim(preg_replace('/\s+/', ' ', mb_strtoupper((string)$s, 'UTF-8'))); }
function pad($n, int $l = 2): string { return str_pad((string)$n, $l, '0', STR_PAD_LEFT); }

function iniciar_sesion(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    session_name('FITCODE');
    session_set_cookie_params(['lifetime' => 0, 'path' => base_url() . '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
    session_start();
}
function csrf_token(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(16)); }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . csrf_token() . '">'; }
function csrf_verificar(): void
{
    $esp = $_SESSION['csrf'] ?? '';
    if ($esp === '' || !hash_equals($esp, (string)($_POST['csrf'] ?? ''))) {
        http_response_code(419);
        flash('error', 'El formulario expiró. Intenta de nuevo.');
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? url('index.php'))); exit;
    }
}
function flash(string $t, string $m): void { $_SESSION['flash'][] = [$t, $m]; }
function flashes(): array { $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f; }

function validar_password(string $p): array
{
    $e = [];
    if (strlen($p) < 8) $e[] = 'al menos 8 caracteres';
    if (!preg_match('/[a-z]/', $p)) $e[] = 'una letra minúscula (a-z)';
    if (!preg_match('/[A-Z]/', $p)) $e[] = 'una letra MAYÚSCULA';
    if (!preg_match('/\d/', $p)) $e[] = 'un número';
    if (!preg_match('/[^a-zA-Z0-9]/', $p)) $e[] = 'un signo (ej. # $ ! % *)';
    return $e;
}
function validar_rfc(string $r): bool { return (bool)preg_match('/^[A-ZÑ&]{4}\d{6}$/u', $r); }
function hash_senuelo(): string { static $h = null; return $h ??= password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT); }
function validar_email(string $e): bool { return (bool)filter_var($e, FILTER_VALIDATE_EMAIL); }
const RE_NOMBRE = "/^[A-ZÁÉÍÓÚÜÑ][A-ZÁÉÍÓÚÜÑ '.-]{0,59}$/u";

function parse_fecha_dmy(string $s): ?string
{
    if (!preg_match('#^(\d{2})/(\d{2})/(\d{4})$#', $s, $m) || !checkdate((int)$m[2], (int)$m[1], (int)$m[3])) return null;
    $iso = "$m[3]-$m[2]-$m[1]";
    return ($iso > hoy() || (int)$m[3] < 1900) ? null : $iso;
}
function edad_desde(string $iso): int { return (new DateTime($iso))->diff(new DateTime('today'))->y; }
function quitar_acentos(string $s): string
{
    $s = strtr($s, ['Á' => 'A', 'É' => 'E', 'Í' => 'I', 'Ó' => 'O', 'Ú' => 'U', 'Ü' => 'U', 'Ñ' => 'N', 'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u', 'ü' => 'u', 'ñ' => 'n']);
    return preg_replace('/[^A-Za-z0-9 ]/', '', $s);
}

function luhn_digito(string $num): int
{
    $s = 0; $rev = strrev($num);
    for ($i = 0; $i < strlen($rev); $i++) { $d = (int)$rev[$i]; if ($i % 2 === 0) { $d *= 2; if ($d > 9) $d -= 9; } $s += $d; }
    return (10 - $s % 10) % 10;
}
function generar_codigo_barras(int $id, string $fecha): string { $c = substr($fecha, 2, 2) . pad($id, 6); return 'FC' . $c . luhn_digito($c); }
function codigo_barras_valido(string $c): bool { return (bool)preg_match('/^FC(\d{8})(\d)$/', $c, $m) && luhn_digito($m[1]) === (int)$m[2]; }

function fecha_mx(?string $iso, bool $hora = false): string
{
    if (!$iso) return '—';
    $M = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
    $t = strtotime($iso);
    return date('d', $t) . ' ' . $M[(int)date('n', $t) - 1] . ' ' . date('Y', $t) . ($hora ? ' · ' . date('H:i', $t) : '');
}
function hora_de(string $iso): string { return date('H:i', strtotime($iso)); }
function dinero($n): string { return '$' . number_format((float)$n, 2) . ' MXN'; }
function num($n): string { return rtrim(rtrim(number_format((float)$n, 1, '.', ''), '0'), '.'); }

function guardar_upload(array $f, string $prefijo, string $dir = TMP_PATH): array
{
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('no se recibió el archivo');
    if ($f['size'] > UPLOAD_MAX_BYTES) throw new RuntimeException('supera los 5 MB');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    if (!isset(UPLOAD_MIMES[$mime])) throw new RuntimeException('formato no permitido (usa PDF, JPG, PNG o WEBP)');
    @mkdir($dir, 0775, true);
    $nombre = $prefijo . '_' . bin2hex(random_bytes(8)) . '.' . UPLOAD_MIMES[$mime];
    if (!move_uploaded_file($f['tmp_name'], "$dir/$nombre")) throw new RuntimeException('no se pudo guardar');
    return ['ruta' => $nombre, 'mime' => $mime, 'nombre' => $f['name']];
}
function guardar_firma_dataurl(string $data, string $dir = TMP_PATH): ?array
{
    if (!preg_match('#^data:image/png;base64,([A-Za-z0-9+/=]+)$#', $data, $m)) return null;
    $bin = base64_decode($m[1], true);
    if (!$bin || strlen($bin) > UPLOAD_MAX_BYTES || !str_starts_with($bin, "\x89PNG")) return null;
    @mkdir($dir, 0775, true);
    $nombre = 'firma_' . bin2hex(random_bytes(8)) . '.png';
    file_put_contents("$dir/$nombre", $bin);
    return ['ruta' => $nombre, 'mime' => 'image/png', 'nombre' => 'firma.png'];
}
function confirmar_archivo(array $doc): string
{
    @mkdir(UPLOAD_PATH, 0775, true);
    $src = TMP_PATH . '/' . basename($doc['ruta']);
    if (is_file($src)) rename($src, UPLOAD_PATH . '/' . basename($doc['ruta']));
    return basename($doc['ruta']);
}
function procesar_documentos(array $requeridos, array &$docs, array &$E, string $etiquetaFirma): void
{
    foreach ($requeridos as $campo => $lbl) {
        if (!empty($_FILES[$campo]['name'])) {
            try { $docs[$campo] = guardar_upload($_FILES[$campo], $campo); }
            catch (RuntimeException $ex) { $E[$campo] = "$lbl: " . $ex->getMessage() . '.'; }
        } elseif (empty($docs[$campo])) $E[$campo] = "$lbl: adjunta el archivo.";
    }
    $f = null;
    if (!empty($_POST['firma_data'])) $f = guardar_firma_dataurl($_POST['firma_data']);
    elseif (!empty($_FILES['firma_file']['name'])) {
        try { $f = guardar_upload($_FILES['firma_file'], 'firma'); } catch (RuntimeException $ex) { $E['firma'] = 'Firma: ' . $ex->getMessage() . '.'; }
    }
    if ($f) $docs['firma'] = $f;
    elseif (empty($docs['firma']) && empty($E['firma'])) $E['firma'] = "Falta la $etiquetaFirma.";
}

function enviar_correo(string $para, string $asunto, string $cuerpo): bool
{
    if (CORREO_SIMULADO) return true;
    return false;
}
