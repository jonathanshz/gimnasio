<?php
const REG_PASOS = [1 => 'Código', 2 => 'Tipo', 3 => 'Datos', 4 => 'Cuenta', 5 => 'Verificar'];

function reg_cabecera(int $paso): void
{ ?>
<header class="reg-head"><a href="<?= url('index.php') ?>"><?= logo() ?></a>
  <ol class="steps" aria-label="Progreso del registro"><?php foreach (REG_PASOS as $n => $t): ?><li class="<?= $n < $paso ? 'done' : ($n === $paso ? 'on' : '') ?>"><span class="n mono"><?= $n < $paso ? '✓' : $n ?></span><span class="t"><?= $t ?></span></li><?php endforeach; ?></ol>
  <a href="<?= url('index.php') ?>" class="btn btn-ghost btn-sm">Cancelar</a></header>
<?php }

function reg_requiere(string ...$claves): array
{
    $r = $_SESSION['reg'] ?? [];
    if (empty($r['codigo_id']) || time() - ($r['t'] ?? 0) > 45 * 60) {
        unset($_SESSION['reg']);
        flash('error', 'Ingresa tu código de recepción para comenzar el registro.');
        redirect('registro/codigo.php');
    }
    foreach ($claves as $c) if (empty($r[$c])) redirect($c === 'tipo' ? 'registro/tipo.php' : 'registro/datos.php');
    return $r;
}

function bloque_identidad(array $v, array $E, string $leyenda, string $tipo, ?string $extra = null): string
{
    $val = fn($k) => e($v[$k] ?? '');
    return '<fieldset class="fieldset"><legend>' . $leyenda . '</legend><div class="form-grid">
    <div class="field col-4' . inv($E, 'nombre') . '"><label for="nombre">Nombre(s) <span class="req">*</span></label><input class="input upper" id="nombre" name="nombre" value="' . $val('nombre') . '" maxlength="60">' . err($E, 'nombre') . '</div>
    <div class="field col-4' . inv($E, 'apellido_paterno') . '"><label for="ap">Apellido paterno <span class="req">*</span></label><input class="input upper" id="ap" name="apellido_paterno" value="' . $val('apellido_paterno') . '" maxlength="60">' . err($E, 'apellido_paterno') . '</div>
    <div class="field col-4' . inv($E, 'apellido_materno') . '"><label for="am">Apellido materno <span class="req">*</span></label><input class="input upper" id="am" name="apellido_materno" value="' . $val('apellido_materno') . '" maxlength="60">' . err($E, 'apellido_materno') . '</div>
    <div class="field col-4' . inv($E, 'fecha_nacimiento') . '"><label for="fn">Fecha de nacimiento <span class="req">*</span></label>
      <input class="input mono" id="fn" name="fecha_nacimiento" value="' . $val('fecha_nacimiento') . '" placeholder="DD/MM/AAAA" inputmode="numeric" maxlength="10" data-date data-age-for="edad" data-tipo="' . ($tipo === 'menor' ? 'MENOR' : 'MAYOR') . '">
      ' . (isset($E['fecha_nacimiento']) ? err($E, 'fecha_nacimiento') : '<p class="hint">Formato DD/MM/AAAA</p>') . '</div>
    <div class="field col-2"><label for="edad">Edad <span class="req">*</span></label><input class="input mono" id="edad" name="edad" value="' . $val('edad') . '" readonly tabindex="-1"></div>
    ' . ($extra ?? '<div class="field col-3' . inv($E, 'genero') . '"><label for="genero">Género <span class="req">*</span></label><select class="input" id="genero" name="genero">' . opciones(CAT_GENERO, $v['genero'] ?? null) . '</select>' . err($E, 'genero') . '</div>
    <div class="field col-3' . inv($E, 'sexo') . '"><label for="sexo">Sexo <span class="req">*</span></label><select class="input" id="sexo" name="sexo">' . opciones(CAT_SEXO, $v['sexo'] ?? null) . '</select>' . err($E, 'sexo') . '</div>') . '
  </div></fieldset>';
}

function bloque_salud(array $v, array $E, array $docs, string $aviso, string $leyenda = '03 · Salud'): string
{
    return '<fieldset class="fieldset"><legend>' . $leyenda . '</legend><div class="form-grid">
    <div class="field col-6' . inv($E, 'servicio_medico') . '"><label for="sm">Servicio médico con el que cuenta <span class="req">*</span></label><select class="input" id="sm" name="servicio_medico">' . opciones(CAT_SERVICIO, $v['servicio_medico'] ?? null) . '</select>' . err($E, 'servicio_medico') . '</div>
    <div class="field col-6' . inv($E, 'enfermedad_cronica') . '"><label for="enf">¿Padece alguna enfermedad crónica? <span class="req">*</span></label><select class="input" id="enf" name="enfermedad_cronica" data-toggle-when="NINGUNA">' . opciones(CAT_ENF, $v['enfermedad_cronica'] ?? null) . '</select>' . err($E, 'enfermedad_cronica') . '</div>
    <div class="field col-12 hidden" data-show-if="enf" data-values="OTRA"><label for="enf_o">Especifique la enfermedad <span class="req">*</span></label><input class="input upper" id="enf_o" name="enfermedad_otra" value="' . e($v['enfermedad_otra'] ?? '') . '" maxlength="120">' . err($E, 'enfermedad_otra') . '</div>
    <div class="col-12 hidden" data-show-if="enf">' . alerta('warn', 'alert', $aviso, ' style="margin-bottom:12px"') . campo_upload('cert_medico', 'Constancia médica', 'PDF o imagen firmada por un médico · máx. 5 MB', $docs['cert_medico'] ?? null) . err($E, 'cert_medico') . '</div>
  </div></fieldset>';
}

function validar_persona(array $d, array &$E, string $tipo, array $op = []): array
{
    $v = ['nombre' => mayus($d['nombre'] ?? ''), 'apellido_paterno' => mayus($d['apellido_paterno'] ?? ''), 'apellido_materno' => mayus($d['apellido_materno'] ?? ''),
        'fecha_nacimiento' => trim($d['fecha_nacimiento'] ?? ''), 'edad' => '', 'fecha_iso' => null, 'genero' => $d['genero'] ?? '', 'sexo' => $d['sexo'] ?? '',
        'servicio_medico' => $d['servicio_medico'] ?? '', 'enfermedad_cronica' => $d['enfermedad_cronica'] ?? '', 'enfermedad_otra' => mayus($d['enfermedad_otra'] ?? '')];
    foreach (['nombre' => 'Nombre', 'apellido_paterno' => 'Apellido paterno', 'apellido_materno' => 'Apellido materno'] as $k => $l)
        if (!preg_match(RE_NOMBRE, $v[$k])) $E[$k] = "$l: solo letras en MAYÚSCULAS.";
    if (empty($op['sin_fecha'])) {
        $iso = parse_fecha_dmy($v['fecha_nacimiento']);
        if (!$iso) $E['fecha_nacimiento'] = 'Usa el formato DD/MM/AAAA con una fecha real.';
        else {
            $edad = edad_desde($iso); $v['edad'] = (string)$edad; $v['fecha_iso'] = $iso;
            if ($tipo === 'mayor' && $edad < 18) $E['fecha_nacimiento'] = 'Es menor de edad: regresa y elige “Menor de edad”.';
            if ($tipo === 'menor' && $edad >= 18) $E['fecha_nacimiento'] = 'Es mayor de edad: regresa y elige “Mayor de edad”.';
            if ($tipo === 'coach' && $edad < 18) $E['fecha_nacimiento'] = 'Para trabajar como coach debes ser mayor de edad.';
            if ($edad > 110) $E['fecha_nacimiento'] = 'Revisa el año de nacimiento.';
        }
    }
    if (empty($op['sin_genero'])) {
        if (!in_array($v['genero'], CAT_GENERO, true)) $E['genero'] = 'Selecciona un género.';
        if (!in_array($v['sexo'], CAT_SEXO, true)) $E['sexo'] = 'Selecciona el sexo.';
    }
    if (empty($op['sin_salud'])) {
        if (!in_array($v['servicio_medico'], CAT_SERVICIO, true)) $E['servicio_medico'] = 'Selecciona el servicio médico.';
        if (!in_array($v['enfermedad_cronica'], CAT_ENF, true)) $E['enfermedad_cronica'] = 'Indica si padece alguna enfermedad crónica.';
        if ($v['enfermedad_cronica'] === 'OTRA' && mb_strlen($v['enfermedad_otra']) < 3) $E['enfermedad_otra'] = 'Especifica la enfermedad.';
    }
    return $v;
}
