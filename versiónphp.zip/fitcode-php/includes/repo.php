<?php

function bitacora(string $actor, ?int $id, string $accion, string $modulo, ?string $detalle = null): void
{
    insertar('bitacora', ['usuario_id' => $actor === 'staff' ? $id : null, 'socio_id' => $actor === 'socio' ? $id : null, 'actor' => $actor,
        'accion' => $accion, 'modulo' => $modulo, 'detalle' => $detalle, 'ip' => $_SERVER['REMOTE_ADDR'] ?? 'cli', 'creado_en' => ahora()]);
}
function nombre_de(array $p): string { return trim("{$p['nombre']} {$p['apellido_paterno']} {$p['apellido_materno']}"); }
function esta_bloqueado(?array $row): bool { return $row && $row['bloqueado_hasta'] && $row['bloqueado_hasta'] > ahora(); }
function marcar_intento(string $tabla, ?array $row, bool $ok): void
{
    if (!$row) return;
    if ($ok) { q("UPDATE $tabla SET intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id = ?", [$row['id']]); return; }
    $n = (int)$row['intentos_fallidos'] + 1;
    if ($n >= 5) q("UPDATE $tabla SET intentos_fallidos = 0, bloqueado_hasta = ? WHERE id = ?", [mas_minutos(10), $row['id']]);
    else q("UPDATE $tabla SET intentos_fallidos = ? WHERE id = ?", [$n, $row['id']]);
}

final class Sesion
{
    public static function abrir(string $tipo, int $id): void
    {
        session_regenerate_id(true);
        insertar('sesiones', ['usuario_id' => $tipo === 'usuario' ? $id : null, 'socio_id' => $tipo === 'socio' ? $id : null, 'token_hash' => hash('sha256', session_id() . random_bytes(8)),
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'cli', 'creada_en' => ahora(), 'expira_en' => mas_minutos(480)]);
        if ($tipo === 'usuario') q('UPDATE usuarios SET ultimo_acceso = ? WHERE id = ?', [ahora(), $id]);
        $_SESSION[$tipo === 'socio' ? 'socio_id' : 'usuario_id'] = $id;
    }
    public static function cerrar(string $tipo): void
    {
        $id = $_SESSION[$tipo === 'socio' ? 'socio_id' : 'usuario_id'] ?? null;
        if ($id) q('UPDATE sesiones SET cerrada_en = ? WHERE ' . ($tipo === 'socio' ? 'socio_id' : 'usuario_id') . ' = ? AND cerrada_en IS NULL', [ahora(), $id]);
        unset($_SESSION[$tipo === 'socio' ? 'socio_id' : 'usuario_id']);
        session_regenerate_id(true);
    }
}

final class Socios
{
    public static function porId(int $id): ?array
    {
        $s = q1('SELECT * FROM socios WHERE id = ?', [$id]);
        if ($s) { $s['edad'] = edad_desde($s['fecha_nacimiento']); $s['nombre_completo'] = nombre_de($s); }
        return $s;
    }
    public static function login(string $ident, string $pw): array
    {
        $tel = preg_replace('/\D/', '', $ident);
        $s = q1('SELECT * FROM socios WHERE UPPER(usuario) = UPPER(?) OR LOWER(email) = LOWER(?) OR (telefono = ? AND LENGTH(?) = 10) LIMIT 1', [$ident, $ident, $tel, $tel]);
        if (esta_bloqueado($s)) return ['ok' => false, 'error' => 'Demasiados intentos fallidos. Por seguridad, espera 10 minutos o acude a recepción.'];
        $ok = password_verify($pw, $s['password_hash'] ?? hash_senuelo()) && $s && $s['activo'];
        marcar_intento('socios', $s, $ok);
        if (!$ok) return ['ok' => false, 'error' => 'Usuario o contraseña incorrectos.'];
        if (!$s['email_verificado_en']) return ['ok' => false, 'sin_verificar' => true, 'socio' => $s];
        Sesion::abrir('socio', (int)$s['id']);
        bitacora('socio', (int)$s['id'], 'login', 'auth');
        return ['ok' => true, 'socio' => $s];
    }
    public static function existeEmail(string $e): bool { return (bool)qv('SELECT (SELECT COUNT(*) FROM socios WHERE LOWER(email) = LOWER(?)) + (SELECT COUNT(*) FROM usuarios WHERE LOWER(email) = LOWER(?))', [$e, $e]); }
    public static function existeTelefono(string $t): bool { return (bool)qv('SELECT COUNT(*) FROM socios WHERE telefono = ?', [$t]); }
    public static function generarUsuario(string $n, string $ap, string $am, string $iso): string
    {
        $base = strtoupper(explode(' ', trim(quitar_acentos($n)))[0] . substr(quitar_acentos($ap), 0, 1) . substr(quitar_acentos($am), 0, 1)) . '-' . date('dmy', strtotime($iso));
        $u = $base;
        for ($i = 2; qv('SELECT COUNT(*) FROM socios WHERE usuario = ?', [$u]); $i++) $u = "$base-$i";
        return $u;
    }
    public static function crear(array $d, array $docs, int $codigoId): array
    {
        return transaccion(function () use ($d, $docs, $codigoId) {
            $id = insertar('socios', ['usuario' => $d['usuario'], 'nombre' => $d['nombre'], 'apellido_paterno' => $d['apellido_paterno'], 'apellido_materno' => $d['apellido_materno'],
                'apellidos' => "{$d['apellido_paterno']} {$d['apellido_materno']}", 'email' => $d['email'], 'telefono' => $d['telefono'], 'fecha_nacimiento' => $d['fecha_iso'],
                'genero' => $d['genero'], 'sexo' => $d['sexo'], 'tipo_socio' => $d['tipo'], 'tutor_nombre' => $d['tutor_nombre'] ?: null, 'servicio_medico' => $d['servicio_medico'],
                'enfermedad_cronica' => $d['enfermedad_cronica'], 'enfermedad_otra' => $d['enfermedad_cronica'] === 'OTRA' ? $d['enfermedad_otra'] : null,
                'contacto_emergencia' => $d['tutor_nombre'] ?: null, 'telefono_emergencia' => $d['tel_emergencia'], 'password_hash' => password_hash($d['password'], PASSWORD_DEFAULT), 'creado_en' => ahora()]);
            q('UPDATE socios SET codigo_credencial = ? WHERE id = ?', [generar_codigo_barras($id, hoy()), $id]);
            foreach ($docs as $tipo => $doc) insertar('socio_documentos', ['socio_id' => $id, 'tipo' => $tipo, 'ruta_archivo' => confirmar_archivo($doc), 'mime' => $doc['mime'], 'creado_en' => ahora()]);
            insertar('expedientes', ['socio_id' => $id, 'creado_en' => ahora(), 'actualizado_en' => ahora()]);
            q('UPDATE codigos_registro SET usado_por_socio_id = ?, usado_en = ? WHERE id = ? AND usado_en IS NULL', [$id, ahora(), $codigoId]);
            bitacora('socio', $id, 'registro', 'socios');
            return self::porId($id);
        });
    }
    public static function buscar(string $q): array
    {
        $w = array_filter(explode(' ', strtoupper(quitar_acentos($q))));
        $out = [];
        foreach (qa('SELECT * FROM socios ORDER BY nombre, apellido_paterno') as $s) {
            $t = strtoupper(quitar_acentos(nombre_de($s) . " {$s['usuario']} {$s['codigo_credencial']}"));
            foreach ($w as $x) if (!str_contains($t, $x)) continue 2;
            $s['edad'] = edad_desde($s['fecha_nacimiento']); $s['nombre_completo'] = nombre_de($s); $out[] = $s;
        }
        return $out;
    }
    public static function documentos(int $id): array { return qa('SELECT * FROM socio_documentos WHERE socio_id = ? ORDER BY id', [$id]); }
}

final class Codigos
{
    public static function validar(string $c): array
    {
        $_SESSION['intentos_codigo'] = array_filter($_SESSION['intentos_codigo'] ?? [], fn($t) => $t > time() - 600);
        if (count($_SESSION['intentos_codigo']) >= 5) return ['ok' => false, 'error' => 'Demasiados códigos inválidos. Espera 10 minutos o solicita uno nuevo en recepción.'];
        if (!preg_match('/^\d{6}$/', $c)) { $_SESSION['intentos_codigo'][] = time(); return ['ok' => false, 'error' => 'El código debe tener exactamente 6 dígitos (0-9).']; }
        $r = q1('SELECT id FROM codigos_registro WHERE codigo = ? AND usado_en IS NULL AND expira_en > ? ORDER BY id DESC LIMIT 1', [$c, ahora()]);
        $id = $r ? (int)$r['id'] : insertar('codigos_registro', ['codigo' => $c, 'creado_en' => ahora(), 'expira_en' => mas_minutos(72 * 60)]);
        return ['ok' => true, 'id' => $id];
    }
    public static function generar(int $usuarioId): string
    {
        $c = pad(random_int(0, 999999), 6);
        insertar('codigos_registro', ['codigo' => $c, 'generado_por' => $usuarioId, 'creado_en' => ahora(), 'expira_en' => mas_minutos(72 * 60)]);
        bitacora('staff', $usuarioId, 'generar_codigo', 'registro');
        return $c;
    }
    public static function listar(): array
    {
        return qa('SELECT c.*, u.nombre AS generado_por_nombre, s.usuario AS usado_por FROM codigos_registro c
                   LEFT JOIN usuarios u ON u.id = c.generado_por LEFT JOIN socios s ON s.id = c.usado_por_socio_id ORDER BY c.id DESC LIMIT 40');
    }
}

final class Verificacion
{
    private static function col(string $tipo): string { return $tipo === 'socio' ? 'socio_id' : 'usuario_id'; }
    public static function enviar(string $tipo, int $id): array
    {
        $col = self::col($tipo);
        $email = qv('SELECT email FROM ' . ($tipo === 'socio' ? 'socios' : 'usuarios') . ' WHERE id = ?', [$id]);
        $prev = q1("SELECT creado_en FROM verificaciones_correo WHERE $col = ? AND invalidado_en IS NULL AND verificado_en IS NULL ORDER BY id DESC LIMIT 1", [$id]);
        if ($prev && $prev['creado_en'] > mas_minutos(-1)) return ['ok' => false, 'error' => 'Espera un minuto antes de pedir otro código.'];
        q("UPDATE verificaciones_correo SET invalidado_en = ? WHERE $col = ? AND verificado_en IS NULL AND invalidado_en IS NULL", [ahora(), $id]);
        $codigo = pad(random_int(0, 999999), 6);
        insertar('verificaciones_correo', [$col => $id, 'email' => $email, 'codigo_hash' => hash('sha256', $codigo), 'codigo_demo' => CORREO_SIMULADO ? $codigo : null, 'creado_en' => ahora(), 'expira_en' => mas_minutos(15)]);
        enviar_correo($email, 'Tu código FIT CODE', "Tu código de verificación es $codigo. Vence en 15 minutos.");
        return ['ok' => true, 'email' => $email];
    }
    public static function vigente(string $tipo, int $id): ?array
    {
        $col = self::col($tipo);
        return q1("SELECT email, codigo_demo, expira_en FROM verificaciones_correo WHERE $col = ? AND verificado_en IS NULL AND invalidado_en IS NULL AND expira_en > ? ORDER BY id DESC LIMIT 1", [$id, ahora()]);
    }
    public static function confirmar(string $tipo, int $id, string $codigo): array
    {
        $col = self::col($tipo);
        $v = q1("SELECT * FROM verificaciones_correo WHERE $col = ? AND verificado_en IS NULL AND invalidado_en IS NULL ORDER BY id DESC LIMIT 1", [$id]);
        if (!$v) return ['ok' => false, 'error' => 'No hay un código vigente. Pide uno nuevo.'];
        if ($v['expira_en'] < ahora()) { q('UPDATE verificaciones_correo SET invalidado_en = ? WHERE id = ?', [ahora(), $v['id']]); return ['ok' => false, 'error' => 'El código expiró (15 min). Pide uno nuevo.']; }
        if (!hash_equals($v['codigo_hash'], hash('sha256', $codigo))) {
            $n = (int)$v['intentos'] + 1;
            q('UPDATE verificaciones_correo SET intentos = ?, invalidado_en = ? WHERE id = ?', [$n, $n >= 5 ? ahora() : null, $v['id']]);
            return ['ok' => false, 'error' => $n >= 5 ? 'Demasiados intentos. Pide un código nuevo.' : 'Código incorrecto. Te quedan ' . (5 - $n) . ' intento(s).'];
        }
        transaccion(function () use ($v, $tipo, $id) {
            q('UPDATE verificaciones_correo SET verificado_en = ? WHERE id = ?', [ahora(), $v['id']]);
            q('UPDATE ' . ($tipo === 'socio' ? 'socios' : 'usuarios') . ' SET email_verificado_en = ? WHERE id = ?', [ahora(), $id]);
        });
        return ['ok' => true];
    }
}

final class Personal
{
    private const SQL = 'SELECT u.*, u.id AS usuario_id, r.nombre AS rol, e.id AS empleado_id, e.numero_empleado, e.nombre AS e_nombre, e.apellido_paterno,
                                e.apellido_materno, e.rfc, e.estado, i.id AS instructor_id
                         FROM usuarios u JOIN roles r ON r.id = u.rol_id JOIN empleados e ON e.id = u.empleado_id
                         LEFT JOIN instructores i ON i.empleado_id = e.id';
    private static function vista(?array $u): ?array
    {
        if (!$u) return null;
        $u['nombre'] = trim("{$u['e_nombre']} {$u['apellido_paterno']} {$u['apellido_materno']}");
        $u['nombre_corto'] = explode(' ', $u['e_nombre'])[0];
        $u['verificado'] = (bool)$u['email_verificado_en'];
        return $u;
    }
    public static function login(string $ident, string $pw): array
    {
        $u = q1(self::SQL . " WHERE (UPPER(e.numero_empleado) = UPPER(?) OR LOWER(u.email) = LOWER(?)) AND r.nombre IN ('recepcion','instructor') LIMIT 1", [trim($ident), trim($ident)]);
        return self::validar($u, $pw, 'Número de empleado, correo o contraseña incorrectos.');
    }
    public static function loginAdmin(string $num, string $email, string $pw): array
    {
        $u = q1(self::SQL . " WHERE UPPER(e.numero_empleado) = UPPER(?) AND LOWER(u.email) = LOWER(?) AND r.nombre IN ('administrador','dueno') LIMIT 1", [trim($num), trim($email)]);
        return self::validar($u, $pw, 'Los datos de acceso no coinciden.');
    }
    private static function validar(?array $u, string $pw, string $msg): array
    {
        if (esta_bloqueado($u)) return ['ok' => false, 'error' => 'Cuenta bloqueada temporalmente por intentos fallidos. Espera 10 minutos.'];
        $ok = password_verify($pw, $u['password_hash'] ?? hash_senuelo()) && $u;
        if ($u) marcar_intento('usuarios', ['id' => $u['usuario_id'], 'intentos_fallidos' => $u['intentos_fallidos']], $ok);
        if (!$ok) return ['ok' => false, 'error' => $msg];
        if (!$u['email_verificado_en']) return ['ok' => false, 'sin_verificar' => true, 'usuario_id' => (int)$u['usuario_id']];
        if ($u['estado'] === 'pendiente') return ['ok' => false, 'error' => 'Tu cuenta está pendiente de aprobación por administración.'];
        if ($u['estado'] !== 'activo' || !$u['activo']) return ['ok' => false, 'error' => 'Tu cuenta está desactivada. Contacta a administración.'];
        Sesion::abrir('usuario', (int)$u['usuario_id']);
        bitacora('staff', (int)$u['usuario_id'], 'login', 'auth');
        return ['ok' => true, 'staff' => self::vista($u)];
    }
    public static function porUsuario(int $id): ?array { return self::vista(q1(self::SQL . ' WHERE u.id = ?', [$id])); }
    public static function sesionActiva(int $id): ?array
    {
        $v = self::porUsuario($id);
        return $v && $v['activo'] && $v['estado'] === 'activo' && $v['verificado'] ? $v : null;
    }
    public static function existeRFC(string $r): bool { return (bool)qv('SELECT COUNT(*) FROM empleados WHERE rfc = ?', [$r]); }
    public static function registrar(string $puesto, array $d, array $docs): array
    {
        return transaccion(function () use ($puesto, $d, $docs) {
            $pId = (int)qv('SELECT id FROM puestos WHERE clave = ?', [$puesto]);
            $n = (int)qv('SELECT COUNT(*) FROM empleados WHERE puesto_id = ?', [$pId]) + 1;
            $num = ($puesto === 'instructor' ? 'COA' : 'REC') . '-' . pad($n, 4);
            $e = insertar('empleados', ['numero_empleado' => $num, 'puesto_id' => $pId, 'nombre' => $d['nombre'], 'apellido_paterno' => $d['apellido_paterno'], 'apellido_materno' => $d['apellido_materno'],
                'apellidos' => "{$d['apellido_paterno']} {$d['apellido_materno']}", 'email' => $d['email'], 'telefono' => $d['telefono'], 'rfc' => $d['rfc'], 'fecha_nacimiento' => $d['fecha_iso'] ?? null,
                'telefono_emergencia' => $d['telefono_emergencia'] ?: null, 'servicio_medico' => $d['servicio_medico'] ?: null, 'enfermedad_cronica' => $d['enfermedad_cronica'] ?: null,
                'enfermedad_otra' => ($d['enfermedad_cronica'] ?? '') === 'OTRA' ? $d['enfermedad_otra'] : null, 'fecha_ingreso' => hoy(), 'estado' => 'pendiente', 'creado_en' => ahora()]);
            $u = insertar('usuarios', ['nombre' => nombre_de($d), 'email' => $d['email'], 'password_hash' => password_hash($d['password'], PASSWORD_DEFAULT),
                'rol_id' => qv('SELECT id FROM roles WHERE nombre = ?', [$puesto]), 'empleado_id' => $e, 'activo' => 0, 'creado_en' => ahora()]);
            if ($puesto === 'instructor') insertar('instructores', ['empleado_id' => $e]);
            foreach ($docs as $tipo => $doc) insertar('empleado_documentos', ['empleado_id' => $e, 'tipo' => $tipo, 'ruta_archivo' => confirmar_archivo($doc), 'mime' => $doc['mime'], 'creado_en' => ahora()]);
            return ['usuario_id' => $u, 'numero_empleado' => $num];
        });
    }
    public static function listar(): array
    {
        return array_map([self::class, 'vista'], qa(self::SQL . " ORDER BY CASE e.estado WHEN 'pendiente' THEN 0 WHEN 'activo' THEN 1 ELSE 2 END, e.numero_empleado"));
    }
    public static function cambiarEstado(int $empleadoId, string $estado, int $adminId): void
    {
        transaccion(function () use ($empleadoId, $estado, $adminId) {
            q('UPDATE empleados SET estado = ? WHERE id = ?', [$estado, $empleadoId]);
            q('UPDATE usuarios SET activo = ? WHERE empleado_id = ?', [$estado === 'activo' ? 1 : 0, $empleadoId]);
            bitacora('staff', $adminId, 'personal_' . $estado, 'personal', (string)$empleadoId);
        });
    }
    public static function documentos(int $empleadoId): array { return qa('SELECT * FROM empleado_documentos WHERE empleado_id = ? ORDER BY id', [$empleadoId]); }
}

final class Planes
{
    private static function x(array $p): array { $p['beneficios'] = explode("\n", (string)$p['beneficios_descripcion']); $p['precio'] = (float)$p['precio']; return $p; }
    public static function listar(): array { return array_map([self::class, 'x'], qa('SELECT * FROM tipos_membresia WHERE activo = 1 ORDER BY precio')); }
    public static function porId(int $id): ?array { $p = q1('SELECT * FROM tipos_membresia WHERE id = ? AND activo = 1', [$id]); return $p ? self::x($p) : null; }
}
final class Membresias
{
    private const SQL = 'SELECT m.*, t.nombre AS plan, t.precio, t.descripcion, t.beneficios_descripcion, t.duracion_dias FROM membresias m JOIN tipos_membresia t ON t.id = m.tipo_membresia_id';
    public static function enriquecer(array $m): array
    {
        $h = hoy(); $est = $m['estado'];
        if ($est === 'activa' && $h > $m['fecha_fin']) $est = 'vencida';
        if ($est === 'activa' && $h < $m['fecha_inicio']) $est = 'pendiente';
        $total = max(1, dias_entre($m['fecha_inicio'], $m['fecha_fin']) + 1);
        $restan = $h > $m['fecha_fin'] ? 0 : dias_entre(max($h, $m['fecha_inicio']), $m['fecha_fin']) + 1;
        return $m + ['estado_real' => $est, 'dias_totales' => $total, 'dias_restantes' => $restan, 'porcentaje' => (int)round(min(100, $restan / $total * 100)),
            'por_vencer' => $est === 'activa' && $restan <= 7, 'beneficios' => explode("\n", (string)$m['beneficios_descripcion'])];
    }
    public static function actual(int $socioId): ?array
    {
        $ms = array_map([self::class, 'enriquecer'], qa(self::SQL . " WHERE m.socio_id = ? AND m.estado <> 'cancelada' ORDER BY m.fecha_fin DESC, m.id DESC", [$socioId]));
        foreach ($ms as $m) if ($m['estado_real'] === 'activa') return $m;
        return $ms[0] ?? null;
    }
    public static function siguiente(int $socioId): ?array
    {
        $m = q1(self::SQL . " WHERE m.socio_id = ? AND m.estado = 'activa' AND m.fecha_inicio > ? ORDER BY m.fecha_inicio LIMIT 1", [$socioId, hoy()]);
        return $m ? self::enriquecer($m) : null;
    }
    public static function historial(int $socioId): array { return array_map([self::class, 'enriquecer'], qa(self::SQL . ' WHERE m.socio_id = ? ORDER BY m.fecha_inicio DESC, m.id DESC', [$socioId])); }
    public static function crear(int $socioId, int $tipoId): int
    {
        $t = q1('SELECT * FROM tipos_membresia WHERE id = ?', [$tipoId]);
        $fin = qv("SELECT MAX(fecha_fin) FROM membresias WHERE socio_id = ? AND estado = 'activa' AND fecha_fin >= ?", [$socioId, hoy()]);
        $ini = $fin ? mas_dias($fin, 1) : hoy();
        return insertar('membresias', ['socio_id' => $socioId, 'tipo_membresia_id' => $tipoId, 'fecha_inicio' => $ini, 'fecha_fin' => mas_dias($ini, $t['duracion_dias'] - 1),
            'estado' => 'activa', 'precio_aplicado' => $t['precio'], 'creado_en' => ahora()]);
    }
    public static function porVencer(): array
    {
        $out = [];
        foreach (qa('SELECT DISTINCT socio_id FROM membresias') as $r) { $m = self::actual((int)$r['socio_id']); if ($m && $m['por_vencer']) $out[] = $m; }
        return $out;
    }
}

final class Pagos
{
    private const SQL = 'SELECT p.*, s.nombre, s.apellido_paterno, s.apellido_materno, s.usuario AS socio_usuario, t.nombre AS plan,
                                m.fecha_inicio, m.fecha_fin, u.nombre AS cajero
                         FROM pagos p JOIN socios s ON s.id = p.socio_id JOIN tipos_membresia t ON t.id = p.tipo_membresia_id
                         LEFT JOIN membresias m ON m.id = p.membresia_id LEFT JOIN usuarios u ON u.id = p.usuario_id';
    private static function v(?array $p): ?array { if ($p) { $p['socio'] = nombre_de($p); $p['monto'] = (float)$p['monto']; } return $p; }
    private static function folio(): string { do { $f = 'R' . date('ymd') . strtoupper(bin2hex(random_bytes(3))); } while (qv('SELECT COUNT(*) FROM pagos WHERE folio = ?', [$f])); return $f; }
    private static function referencia(): string
    {
        $abc = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        do { $r = 'EF-'; for ($i = 0; $i < 8; $i++) $r .= $abc[random_int(0, 31)]; } while (qv('SELECT COUNT(*) FROM pagos WHERE referencia_pago = ?', [$r]));
        return $r;
    }
    private static function expirar(): void { q("UPDATE pagos SET estado = 'expirado' WHERE estado = 'pendiente' AND expira_en IS NOT NULL AND expira_en < ?", [ahora()]); }
    private static function nuevo(int $socioId, int $tipoId, string $metodo, ?int $usuarioId, array $extra = []): int
    {
        $t = Planes::porId($tipoId) ?? throw new InvalidArgumentException('Plan no válido');
        return insertar('pagos', ['folio' => self::folio(), 'socio_id' => $socioId, 'tipo_membresia_id' => $tipoId, 'concepto' => 'Membresía ' . $t['nombre'], 'monto' => $t['precio'],
            'metodo' => $metodo, 'usuario_id' => $usuarioId, 'estado' => 'pendiente', 'creado_en' => ahora()] + $extra);
    }
    private static function liquidar(int $pagoId, ?int $usuarioId, ?string $refExterna = null): array
    {
        transaccion(function () use ($pagoId, $usuarioId, $refExterna) {
            $p = q1('SELECT * FROM pagos WHERE id = ?', [$pagoId]);
            $st = q("UPDATE pagos SET estado = 'pagado', pagado_en = ?, usuario_id = COALESCE(?, usuario_id), referencia_externa = COALESCE(?, referencia_externa) WHERE id = ? AND estado = 'pendiente'",
                [ahora(), $usuarioId, $refExterna, $pagoId]);
            if ($st->rowCount() !== 1) throw new RuntimeException('El pago ya no está pendiente.');
            q('UPDATE pagos SET membresia_id = ? WHERE id = ?', [Membresias::crear((int)$p['socio_id'], (int)$p['tipo_membresia_id']), $pagoId]);
            insertar('detalle_pagos', ['pago_id' => $pagoId, 'descripcion' => $p['concepto'], 'precio_unitario' => $p['monto'], 'subtotal' => $p['monto']]);
            insertar('movimientos_contables', ['tipo' => 'ingreso', 'categoria_id' => qv("SELECT id FROM categorias_contables WHERE nombre = 'Membresías'"), 'fecha_movimiento' => ahora(),
                'concepto' => $p['concepto'], 'monto' => $p['monto'], 'pago_id' => $pagoId, 'usuario_id' => $usuarioId, 'referencia' => $p['folio']]);
            bitacora($usuarioId ? 'staff' : 'socio', $usuarioId ?: (int)$p['socio_id'], 'pago_' . $p['metodo'], 'pagos', $p['folio']);
        });
        return self::v(q1(self::SQL . ' WHERE p.id = ?', [$pagoId]));
    }
    public static function porSocio(int $socioId): array { self::expirar(); return array_map([self::class, 'v'], qa(self::SQL . ' WHERE p.socio_id = ? ORDER BY p.creado_en DESC, p.id DESC', [$socioId])); }
    public static function recibo(?int $socioId, string $folio): ?array
    {
        return $socioId === null ? self::v(q1(self::SQL . ' WHERE p.folio = ?', [$folio])) : self::v(q1(self::SQL . ' WHERE p.folio = ? AND p.socio_id = ?', [$folio, $socioId]));
    }
    public static function fichaPendiente(int $socioId): ?array { self::expirar(); return self::v(q1(self::SQL . " WHERE p.socio_id = ? AND p.metodo = 'efectivo' AND p.estado = 'pendiente' ORDER BY p.id DESC LIMIT 1", [$socioId])); }
    public static function pagarTarjeta(int $socioId, int $tipoId, string $marca, string $ultimos4, bool $aprobada): array
    {
        $id = self::nuevo($socioId, $tipoId, 'mercadopago', null, ['tarjeta_marca' => $marca, 'tarjeta_ultimos4' => $ultimos4]);
        if (!$aprobada) { q("UPDATE pagos SET estado = 'rechazado', observaciones = 'Rechazado por el banco (simulación)' WHERE id = ?", [$id]); return ['ok' => false, 'error' => 'El banco rechazó la tarjeta. Prueba con otra o paga en efectivo.']; }
        return ['ok' => true, 'pago' => self::liquidar($id, null, 'MP-SIM-' . time())];
    }
    public static function crearFicha(int $socioId, int $tipoId): array
    {
        q("UPDATE pagos SET estado = 'cancelado' WHERE socio_id = ? AND metodo = 'efectivo' AND estado = 'pendiente'", [$socioId]);
        $id = self::nuevo($socioId, $tipoId, 'efectivo', null, ['referencia_pago' => self::referencia(), 'expira_en' => mas_minutos(72 * 60)]);
        bitacora('socio', $socioId, 'ficha_efectivo', 'pagos');
        return self::v(q1(self::SQL . ' WHERE p.id = ?', [$id]));
    }
    public static function cancelarFicha(int $socioId, int $pagoId): void { q("UPDATE pagos SET estado = 'cancelado' WHERE id = ? AND socio_id = ? AND estado = 'pendiente'", [$pagoId, $socioId]); }
    public static function pendientesEfectivo(): array { self::expirar(); return array_map([self::class, 'v'], qa(self::SQL . " WHERE p.metodo = 'efectivo' AND p.estado = 'pendiente' ORDER BY p.creado_en")); }
    public static function cobrarFicha(string $ref, int $usuarioId): array
    {
        self::expirar();
        $ref = strtoupper(trim($ref));
        $p = q1('SELECT id, estado FROM pagos WHERE referencia_pago = ?', [$ref]);
        if (!$p) return ['ok' => false, 'error' => 'No existe una ficha con esa referencia.'];
        if ($p['estado'] !== 'pendiente') return ['ok' => false, 'error' => "La ficha $ref está {$p['estado']}."];
        return ['ok' => true, 'pago' => self::liquidar((int)$p['id'], $usuarioId)];
    }
    public static function cobroMostrador(int $socioId, int $tipoId, string $metodo, int $usuarioId): array
    {
        if (!in_array($metodo, ['efectivo', 'tarjeta'], true)) $metodo = 'efectivo';
        q("UPDATE pagos SET estado = 'cancelado' WHERE socio_id = ? AND metodo = 'efectivo' AND estado = 'pendiente'", [$socioId]);
        return self::liquidar(self::nuevo($socioId, $tipoId, $metodo, $usuarioId), $usuarioId);
    }
    public static function listar(int $limite = 60): array { self::expirar(); return array_map([self::class, 'v'], qa(self::SQL . " ORDER BY p.creado_en DESC, p.id DESC LIMIT $limite")); }
    public static function corte(string $fecha): array
    {
        return qa("SELECT metodo, COUNT(*) AS pagos, SUM(monto) AS total FROM pagos WHERE estado = 'pagado' AND pagado_en >= ? AND pagado_en < ? GROUP BY metodo",
            [$fecha . ' 00:00:00', mas_dias($fecha, 1) . ' 00:00:00']);
    }
    public static function ingresosDesde(string $desde): float { return (float)qv("SELECT COALESCE(SUM(monto),0) FROM pagos WHERE estado = 'pagado' AND pagado_en >= ?", [$desde]); }
}

final class Asistencias
{
    public static function visitas(int $socioId, int $n = 999): array
    {
        $v = []; $abierta = null;
        foreach (qa("SELECT tipo_movimiento, creado_en FROM asistencias WHERE socio_id = ? AND resultado = 'permitido' ORDER BY creado_en, id", [$socioId]) as $a) {
            if ($a['tipo_movimiento'] === 'entrada') { $v[] = ['entrada' => $a['creado_en'], 'salida' => null]; $abierta = count($v) - 1; }
            elseif ($abierta !== null) { $v[$abierta]['salida'] = $a['creado_en']; $abierta = null; }
        }
        return array_slice(array_reverse($v), 0, $n);
    }
    public static function dentro(int $socioId): ?array { $v = self::visitas($socioId, 1)[0] ?? null; return $v && !$v['salida'] ? $v : null; }
    public static function contarDesde(int $socioId, int $dias): int
    {
        return (int)qv("SELECT COUNT(*) FROM asistencias WHERE socio_id = ? AND resultado = 'permitido' AND tipo_movimiento = 'entrada' AND creado_en >= ?", [$socioId, mas_dias(hoy(), -$dias)]);
    }
    public static function escanear(string $codigo, int $usuarioId): array
    {
        $codigo = strtoupper(trim($codigo));
        $log = fn(?int $sid, string $res, ?string $mot, ?string $tipo) => insertar('asistencias', ['socio_id' => $sid, 'codigo_leido' => $codigo, 'resultado' => $res, 'motivo' => $mot, 'tipo_movimiento' => $tipo, 'registrado_por' => $usuarioId, 'creado_en' => ahora()]);
        if (!codigo_barras_valido($codigo)) { $log(null, 'codigo_invalido', 'Dígito verificador incorrecto', null); return ['ok' => false, 'motivo' => 'Código de barras no válido o mal leído.']; }
        $s = q1('SELECT id FROM socios WHERE codigo_credencial = ?', [$codigo]);
        if (!$s) { $log(null, 'codigo_invalido', 'No pertenece a ningún socio', null); return ['ok' => false, 'motivo' => 'El código no pertenece a ningún socio.']; }
        $sid = (int)$s['id']; $socio = Socios::porId($sid); $m = Membresias::actual($sid); $dentro = self::dentro($sid);
        if ($dentro) { $log($sid, 'permitido', null, 'salida'); return ['ok' => true, 'tipo' => 'SALIDA', 'socio' => $socio, 'm' => $m, 'hora' => ahora(), 'minutos' => (int)round((time() - strtotime($dentro['entrada'])) / 60)]; }
        if (!$m || $m['estado_real'] !== 'activa') {
            $mot = !$m ? 'El socio no tiene membresía asignada.' : "Membresía {$m['estado_real']} (vence " . fecha_mx($m['fecha_fin']) . ').';
            $log($sid, $m ? 'membresia_vencida' : 'sin_membresia', $mot, 'entrada');
            return ['ok' => false, 'socio' => $socio, 'motivo' => $mot];
        }
        $log($sid, 'permitido', null, 'entrada');
        return ['ok' => true, 'tipo' => 'ENTRADA', 'socio' => $socio, 'm' => $m, 'hora' => ahora()];
    }
    public static function delDia(string $fecha): array
    {
        return qa('SELECT a.*, s.nombre, s.apellido_paterno, s.apellido_materno, u.nombre AS registro FROM asistencias a LEFT JOIN socios s ON s.id = a.socio_id
                   LEFT JOIN usuarios u ON u.id = a.registrado_por WHERE a.creado_en >= ? AND a.creado_en < ? ORDER BY a.creado_en DESC, a.id DESC', [$fecha . ' 00:00:00', mas_dias($fecha, 1) . ' 00:00:00']);
    }
    public static function recientes(int $n): array
    {
        return qa("SELECT a.*, s.nombre, s.apellido_paterno, s.apellido_materno FROM asistencias a JOIN socios s ON s.id = a.socio_id WHERE a.resultado = 'permitido' ORDER BY a.creado_en DESC, a.id DESC LIMIT $n");
    }
    public static function kpisHoy(): array
    {
        $h = hoy() . ' 00:00:00'; $dentro = 0;
        foreach (qa("SELECT DISTINCT socio_id FROM asistencias WHERE creado_en >= ? AND socio_id IS NOT NULL", [$h]) as $r) if (self::dentro((int)$r['socio_id'])) $dentro++;
        return ['dentro' => $dentro,
            'entradas' => (int)qv("SELECT COUNT(*) FROM asistencias WHERE resultado = 'permitido' AND tipo_movimiento = 'entrada' AND creado_en >= ?", [$h]),
            'rechazos' => (int)qv("SELECT COUNT(*) FROM asistencias WHERE resultado <> 'permitido' AND creado_en >= ?", [$h])];
    }
    public static function afluenciaPorHora(): array
    {
        $h = array_fill(5, 18, 0);
        foreach (qa("SELECT creado_en FROM asistencias WHERE resultado = 'permitido' AND tipo_movimiento = 'entrada' AND creado_en >= ?", [mas_dias(hoy(), -30)]) as $a) {
            $x = (int)date('G', strtotime($a['creado_en'])); if (isset($h[$x])) $h[$x]++;
        }
        return $h;
    }
}

final class Equipos
{
    public static function listar(): array
    {
        return array_map(function ($e) {
            $e['disponibilidad'] = $e['estado'] === 'mantenimiento' ? 'MANTENIMIENTO' : ($e['en_uso'] ? 'OCUPADA' : 'LIBRE');
            return $e;
        }, qa("SELECT e.*, (SELECT COUNT(*) FROM uso_equipos u WHERE u.equipo_id = e.id AND u.fin IS NULL) AS en_uso FROM equipos e WHERE e.estado <> 'baja' ORDER BY e.ubicacion, e.nombre"));
    }
    public static function alternarUso(int $id, ?int $usuarioId = null): void
    {
        $u = q1('SELECT id FROM uso_equipos WHERE equipo_id = ? AND fin IS NULL', [$id]);
        if ($u) q('UPDATE uso_equipos SET fin = ? WHERE id = ?', [ahora(), $u['id']]);
        else insertar('uso_equipos', ['equipo_id' => $id, 'inicio' => ahora(), 'registrado_por' => $usuarioId]);
    }
    public static function simularMovimiento(): void
    {
        $ok = qa("SELECT id FROM equipos WHERE estado = 'operativo'");
        if ($ok) self::alternarUso((int)$ok[array_rand($ok)]['id']);
    }
    public static function cambiarEstado(int $id, string $estado, int $usuarioId): void
    {
        if (!in_array($estado, ['operativo', 'mantenimiento'], true)) return;
        q('UPDATE equipos SET estado = ? WHERE id = ?', [$estado, $id]);
        if ($estado === 'mantenimiento') q('UPDATE uso_equipos SET fin = ? WHERE equipo_id = ? AND fin IS NULL', [ahora(), $id]);
        bitacora('staff', $usuarioId, 'equipo_' . $estado, 'equipos', (string)$id);
    }
}

final class Expedientes
{
    public static function obtener(int $socioId): ?array { return q1('SELECT * FROM expedientes WHERE socio_id = ?', [$socioId]); }
    public static function guardar(int $socioId, array $d, ?int $usuarioId): void
    {
        if (!self::obtener($socioId)) insertar('expedientes', ['socio_id' => $socioId, 'creado_en' => ahora(), 'actualizado_en' => ahora()]);
        q('UPDATE expedientes SET objetivo_principal = ?, nivel = ?, dias_entrenamiento = ?, actualizado_por = ?, actualizado_en = ? WHERE socio_id = ?',
            [$d['objetivo'], $d['nivel'], (int)$d['dias'], $usuarioId, ahora(), $socioId]);
    }
}
final class Mediciones
{
    public static function porSocio(int $socioId): array
    {
        return qa('SELECT m.* FROM mediciones m JOIN expedientes e ON e.id = m.expediente_id WHERE e.socio_id = ? ORDER BY m.fecha_medicion, m.id', [$socioId]);
    }
    public static function registrar(int $socioId, array $d, ?int $usuarioId): array
    {
        $exp = Expedientes::obtener($socioId);
        if (!$exp) { insertar('expedientes', ['socio_id' => $socioId, 'creado_en' => ahora(), 'actualizado_en' => ahora()]); $exp = Expedientes::obtener($socioId); }
        $imc = imc((float)$d['peso'], (float)$d['estatura']);
        insertar('mediciones', ['expediente_id' => $exp['id'], 'fecha_medicion' => ahora(), 'peso_kg' => (float)$d['peso'], 'estatura_cm' => (float)$d['estatura'], 'imc' => $imc,
            'porcentaje_grasa' => ($d['grasa'] ?? '') === '' ? null : (float)$d['grasa'], 'porcentaje_musculo' => ($d['musculo'] ?? '') === '' ? null : (float)$d['musculo'], 'registrado_por' => $usuarioId]);
        return ['imc' => $imc];
    }
}
final class Rutinas
{
    public static function asignada(int $socioId): ?array
    {
        $rs = q1("SELECT rs.*, r.nombre, r.objetivo, e.nombre AS c_nombre, e.apellido_paterno AS c_ap FROM rutinas_socio rs JOIN rutinas r ON r.id = rs.rutina_id
                  LEFT JOIN instructores i ON i.id = rs.instructor_id LEFT JOIN empleados e ON e.id = i.empleado_id
                  WHERE rs.socio_id = ? AND rs.estado = 'activa' ORDER BY rs.fecha_inicio DESC, rs.id DESC LIMIT 1", [$socioId]);
        if (!$rs) return null;
        $dias = [];
        foreach (qa('SELECT re.*, ej.nombre AS ejercicio FROM rutina_ejercicios re JOIN ejercicios ej ON ej.id = re.ejercicio_id WHERE re.rutina_id = ? ORDER BY re.dia_numero, re.orden', [$rs['rutina_id']]) as $x) {
            $dias[$x['dia_numero']] ??= ['dia_numero' => $x['dia_numero'], 'enfoque' => $x['enfoque'], 'ejercicios' => []];
            $dias[$x['dia_numero']]['ejercicios'][] = $x;
        }
        return ['id' => $rs['id'], 'nombre' => $rs['nombre'], 'desde' => $rs['fecha_inicio'], 'coach' => $rs['c_nombre'] ? "{$rs['c_nombre']} {$rs['c_ap']}" : 'Coach', 'dias' => array_values($dias)];
    }
    public static function asignar_plan(int $socioId, array $plan, array $staff): void
    {
        transaccion(function () use ($socioId, $plan, $staff) {
            q("UPDATE rutinas_socio SET estado = 'finalizada', fecha_fin = ? WHERE socio_id = ? AND estado = 'activa'", [hoy(), $socioId]);
            $r = insertar('rutinas', ['nombre' => $plan['nombre'], 'objetivo' => $plan['objetivo'], 'nivel' => $plan['nivel'], 'dias_por_semana' => $plan['dias'], 'creador_usuario_id' => $staff['usuario_id'], 'es_plantilla' => 0, 'creada_en' => ahora()]);
            foreach ($plan['semana'] as $i => $d) foreach ($d['ejercicios'] as $o => $x) {
                $ej = qv('SELECT id FROM ejercicios WHERE nombre = ?', [$x['nombre']]) ?: insertar('ejercicios', ['nombre' => $x['nombre']]);
                insertar('rutina_ejercicios', ['rutina_id' => $r, 'ejercicio_id' => $ej, 'dia_numero' => $i + 1, 'enfoque' => $d['enfoque'], 'orden' => $o + 1, 'series' => $x['series'], 'repeticiones' => $x['reps'], 'descanso_segundos' => $x['descanso']]);
            }
            insertar('rutinas_socio', ['socio_id' => $socioId, 'rutina_id' => $r, 'instructor_id' => $staff['instructor_id'], 'fecha_inicio' => hoy(), 'estado' => 'activa', 'asignada_en' => ahora()]);
            bitacora('staff', (int)$staff['usuario_id'], 'asignar_rutina', 'rutinas', (string)$socioId);
        });
    }
    public static function finalizar(int $id): void { q("UPDATE rutinas_socio SET estado = 'finalizada', fecha_fin = ? WHERE id = ?", [hoy(), $id]); }
}

function datos_fitness(array $s): ?array
{
    $exp = Expedientes::obtener((int)$s['id']); $meds = Mediciones::porSocio((int)$s['id']); $u = end($meds) ?: null;
    if (!$exp || !$exp['objetivo_principal'] || !$u) return null;
    return ['exp' => $exp, 'meds' => $meds, 'u' => $u, 'objetivo' => $exp['objetivo_principal'], 'nivel' => $exp['nivel'] ?: 'principiante', 'dias' => (int)($exp['dias_entrenamiento'] ?: 3),
        'edad' => $s['edad'], 'sexo' => $s['sexo'], 'peso' => (float)$u['peso_kg'], 'estatura' => (float)$u['estatura_cm']];
}
