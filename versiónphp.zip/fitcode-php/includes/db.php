<?php

function db(): PDO
{
    static $pdo = null;
    if ($pdo) return $pdo;
    $op = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];
    if (DB_DRIVER === 'mysql') {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, $op);
        return $pdo;
    }
    $nueva = !is_file(DB_SQLITE_FILE);
    @mkdir(dirname(DB_SQLITE_FILE), 0775, true);
    $pdo = new PDO('sqlite:' . DB_SQLITE_FILE, null, null, $op);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA journal_mode = WAL');
    if ($nueva) {
        $pdo->beginTransaction();
        foreach (esquema_sql('sqlite') as $sql) $pdo->exec($sql);
        semilla();
        $pdo->commit();
    }
    return $pdo;
}
function q(string $sql, array $p = []): PDOStatement { $st = db()->prepare($sql); $st->execute($p); return $st; }
function q1(string $sql, array $p = []): ?array { return q($sql, $p)->fetch() ?: null; }
function qv(string $sql, array $p = []) { return q($sql, $p)->fetchColumn(); }
function qa(string $sql, array $p = []): array { return q($sql, $p)->fetchAll(); }
function insertar(string $tabla, array $fila): int
{
    $cols = array_keys($fila);
    q("INSERT INTO $tabla (" . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')', array_values($fila));
    return (int)db()->lastInsertId();
}
function transaccion(callable $fn)
{
    $pdo = db(); $propia = !$pdo->inTransaction();
    if ($propia) $pdo->beginTransaction();
    try { $r = $fn(); if ($propia) $pdo->commit(); return $r; }
    catch (Throwable $e) { if ($propia) $pdo->rollBack(); throw $e; }
}

function semilla(): void
{
    $now = ahora(); $f = fn(int $d) => mas_dias(hoy(), $d);
    foreach (['dueno', 'administrador', 'recepcion', 'instructor', 'socio'] as $r) insertar('roles', ['nombre' => $r]);
    foreach ([['dueno', 'Dueño'], ['administrador', 'Administrador'], ['recepcion', 'Recepcionista'], ['instructor', 'Coach']] as [$c, $n]) insertar('puestos', ['clave' => $c, 'nombre' => $n]);
    foreach ([['activa', 'Activa', 1], ['pendiente', 'Pendiente', 0], ['vencida', 'Vencida', 0], ['cancelada', 'Cancelada', 0], ['congelada', 'Congelada', 0]] as [$c, $n, $a]) insertar('estados_membresia', ['codigo' => $c, 'nombre' => $n, 'permite_acceso' => $a]);
    foreach ([['efectivo', 'Efectivo', 0], ['tarjeta', 'Tarjeta en terminal', 1], ['mercadopago', 'Tarjeta en línea', 1], ['transferencia', 'Transferencia', 1]] as [$c, $n, $r]) insertar('metodos_pago', ['codigo' => $c, 'nombre' => $n, 'requiere_referencia' => $r]);
    foreach ([['permitido', 'Permitido', 1], ['membresia_vencida', 'Membresía vencida', 0], ['sin_membresia', 'Sin membresía', 0], ['codigo_invalido', 'Código inválido', 0]] as [$c, $n, $a]) insertar('resultados_acceso', ['codigo' => $c, 'nombre' => $n, 'acceso_permitido' => $a]);
    foreach ([['operativo', 'Operativo', 1], ['mantenimiento', 'En mantenimiento', 0], ['baja', 'Dado de baja', 0]] as [$c, $n, $d]) insertar('estados_equipo', ['codigo' => $c, 'nombre' => $n, 'disponible_uso' => $d]);
    insertar('categorias_contables', ['nombre' => 'Membresías', 'tipo' => 'ingreso']);

    $staff = [
        ['dueno', 'DUE-0001', 'ROBERTO', 'MÉNDEZ', 'SALAS', 'dueno@fitcode.mx', 'MESR800101', 'Dueno#2026'],
        ['administrador', 'ADM-0001', 'LAURA', 'GÓMEZ', 'TREJO', 'admin@fitcode.mx', 'GOTL900215', 'Admin#2026'],
        ['recepcion', 'REC-0001', 'DIANA', 'CRUZ', 'VEGA', 'recepcion@fitcode.mx', 'CUVD980712', 'Recep#2026'],
        ['instructor', 'COA-0001', 'CARLOS', 'RUIZ', 'ORTEGA', 'coach@fitcode.mx', 'RUOC920304', 'Coach#2026'],
    ];
    foreach ($staff as [$rol, $num, $n, $ap, $am, $mail, $rfc, $pw]) {
        $e = insertar('empleados', ['numero_empleado' => $num, 'puesto_id' => qv('SELECT id FROM puestos WHERE clave = ?', [$rol]), 'nombre' => $n, 'apellido_paterno' => $ap, 'apellido_materno' => $am, 'apellidos' => "$ap $am", 'email' => $mail, 'telefono' => '5550000000', 'rfc' => $rfc, 'fecha_ingreso' => '2025-01-15', 'estado' => 'activo', 'creado_en' => $now]);
        insertar('usuarios', ['nombre' => "$n $ap $am", 'email' => $mail, 'password_hash' => password_hash($pw, PASSWORD_DEFAULT), 'email_verificado_en' => $now, 'rol_id' => qv('SELECT id FROM roles WHERE nombre = ?', [$rol]), 'empleado_id' => $e, 'activo' => 1, 'creado_en' => $now]);
        if ($rol === 'instructor') insertar('instructores', ['empleado_id' => $e, 'especialidad' => 'Hipertrofia y fuerza']);
    }
    foreach ([['Visita', 1, 80, 'Acceso por un día.', "Acceso a piso de pesas\nRegaderas"],
              ['Mensual', 30, 549, 'El plan base para entrenar todo el mes.', "Acceso ilimitado\nEvaluación inicial\nApp FIT CODE"],
              ['Trimestral', 90, 1499, 'Tres meses con precio preferente.', "Todo lo del Mensual\n1 rutina personalizada\nMedición mensual"],
              ['Anual', 365, 5490, 'Doce meses al mejor precio.', "Todo lo del Trimestral\nClases grupales\nCasillero fijo\n2 pases de invitado al mes"],
              ['Estudiante', 30, 399, 'Mensual con credencial vigente.', "Acceso L–V 6:00–16:00\nApp FIT CODE"]] as $p)
        insertar('tipos_membresia', ['nombre' => $p[0], 'duracion_dias' => $p[1], 'precio' => $p[2], 'descripcion' => $p[3], 'beneficios_descripcion' => $p[4]]);

    $pw = password_hash('Socio#2026', PASSWORD_DEFAULT);
    foreach ([['ANAPP-150398', 'ana@demo.mx', '5512345678', 'mayor', 'ANA', 'PÉREZ', 'PÉREZ', '1998-03-15', 'FEMENINO', 'MUJER', 'IMSS', 'NINGUNA', null, '2026-03-01'],
              ['LUISRM-020901', 'luis@demo.mx', '5587654321', 'mayor', 'LUIS', 'RAMÍREZ', 'MORA', '2001-09-02', 'MASCULINO', 'HOMBRE', 'ISSSTE', 'ASMA', null, '2026-06-10'],
              ['SOFIAHL-110510', 'sofia@demo.mx', '5511122233', 'menor', 'SOFÍA', 'HERNÁNDEZ', 'LUNA', '2010-05-11', 'FEMENINO', 'MUJER', 'IMSS', 'NINGUNA', 'MARTHA LUNA RÍOS', '2026-08-20']] as $s) {
        $id = insertar('socios', ['usuario' => $s[0], 'email' => $s[1], 'telefono' => $s[2], 'tipo_socio' => $s[3], 'nombre' => $s[4], 'apellido_paterno' => $s[5], 'apellido_materno' => $s[6], 'apellidos' => "$s[5] $s[6]", 'fecha_nacimiento' => $s[7], 'genero' => $s[8], 'sexo' => $s[9], 'servicio_medico' => $s[10], 'enfermedad_cronica' => $s[11], 'tutor_nombre' => $s[12], 'contacto_emergencia' => $s[12], 'telefono_emergencia' => '5500000000', 'password_hash' => $pw, 'email_verificado_en' => $now, 'creado_en' => "$s[13] 10:00:00"]);
        q('UPDATE socios SET codigo_credencial = ? WHERE id = ?', [generar_codigo_barras($id, $s[13]), $id]);
        insertar('expedientes', ['socio_id' => $id, 'creado_en' => $now, 'actualizado_en' => $now]);
    }
    $pago = function (int $sid, int $tipo, string $ini, string $metodo) {
        $p = q1('SELECT * FROM tipos_membresia WHERE id = ?', [$tipo]);
        $fin = mas_dias($ini, $p['duracion_dias'] - 1);
        $m = insertar('membresias', ['socio_id' => $sid, 'tipo_membresia_id' => $tipo, 'fecha_inicio' => $ini, 'fecha_fin' => $fin, 'estado' => $fin < hoy() ? 'vencida' : 'activa', 'precio_aplicado' => $p['precio'], 'creado_en' => "$ini 09:30:00"]);
        $pg = insertar('pagos', ['folio' => 'R' . str_replace('-', '', substr($ini, 2)) . strtoupper(dechex(0xA1B2C0 + $sid * 7 + $tipo)), 'socio_id' => $sid, 'membresia_id' => $m, 'tipo_membresia_id' => $tipo, 'concepto' => 'Membresía ' . $p['nombre'], 'monto' => $p['precio'], 'metodo' => $metodo, 'usuario_id' => 3, 'estado' => 'pagado', 'tarjeta_marca' => $metodo === 'tarjeta' ? 'VISA' : null, 'tarjeta_ultimos4' => $metodo === 'tarjeta' ? '4242' : null, 'creado_en' => "$ini 09:30:00", 'pagado_en' => "$ini 09:30:00"]);
        insertar('detalle_pagos', ['pago_id' => $pg, 'descripcion' => 'Membresía ' . $p['nombre'], 'precio_unitario' => $p['precio'], 'subtotal' => $p['precio']]);
    };
    $pago(1, 2, $f(-90), 'efectivo'); $pago(1, 3, $f(-60), 'tarjeta'); $pago(2, 2, $f(-26), 'efectivo'); $pago(3, 5, $f(-40), 'transferencia');
    foreach ([[1, 18], [2, 9], [3, 4]] as [$sid, $n]) {
        $cod = qv('SELECT codigo_credencial FROM socios WHERE id = ?', [$sid]);
        for ($i = $n; $i >= 1; $i--) {
            $e = strtotime($f(-($i * 2 - ($sid % 2)))) + (6 + ($i * 3 + $sid) % 12) * 3600 + (($i * 7) % 60) * 60;
            $s = $e + (55 + ($i * 11) % 50) * 60;
            insertar('asistencias', ['socio_id' => $sid, 'codigo_leido' => $cod, 'resultado' => 'permitido', 'tipo_movimiento' => 'entrada', 'registrado_por' => 3, 'creado_en' => date('Y-m-d H:i:s', $e)]);
            insertar('asistencias', ['socio_id' => $sid, 'codigo_leido' => $cod, 'resultado' => 'permitido', 'tipo_movimiento' => 'salida', 'registrado_por' => 3, 'creado_en' => date('Y-m-d H:i:s', $s)]);
        }
    }
    foreach ([['Caminadora 01', 'Cardio', 1], ['Caminadora 02', 'Cardio', 0], ['Caminadora 03', 'Cardio', 0], ['Elíptica 01', 'Cardio', 1], ['Bicicleta fija 01', 'Cardio', 0], ['Remo 01', 'Cardio', 2],
              ['Rack de sentadilla 01', 'Pesas libres', 1], ['Rack de sentadilla 02', 'Pesas libres', 0], ['Banco plano 01', 'Pesas libres', 0], ['Banco inclinado 01', 'Pesas libres', 1],
              ['Prensa de pierna', 'Máquinas', 0], ['Polea alta', 'Máquinas', 1], ['Extensión de pierna', 'Máquinas', 0], ['Smith', 'Máquinas', 0], ['Peck deck', 'Máquinas', 0], ['Remo sentado', 'Máquinas', 1]] as [$n, $z, $st]) {
        $id = insertar('equipos', ['nombre' => $n, 'ubicacion' => $z, 'estado' => $st === 2 ? 'mantenimiento' : 'operativo']);
        if ($st === 1) insertar('uso_equipos', ['equipo_id' => $id, 'inicio' => $now, 'registrado_por' => 3]);
    }
    q("UPDATE expedientes SET objetivo_principal = 'recomposicion', nivel = 'intermedio', dias_entrenamiento = 4, actualizado_por = 4 WHERE socio_id = 1");
    foreach ([[-60, 70.1, 25.4, 30.1], [-30, 68.5, 24.1, 30.9], [-3, 67.2, 23.0, 31.6]] as [$d, $p, $g, $mu])
        insertar('mediciones', ['expediente_id' => 1, 'fecha_medicion' => $f($d) . ' 08:00:00', 'peso_kg' => $p, 'estatura_cm' => 165, 'imc' => imc($p, 165), 'porcentaje_grasa' => $g, 'porcentaje_musculo' => $mu, 'registrado_por' => 4]);
    Rutinas::asignar_plan(1, generar_plan(['objetivo' => 'recomposicion', 'nivel' => 'intermedio', 'dias' => 4, 'edad' => 28, 'sexo' => 'MUJER', 'peso' => 67.2, 'estatura' => 165]), ['usuario_id' => 4, 'instructor_id' => 1]);
    q('UPDATE rutinas_socio SET fecha_inicio = ? WHERE id = 1', [$f(-14)]);
    foreach ([['482915', -1], ['731004', -2]] as [$c, $d]) insertar('codigos_registro', ['codigo' => $c, 'generado_por' => 3, 'creado_en' => $f($d) . ' 12:00:00', 'expira_en' => $f($d + 3) . ' 12:00:00']);
    q('DELETE FROM bitacora');
}
