<?php
const OBJETIVOS = [
    'perder_grasa'  => ['nombre' => 'Perder grasa', 'desc' => 'Bajar % de grasa conservando músculo.', 'icono' => 'bolt'],
    'ganar_musculo' => ['nombre' => 'Ganar músculo', 'desc' => 'Aumentar masa muscular (hipertrofia).', 'icono' => 'dumbbell'],
    'recomposicion' => ['nombre' => 'Recomposición corporal', 'desc' => 'Perder grasa y ganar músculo a la vez.', 'icono' => 'swap'],
    'fuerza'        => ['nombre' => 'Ganar fuerza', 'desc' => 'Levantar más peso en los básicos.', 'icono' => 'shield'],
    'resistencia'   => ['nombre' => 'Resistencia y condición', 'desc' => 'Mejorar capacidad cardiovascular.', 'icono' => 'refresh'],
    'salud'         => ['nombre' => 'Salud y movilidad', 'desc' => 'Moverte mejor y sentirte bien.', 'icono' => 'check'],
];
const NIVELES = ['principiante' => 'Principiante', 'intermedio' => 'Intermedio', 'avanzado' => 'Avanzado'];
const DIAS_SEMANA = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'];

function imc(float $peso, float $estatura): ?float
{
    $m = $estatura / 100;
    return $m > 0 ? round($peso / ($m * $m), 1) : null;
}

function categoria_imc(?float $v, int $edad): array
{
    if ($v === null) return ['—', 'mute'];
    if ($edad < 18) return ['Menor de edad: se interpreta con percentiles OMS', 'mute'];
    if ($v < 18.5) return ['Bajo peso', 'warn'];
    if ($v < 25) return ['Peso normal', 'ok'];
    if ($v < 30) return ['Sobrepeso', 'warn'];
    return ['Obesidad', 'bad'];
}

const BANCO = [
    'empuje_h'    => ['Press de pecho en máquina', 'Press de banca con mancuernas', 'Press de banca con barra', 'Press de pecho en máquina'],
    'empuje_inc'  => ['Press inclinado en máquina', 'Press inclinado con mancuernas', 'Press inclinado con barra'],
    'empuje_v'    => ['Press de hombro en máquina', 'Press militar con mancuernas', 'Press militar con barra', 'Press de hombro en máquina'],
    'tiron_v'     => ['Jalón al pecho en polea', 'Dominadas asistidas', 'Dominadas', 'Jalón al pecho en polea'],
    'tiron_h'     => ['Remo sentado en polea', 'Remo con mancuerna a una mano', 'Remo con barra', 'Remo sentado en polea'],
    'lateral'     => ['Elevaciones laterales con mancuerna', 'Elevaciones laterales con mancuerna', 'Elevaciones laterales en polea'],
    'pecho_ais'   => ['Aperturas en peck deck', 'Aperturas en polea', 'Aperturas con mancuernas'],
    'posterior'   => ['Face pull en polea', 'Face pull en polea', 'Pájaros con mancuerna'],
    'triceps'     => ['Extensión de tríceps en polea', 'Extensión de tríceps en polea', 'Press francés con barra Z'],
    'biceps'      => ['Curl de bíceps con mancuernas', 'Curl martillo', 'Curl con barra'],
    'cuadriceps'  => ['Prensa de pierna', 'Sentadilla goblet', 'Sentadilla con barra', 'Prensa de pierna'],
    'bisagra'     => ['Peso muerto rumano con mancuernas', 'Peso muerto rumano con barra', 'Peso muerto convencional', 'Peso muerto rumano con mancuernas'],
    'gluteo'      => ['Puente de glúteo', 'Hip thrust con barra', 'Hip thrust con barra'],
    'unilateral'  => ['Zancadas asistidas', 'Zancadas con mancuernas', 'Sentadilla búlgara', 'Step-up a cajón bajo'],
    'ext_pierna'  => ['Extensión de pierna en máquina', 'Extensión de pierna en máquina', 'Extensión de pierna en máquina'],
    'femoral'     => ['Curl femoral acostado', 'Curl femoral acostado', 'Curl femoral sentado'],
    'pantorrilla' => ['Elevación de talones de pie', 'Elevación de talones en prensa', 'Elevación de talones con barra'],
    'core'        => ['Plancha frontal', 'Dead bug', 'Rueda abdominal', 'Plancha frontal'],
    'core2'       => ['Plancha lateral', 'Pallof press en polea', 'Elevación de piernas colgado', 'Bird dog'],
];
const GRUPOS = [
    'superior'      => ['Tren superior', ['empuje_h', 'tiron_v', 'empuje_v', 'tiron_h', 'lateral', 'biceps', 'triceps']],
    'inferior'      => ['Tren inferior', ['cuadriceps', 'bisagra', 'unilateral', 'femoral', 'gluteo', 'pantorrilla', 'core']],
    'empuje'        => ['Tren superior · Empuje', ['empuje_h', 'empuje_v', 'empuje_inc', 'lateral', 'pecho_ais', 'triceps']],
    'tiron'         => ['Tren superior · Tirón', ['tiron_v', 'tiron_h', 'posterior', 'biceps', 'core2']],
    'pierna'        => ['Tren inferior · Pierna', ['cuadriceps', 'bisagra', 'unilateral', 'ext_pierna', 'femoral', 'pantorrilla']],
    'inferior_core' => ['Tren inferior · Glúteo y core', ['bisagra', 'gluteo', 'unilateral', 'femoral', 'core', 'core2']],
    'full_a'        => ['Cuerpo completo A', ['cuadriceps', 'empuje_h', 'tiron_v', 'bisagra', 'lateral', 'core']],
    'full_b'        => ['Cuerpo completo B', ['bisagra', 'empuje_v', 'tiron_h', 'unilateral', 'triceps', 'core2']],
];
const SPLITS = [
    3 => ['full_a', null, 'full_b', null, 'full_a', null, null],
    4 => ['superior', 'inferior', null, 'superior', 'inferior', null, null],
    5 => ['empuje', 'pierna', 'tiron', null, 'superior', 'inferior_core', null],
    6 => ['empuje', 'tiron', 'pierna', 'empuje', 'tiron', 'pierna', null],
];
const PRESCRIPCION = [
    'ganar_musculo' => ['sc' => 4, 'sa' => 3, 'rc' => '8-10', 'ra' => '10-12', 'dc' => 90, 'da' => 60, 'cardio' => 'Cardio suave 10 min (calentamiento)'],
    'fuerza'        => ['sc' => 5, 'sa' => 3, 'rc' => '4-6', 'ra' => '8-10', 'dc' => 150, 'da' => 90, 'cardio' => 'Movilidad 10 min antes de entrenar'],
    'perder_grasa'  => ['sc' => 3, 'sa' => 3, 'rc' => '10-12', 'ra' => '12-15', 'dc' => 60, 'da' => 45, 'cardio' => 'Cardio por intervalos 20-25 min al final'],
    'recomposicion' => ['sc' => 4, 'sa' => 3, 'rc' => '8-12', 'ra' => '12-15', 'dc' => 75, 'da' => 60, 'cardio' => 'Cardio moderado 15-20 min al final'],
    'resistencia'   => ['sc' => 3, 'sa' => 2, 'rc' => '12-15', 'ra' => '15-20', 'dc' => 45, 'da' => 30, 'cardio' => 'Cardio continuo 30 min'],
    'salud'         => ['sc' => 3, 'sa' => 2, 'rc' => '10-12', 'ra' => '12-15', 'dc' => 60, 'da' => 45, 'cardio' => 'Caminata o bici 20 min + movilidad 10 min'],
];
const COMPUESTOS = ['empuje_h', 'empuje_inc', 'empuje_v', 'tiron_v', 'tiron_h', 'cuadriceps', 'bisagra', 'unilateral', 'gluteo'];

function generar_plan(array $f): array
{
    $dias = min(6, max(3, (int)$f['dias']));
    $obj = isset(PRESCRIPCION[$f['objetivo']]) ? $f['objetivo'] : 'salud';
    $P = PRESCRIPCION[$obj];
    $nIdx = ['principiante' => 0, 'intermedio' => 1, 'avanzado' => 2][$f['nivel']] ?? 0;
    $edad = (int)$f['edad'];
    $notas = [];
    if ($edad < 18) {
        if ($obj === 'fuerza') { $P['rc'] = '6-8'; $P['dc'] = 120; }
        $P['sc'] = min($P['sc'], 3);
        $notas[] = 'Menor de edad: prioriza técnica y entrena siempre con supervisión de un coach. Evita cargas máximas.';
    }
    if ($edad >= 50) {
        $P['sc'] = min($P['sc'], 3);
        if ($P['rc'] === '4-6') $P['rc'] = '6-8';
        $notas[] = '50+ años: se usan variantes guiadas y de bajo impacto; agrega 10 min de movilidad y equilibrio.';
    }
    if ($f['nivel'] === 'principiante') {
        $P['sc'] = max(2, $P['sc'] - 1); $P['sa'] = max(2, $P['sa'] - 1);
        $notas[] = 'Principiante: las primeras 2 semanas usa un peso con el que te sobren 3 repeticiones.';
    }
    $imcV = imc((float)$f['peso'], (float)$f['estatura']);
    if ($imcV >= 30 && $edad >= 18) $notas[] = 'IMC ≥ 30: se evita el impacto (saltos, carrera) para cuidar articulaciones; el cardio es en bici o elíptica.';
    $nEj = [4, 5, 6][$nIdx];
    $variante = function (string $pt) use ($edad, $nIdx) { $v = BANCO[$pt]; return ($edad >= 50 && isset($v[3])) ? $v[3] : $v[min($nIdx, count($v) - 1)]; };
    preg_match('/(\d+)/', $P['cardio'], $mc);
    $semana = [];
    foreach (SPLITS[$dias] as $i => $g) {
        if (!$g) {
            $activo = in_array($obj, ['perder_grasa', 'resistencia', 'salud'], true) && $i === 5;
            $semana[] = ['dia' => DIAS_SEMANA[$i], 'descanso' => true, 'enfoque' => $activo ? 'Descanso activo' : 'Descanso',
                'nota' => $activo ? ($imcV >= 30 ? 'Opcional: 30-40 min de bici o caminata a ritmo cómodo.' : 'Opcional: 30-40 min de caminata, bici o natación a ritmo cómodo.') : 'Recupera: duerme 7-9 h e hidrátate.', 'ejercicios' => []];
            continue;
        }
        [$enfoque, $patrones] = GRUPOS[$g];
        $ej = [];
        foreach (array_slice($patrones, 0, $nEj) as $pt) {
            $comp = in_array($pt, COMPUESTOS, true); $core = str_starts_with($pt, 'core');
            $ej[] = ['nombre' => $variante($pt), 'series' => $comp ? $P['sc'] : $P['sa'],
                'reps' => $core ? ($pt === 'core' && $nIdx < 2 ? '30-45 s' : '10-12') : ($comp ? $P['rc'] : $P['ra']),
                'descanso' => $comp ? $P['dc'] : $P['da']];
        }
        $series = array_sum(array_column($ej, 'series'));
        $semana[] = ['dia' => DIAS_SEMANA[$i], 'descanso' => false, 'enfoque' => $enfoque, 'cardio' => $P['cardio'],
            'minutos' => (int)round($series * ($P['dc'] + 45) / 60 * 0.8) + (int)($mc[1] ?? 10), 'ejercicios' => $ej];
    }
    return [
        'nombre' => OBJETIVOS[$obj]['nombre'] . " · $dias días", 'objetivo' => $obj, 'nivel' => $f['nivel'], 'dias' => $dias,
        'semana' => array_values(array_filter($semana, fn($d) => !$d['descanso'])), 'semana_completa' => $semana, 'notas' => $notas,
        'progresion' => $obj === 'fuerza'
            ? 'Cuando completes todas las series con buena técnica, sube 2.5 kg en tren inferior y 1-2.5 kg en superior.'
            : 'Cuando llegues al tope del rango de repeticiones en todas las series, sube el peso 2.5-5% la siguiente sesión.',
    ];
}

const FACTOR_ACT = [3 => 1.375, 4 => 1.45, 5 => 1.55, 6 => 1.65];
const AJUSTE = ['perder_grasa' => -0.20, 'ganar_musculo' => 0.10, 'recomposicion' => -0.08, 'fuerza' => 0.05, 'resistencia' => 0, 'salud' => 0];
const PROT_GKG = ['perder_grasa' => 2.0, 'ganar_musculo' => 1.8, 'recomposicion' => 2.0, 'fuerza' => 1.8, 'resistencia' => 1.4, 'salud' => 1.2];
const EQ = ['verdura' => [25, 2, 4, 0], 'fruta' => [60, 0, 15, 0], 'cereal' => [70, 2, 15, 0], 'leguminosa' => [120, 8, 20, 1],
    'proteina' => [55, 7, 0, 3], 'leche' => [95, 9, 12, 2], 'grasa' => [45, 0, 0, 5]];
const EQ_NOMBRE = ['cereal' => 'Cereales', 'proteina' => 'Proteína (AOA)', 'leguminosa' => 'Leguminosas', 'verdura' => 'Verduras', 'fruta' => 'Frutas', 'leche' => 'Lácteos', 'grasa' => 'Grasas'];
const EJEMPLOS = [
    'cereal' => '1 tortilla de maíz · ⅓ taza de arroz · ½ pan integral · ⅓ taza de avena',
    'proteina' => '1 huevo · 30 g de pechuga de pollo · 30 g de pescado · 40 g de queso panela',
    'leguminosa' => '½ taza de frijoles, lentejas o garbanzos',
    'verdura' => '1 taza de verdura cruda o ½ taza cocida (nopales, calabacita, brócoli, jitomate)',
    'fruta' => '1 manzana · 1 plátano chico · 1 taza de papaya o melón',
    'leche' => '1 taza de leche descremada · ¾ taza de yogur natural',
    'grasa' => '⅓ de aguacate · 1 cdita de aceite · 10 almendras',
];
const COMIDAS = [
    ['Desayuno', '07:30', 0.25, 'Huevos a la mexicana con tortillas, papaya y café sin azúcar'],
    ['Colación AM', '11:00', 0.10, 'Yogur natural con fruta y almendras'],
    ['Comida', '14:30', 0.35, 'Pechuga asada, arroz, frijoles, ensalada de nopales y aguacate'],
    ['Colación PM', '18:00', 0.10, 'Fruta + puño de cacahuates o licuado de leche con plátano (post-entreno)'],
    ['Cena', '21:00', 0.20, 'Tostadas horneadas de atún o pollo con verdura y aguacate'],
];
const TIPS = [
    'perder_grasa' => ['Déficit moderado (≈20%) para no perder músculo.', 'Proteína en cada comida.', 'Prioriza verduras y fibra para controlar el hambre.'],
    'ganar_musculo' => ['Superávit ligero (≈10%): sube 0.25-0.5 kg por semana.', 'Reparte la proteína en 4-5 tomas.', 'Carbohidrato antes y después de entrenar.'],
    'recomposicion' => ['Déficit pequeño con proteína alta.', 'Mantén el entrenamiento de fuerza: es lo que conserva el músculo.', 'Mide progreso con % de grasa y músculo, no solo con el peso.'],
    'fuerza' => ['Come suficiente: comer poco frena la fuerza.', 'Carbohidrato complejo en la comida previa al entreno.', 'Duerme 7-9 h.'],
    'resistencia' => ['Los carbohidratos son tu combustible principal.', 'Hidrátate antes, durante y después.', 'Electrolitos en sesiones de más de 60 min.'],
    'salud' => ['Plato del bien comer: ½ verduras, ¼ proteína, ¼ cereal integral.', 'Limita azúcares y ultraprocesados.', 'Agua simple como bebida principal.'],
];

function plan_nutricional(array $f): array
{
    $edad = (int)$f['edad'];
    if ($edad < 18) return ['menor' => true];
    $peso = (float)$f['peso']; $est = (float)$f['estatura']; $obj = $f['objetivo']; $dias = (int)$f['dias'];
    $base = 10 * $peso + 6.25 * $est - 5 * $edad;
    $tmb = (int)round($f['sexo'] === 'HOMBRE' ? $base + 5 : ($f['sexo'] === 'MUJER' ? $base - 161 : $base - 78));
    $gasto = (int)round($tmb * (FACTOR_ACT[$dias] ?? 1.375));
    $piso = $f['sexo'] === 'HOMBRE' ? 1500 : 1200;
    $kcal = (int)(round($gasto * (1 + (AJUSTE[$obj] ?? 0)) / 10) * 10);
    $limitado = $kcal < $piso; $kcal = max($kcal, $piso, $tmb);
    $prot = (int)round($peso * (PROT_GKG[$obj] ?? 1.4));
    $grasa = (int)round($kcal * 0.27 / 9);
    $carb = max(0, (int)round(($kcal - $prot * 4 - $grasa * 9) / 4));
    $e = ['verdura' => 5, 'fruta' => $obj === 'perder_grasa' ? 2 : 3, 'leguminosa' => 1, 'leche' => $obj === 'ganar_musculo' ? 2 : 1];
    $suma = function (int $k) use (&$e) { $s = 0; foreach ($e as $g => $n) $s += EQ[$g][$k] * $n; return $s; };
    $e['proteina'] = max(4, (int)round(($prot - $suma(1) - 8) / EQ['proteina'][1]));
    $e['cereal'] = max(3, (int)round(($carb - $suma(2)) / EQ['cereal'][2]));
    $e['grasa'] = max(2, (int)round(($grasa - $suma(3)) / EQ['grasa'][3]));
    $comidas = [];
    foreach (COMIDAS as [$n, $h, $pct, $ej]) {
        $eq = [];
        foreach ($e as $g => $x) { $v = round($x * $pct * 2) / 2; if ($v > 0) $eq[$g] = $v; }
        $comidas[] = ['nombre' => $n, 'hora' => $h, 'kcal' => (int)(round($kcal * $pct / 10) * 10), 'eq' => $eq, 'ejemplo' => $ej];
    }
    return ['menor' => false, 'tmb' => $tmb, 'gasto' => $gasto, 'kcal' => $kcal, 'prot' => $prot, 'grasa' => $grasa, 'carb' => $carb,
        'limitado' => $limitado, 'eq_dia' => $e, 'comidas' => $comidas, 'agua' => round($peso * 0.035, 1) + ($dias >= 5 ? 0.5 : 0), 'tips' => TIPS[$obj] ?? []];
}
