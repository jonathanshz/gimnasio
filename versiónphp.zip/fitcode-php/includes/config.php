<?php
date_default_timezone_set('America/Mexico_City');

define('APP_NAME', 'FIT CODE');
define('APP_VERSION', '2.0.0');
define('ROOT_PATH', dirname(__DIR__));
define('STORAGE_PATH', ROOT_PATH . '/storage');
define('UPLOAD_PATH', STORAGE_PATH . '/uploads');
define('TMP_PATH', STORAGE_PATH . '/tmp');

define('DB_DRIVER', getenv('FITCODE_DB') ?: 'sqlite');
define('DB_SQLITE_FILE', getenv('FITCODE_SQLITE') ?: STORAGE_PATH . '/fitcode.sqlite');
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'gimnasio_integral_db');
define('DB_USER', 'root');
define('DB_PASS', '');

define('UPLOAD_MAX_BYTES', 5 * 1024 * 1024);
define('UPLOAD_MIMES', ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp']);

define('CORREO_SIMULADO', true);

const CAT_GENERO = ['MASCULINO', 'FEMENINO', 'NO BINARIO', 'OTRO', 'PREFIERO NO DECIRLO'];
const CAT_SEXO = ['HOMBRE', 'MUJER', 'INTERSEXUAL'];
const CAT_SERVICIO = ['IMSS', 'ISSSTE', 'IMSS-BIENESTAR', 'PEMEX', 'SEDENA', 'SEMAR', 'SEGURO DE GASTOS MÉDICOS PRIVADO', 'NINGUNO'];
const CAT_ENF = ['NINGUNA', 'DIABETES TIPO 1', 'DIABETES TIPO 2', 'HIPERTENSIÓN ARTERIAL', 'ASMA', 'OBESIDAD', 'CARDIOPATÍA', 'ENFERMEDAD PULMONAR OBSTRUCTIVA CRÓNICA (EPOC)', 'ARTRITIS / ARTROSIS', 'HIPOTIROIDISMO / HIPERTIROIDISMO', 'EPILEPSIA', 'INSUFICIENCIA RENAL CRÓNICA', 'ESCOLIOSIS / HERNIA DISCAL', 'OTRA'];
const ROL_NOMBRE = ['dueno' => 'Dueño', 'administrador' => 'Administración', 'recepcion' => 'Recepción', 'instructor' => 'Coach'];
const METODO_NOMBRE = ['efectivo' => 'Efectivo', 'tarjeta' => 'Tarjeta (terminal)', 'mercadopago' => 'Tarjeta en línea', 'transferencia' => 'Transferencia'];
const DOC_NOMBRE = ['id_oficial' => 'Identificación oficial', 'id_tutor' => 'Identificación del tutor', 'cert_medico' => 'Constancia médica', 'firma' => 'Firma electrónica'];
