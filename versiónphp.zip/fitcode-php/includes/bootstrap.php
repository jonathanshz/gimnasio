<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/schema.php';
require_once __DIR__ . '/fitness.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/repo.php';
require_once __DIR__ . '/barcode.php';
require_once __DIR__ . '/layout.php';
require_once __DIR__ . '/ui_fitness.php';

if (PHP_SAPI !== 'cli') {
    iniciar_sesion();
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
}
db();
