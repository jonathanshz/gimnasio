<?php
function esquema_sql(string $driver): array
{
    $tok = $driver === 'mysql'
        ? ['{PK}' => 'INT UNSIGNED AUTO_INCREMENT PRIMARY KEY', '{FK}' => 'INT UNSIGNED', '{T}' => ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci']
        : ['{PK}' => 'INTEGER PRIMARY KEY AUTOINCREMENT', '{FK}' => 'INTEGER', '{T}' => ''];
    $ddl = <<<SQL
CREATE TABLE roles (
  id {PK},
  nombre VARCHAR(30) NOT NULL UNIQUE,
  descripcion VARCHAR(120) NULL,
  activo TINYINT NOT NULL DEFAULT 1
){T};
CREATE TABLE puestos (
  id {PK},
  clave VARCHAR(20) NOT NULL UNIQUE,
  nombre VARCHAR(60) NOT NULL UNIQUE,
  activo TINYINT NOT NULL DEFAULT 1
){T};
CREATE TABLE empleados (
  id {PK},
  numero_empleado VARCHAR(12) NOT NULL UNIQUE,
  puesto_id {FK} NOT NULL,
  nombre VARCHAR(60) NOT NULL,
  apellido_paterno VARCHAR(60) NOT NULL,
  apellido_materno VARCHAR(60) NOT NULL,
  apellidos VARCHAR(121) NOT NULL,
  email VARCHAR(160) NULL UNIQUE,
  telefono VARCHAR(10) NULL,
  rfc CHAR(10) NULL UNIQUE,
  fecha_nacimiento DATE NULL,
  telefono_emergencia VARCHAR(10) NULL,
  servicio_medico VARCHAR(60) NULL,
  enfermedad_cronica VARCHAR(80) NULL,
  enfermedad_otra VARCHAR(120) NULL,
  fecha_ingreso DATE NOT NULL,
  estado VARCHAR(10) NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','activo','inactivo')),
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (puesto_id) REFERENCES puestos(id)
){T};
CREATE TABLE instructores (
  id {PK},
  empleado_id {FK} NOT NULL UNIQUE,
  especialidad VARCHAR(80) NULL,
  activo TINYINT NOT NULL DEFAULT 1,
  FOREIGN KEY (empleado_id) REFERENCES empleados(id)
){T};
CREATE TABLE usuarios (
  id {PK},
  nombre VARCHAR(160) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  email_verificado_en DATETIME NULL,
  rol_id {FK} NOT NULL,
  empleado_id {FK} NULL UNIQUE,
  activo TINYINT NOT NULL DEFAULT 1,
  intentos_fallidos SMALLINT NOT NULL DEFAULT 0,
  bloqueado_hasta DATETIME NULL,
  ultimo_acceso DATETIME NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (rol_id) REFERENCES roles(id),
  FOREIGN KEY (empleado_id) REFERENCES empleados(id)
){T};
CREATE TABLE empleado_documentos (
  id {PK},
  empleado_id {FK} NOT NULL,
  tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('id_oficial','cert_medico','firma')),
  ruta_archivo VARCHAR(255) NOT NULL,
  mime VARCHAR(60) NOT NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (empleado_id) REFERENCES empleados(id) ON DELETE CASCADE
){T};

CREATE TABLE socios (
  id {PK},
  codigo_credencial VARCHAR(16) NULL UNIQUE,
  usuario VARCHAR(40) NOT NULL UNIQUE,
  nombre VARCHAR(60) NOT NULL,
  apellido_paterno VARCHAR(60) NOT NULL,
  apellido_materno VARCHAR(60) NOT NULL,
  apellidos VARCHAR(121) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  telefono VARCHAR(10) NOT NULL UNIQUE,
  fecha_nacimiento DATE NOT NULL,
  genero VARCHAR(30) NOT NULL,
  sexo VARCHAR(20) NOT NULL,
  tipo_socio VARCHAR(10) NOT NULL DEFAULT 'mayor' CHECK (tipo_socio IN ('mayor','menor')),
  tutor_nombre VARCHAR(120) NULL,
  servicio_medico VARCHAR(60) NOT NULL,
  enfermedad_cronica VARCHAR(80) NOT NULL DEFAULT 'NINGUNA',
  enfermedad_otra VARCHAR(120) NULL,
  contacto_emergencia VARCHAR(120) NULL,
  telefono_emergencia VARCHAR(10) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  email_verificado_en DATETIME NULL,
  intentos_fallidos SMALLINT NOT NULL DEFAULT 0,
  bloqueado_hasta DATETIME NULL,
  activo TINYINT NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL
){T};
CREATE TABLE socio_documentos (
  id {PK},
  socio_id {FK} NOT NULL,
  tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('id_oficial','id_tutor','cert_medico','firma')),
  ruta_archivo VARCHAR(255) NOT NULL,
  mime VARCHAR(60) NOT NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (socio_id) REFERENCES socios(id) ON DELETE CASCADE
){T};
CREATE TABLE codigos_registro (
  id {PK},
  codigo CHAR(6) NOT NULL,
  generado_por {FK} NULL,
  usado_por_socio_id {FK} NULL,
  creado_en DATETIME NOT NULL,
  expira_en DATETIME NOT NULL,
  usado_en DATETIME NULL,
  FOREIGN KEY (generado_por) REFERENCES usuarios(id) ON DELETE SET NULL,
  FOREIGN KEY (usado_por_socio_id) REFERENCES socios(id) ON DELETE SET NULL
){T};
CREATE TABLE verificaciones_correo (
  id {PK},
  socio_id {FK} NULL,
  usuario_id {FK} NULL,
  email VARCHAR(160) NOT NULL,
  codigo_hash CHAR(64) NOT NULL,
  codigo_demo CHAR(6) NULL,
  intentos TINYINT NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL,
  expira_en DATETIME NOT NULL,
  verificado_en DATETIME NULL,
  invalidado_en DATETIME NULL,
  CHECK ((socio_id IS NOT NULL AND usuario_id IS NULL) OR (socio_id IS NULL AND usuario_id IS NOT NULL)),
  FOREIGN KEY (socio_id) REFERENCES socios(id) ON DELETE CASCADE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
){T};
CREATE TABLE sesiones (
  id {PK},
  usuario_id {FK} NULL,
  socio_id {FK} NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  ip VARCHAR(45) NULL,
  creada_en DATETIME NOT NULL,
  expira_en DATETIME NOT NULL,
  cerrada_en DATETIME NULL,
  CHECK ((usuario_id IS NOT NULL AND socio_id IS NULL) OR (usuario_id IS NULL AND socio_id IS NOT NULL))
){T};
CREATE TABLE bitacora (
  id {PK},
  usuario_id {FK} NULL,
  socio_id {FK} NULL,
  actor VARCHAR(10) NOT NULL,
  accion VARCHAR(60) NOT NULL,
  modulo VARCHAR(40) NOT NULL,
  detalle VARCHAR(255) NULL,
  ip VARCHAR(45) NULL,
  creado_en DATETIME NOT NULL
){T};

CREATE TABLE tipos_membresia (
  id {PK},
  nombre VARCHAR(60) NOT NULL UNIQUE,
  duracion_dias INT NOT NULL CHECK (duracion_dias > 0),
  precio DECIMAL(10,2) NOT NULL CHECK (precio >= 0),
  descripcion VARCHAR(255) NULL,
  beneficios_descripcion TEXT NULL,
  activo TINYINT NOT NULL DEFAULT 1
){T};
CREATE TABLE estados_membresia (
  codigo VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL,
  permite_acceso TINYINT NOT NULL DEFAULT 0
){T};
CREATE TABLE membresias (
  id {PK},
  socio_id {FK} NOT NULL,
  tipo_membresia_id {FK} NOT NULL,
  fecha_inicio DATE NOT NULL,
  fecha_fin DATE NOT NULL,
  estado VARCHAR(20) NOT NULL DEFAULT 'activa',
  precio_aplicado DECIMAL(10,2) NULL,
  creado_en DATETIME NOT NULL,
  CHECK (fecha_fin >= fecha_inicio),
  FOREIGN KEY (socio_id) REFERENCES socios(id),
  FOREIGN KEY (tipo_membresia_id) REFERENCES tipos_membresia(id),
  FOREIGN KEY (estado) REFERENCES estados_membresia(codigo)
){T};
CREATE TABLE metodos_pago (
  codigo VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL,
  requiere_referencia TINYINT NOT NULL DEFAULT 0
){T};
CREATE TABLE pagos (
  id {PK},
  folio VARCHAR(20) NOT NULL UNIQUE,
  socio_id {FK} NOT NULL,
  membresia_id {FK} NULL,
  tipo_membresia_id {FK} NOT NULL,
  concepto VARCHAR(120) NOT NULL,
  monto DECIMAL(10,2) NOT NULL CHECK (monto >= 0),
  metodo VARCHAR(20) NOT NULL,
  usuario_id {FK} NULL,
  estado VARCHAR(12) NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','pagado','rechazado','cancelado','expirado','reembolsado')),
  referencia_externa VARCHAR(60) NULL,
  referencia_pago VARCHAR(20) NULL UNIQUE,
  expira_en DATETIME NULL,
  pagado_en DATETIME NULL,
  tarjeta_marca VARCHAR(20) NULL,
  tarjeta_ultimos4 CHAR(4) NULL,
  observaciones VARCHAR(255) NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (socio_id) REFERENCES socios(id),
  FOREIGN KEY (membresia_id) REFERENCES membresias(id) ON DELETE SET NULL,
  FOREIGN KEY (tipo_membresia_id) REFERENCES tipos_membresia(id),
  FOREIGN KEY (metodo) REFERENCES metodos_pago(codigo),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
){T};
CREATE TABLE detalle_pagos (
  id {PK},
  pago_id {FK} NOT NULL,
  descripcion VARCHAR(160) NOT NULL,
  cantidad DECIMAL(10,2) NOT NULL DEFAULT 1,
  precio_unitario DECIMAL(10,2) NOT NULL,
  descuento DECIMAL(10,2) NOT NULL DEFAULT 0,
  subtotal DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (pago_id) REFERENCES pagos(id) ON DELETE CASCADE
){T};
CREATE TABLE categorias_contables (
  id {PK},
  nombre VARCHAR(60) NOT NULL UNIQUE,
  tipo VARCHAR(10) NOT NULL
){T};
CREATE TABLE movimientos_contables (
  id {PK},
  tipo VARCHAR(10) NOT NULL,
  categoria_id {FK} NOT NULL,
  fecha_movimiento DATETIME NOT NULL,
  concepto VARCHAR(160) NOT NULL,
  monto DECIMAL(10,2) NOT NULL,
  pago_id {FK} NULL,
  usuario_id {FK} NULL,
  referencia VARCHAR(40) NULL,
  FOREIGN KEY (categoria_id) REFERENCES categorias_contables(id),
  FOREIGN KEY (pago_id) REFERENCES pagos(id) ON DELETE SET NULL
){T};

CREATE TABLE resultados_acceso (
  codigo VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL,
  acceso_permitido TINYINT NOT NULL DEFAULT 0
){T};
CREATE TABLE asistencias (
  id {PK},
  socio_id {FK} NULL,
  codigo_leido VARCHAR(40) NOT NULL,
  resultado VARCHAR(20) NOT NULL,
  motivo VARCHAR(160) NULL,
  tipo_movimiento VARCHAR(10) NULL CHECK (tipo_movimiento IS NULL OR tipo_movimiento IN ('entrada','salida')),
  registrado_por {FK} NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (socio_id) REFERENCES socios(id) ON DELETE SET NULL,
  FOREIGN KEY (resultado) REFERENCES resultados_acceso(codigo),
  FOREIGN KEY (registrado_por) REFERENCES usuarios(id) ON DELETE SET NULL
){T};
CREATE TABLE estados_equipo (
  codigo VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL,
  disponible_uso TINYINT NOT NULL DEFAULT 0
){T};
CREATE TABLE equipos (
  id {PK},
  nombre VARCHAR(80) NOT NULL,
  ubicacion VARCHAR(40) NULL,
  estado VARCHAR(20) NOT NULL DEFAULT 'operativo',
  FOREIGN KEY (estado) REFERENCES estados_equipo(codigo)
){T};
CREATE TABLE uso_equipos (
  id {PK},
  equipo_id {FK} NOT NULL,
  socio_id {FK} NULL,
  inicio DATETIME NOT NULL,
  fin DATETIME NULL,
  registrado_por {FK} NULL,
  FOREIGN KEY (equipo_id) REFERENCES equipos(id)
){T};

CREATE TABLE expedientes (
  id {PK},
  socio_id {FK} NOT NULL UNIQUE,
  objetivo_principal VARCHAR(20) NULL,
  nivel VARCHAR(15) NULL,
  dias_entrenamiento TINYINT NULL,
  actualizado_por {FK} NULL,
  creado_en DATETIME NOT NULL,
  actualizado_en DATETIME NOT NULL,
  FOREIGN KEY (socio_id) REFERENCES socios(id) ON DELETE CASCADE
){T};
CREATE TABLE mediciones (
  id {PK},
  expediente_id {FK} NOT NULL,
  fecha_medicion DATETIME NOT NULL,
  peso_kg DECIMAL(5,1) NOT NULL CHECK (peso_kg > 0),
  estatura_cm DECIMAL(5,1) NOT NULL CHECK (estatura_cm > 0),
  imc DECIMAL(4,1) NOT NULL,
  porcentaje_grasa DECIMAL(4,1) NULL,
  porcentaje_musculo DECIMAL(4,1) NULL,
  registrado_por {FK} NULL,
  FOREIGN KEY (expediente_id) REFERENCES expedientes(id) ON DELETE CASCADE
){T};
CREATE TABLE ejercicios (
  id {PK},
  nombre VARCHAR(120) NOT NULL UNIQUE,
  activo TINYINT NOT NULL DEFAULT 1
){T};
CREATE TABLE rutinas (
  id {PK},
  nombre VARCHAR(120) NOT NULL,
  objetivo VARCHAR(20) NULL,
  nivel VARCHAR(15) NULL,
  dias_por_semana TINYINT NULL,
  creador_usuario_id {FK} NULL,
  es_plantilla TINYINT NOT NULL DEFAULT 1,
  creada_en DATETIME NOT NULL
){T};
CREATE TABLE rutina_ejercicios (
  id {PK},
  rutina_id {FK} NOT NULL,
  ejercicio_id {FK} NOT NULL,
  dia_numero TINYINT NOT NULL,
  enfoque VARCHAR(40) NULL,
  orden SMALLINT NOT NULL DEFAULT 1,
  series TINYINT NULL,
  repeticiones VARCHAR(12) NULL,
  descanso_segundos SMALLINT NULL,
  FOREIGN KEY (rutina_id) REFERENCES rutinas(id) ON DELETE CASCADE,
  FOREIGN KEY (ejercicio_id) REFERENCES ejercicios(id)
){T};
CREATE TABLE rutinas_socio (
  id {PK},
  socio_id {FK} NOT NULL,
  rutina_id {FK} NOT NULL,
  instructor_id {FK} NULL,
  fecha_inicio DATE NOT NULL,
  fecha_fin DATE NULL,
  estado VARCHAR(12) NOT NULL DEFAULT 'activa',
  asignada_en DATETIME NOT NULL,
  FOREIGN KEY (socio_id) REFERENCES socios(id),
  FOREIGN KEY (rutina_id) REFERENCES rutinas(id),
  FOREIGN KEY (instructor_id) REFERENCES instructores(id) ON DELETE SET NULL
){T};
CREATE INDEX ix_asist_socio ON asistencias (socio_id, resultado, creado_en);
CREATE INDEX ix_memb_socio ON membresias (socio_id, fecha_fin);
CREATE INDEX ix_pagos_socio ON pagos (socio_id, creado_en);
CREATE INDEX ix_pagos_pend ON pagos (metodo, estado, expira_en);
CREATE INDEX ix_uso_abierto ON uso_equipos (equipo_id, fin);
SQL;
    $ddl = strtr($ddl, $tok);
    return array_values(array_filter(array_map('trim', explode(';', preg_replace('/--[^\n]*/', '', $ddl)))));
}
