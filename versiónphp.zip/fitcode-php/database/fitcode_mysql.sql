CREATE DATABASE IF NOT EXISTS gimnasio_integral_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gimnasio_integral_db;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `rutinas_socio`;
DROP TABLE IF EXISTS `rutina_ejercicios`;
DROP TABLE IF EXISTS `rutinas`;
DROP TABLE IF EXISTS `ejercicios`;
DROP TABLE IF EXISTS `mediciones`;
DROP TABLE IF EXISTS `expedientes`;
DROP TABLE IF EXISTS `uso_equipos`;
DROP TABLE IF EXISTS `equipos`;
DROP TABLE IF EXISTS `estados_equipo`;
DROP TABLE IF EXISTS `asistencias`;
DROP TABLE IF EXISTS `resultados_acceso`;
DROP TABLE IF EXISTS `movimientos_contables`;
DROP TABLE IF EXISTS `categorias_contables`;
DROP TABLE IF EXISTS `detalle_pagos`;
DROP TABLE IF EXISTS `pagos`;
DROP TABLE IF EXISTS `metodos_pago`;
DROP TABLE IF EXISTS `membresias`;
DROP TABLE IF EXISTS `estados_membresia`;
DROP TABLE IF EXISTS `tipos_membresia`;
DROP TABLE IF EXISTS `bitacora`;
DROP TABLE IF EXISTS `sesiones`;
DROP TABLE IF EXISTS `verificaciones_correo`;
DROP TABLE IF EXISTS `codigos_registro`;
DROP TABLE IF EXISTS `socio_documentos`;
DROP TABLE IF EXISTS `socios`;
DROP TABLE IF EXISTS `empleado_documentos`;
DROP TABLE IF EXISTS `usuarios`;
DROP TABLE IF EXISTS `instructores`;
DROP TABLE IF EXISTS `empleados`;
DROP TABLE IF EXISTS `puestos`;
DROP TABLE IF EXISTS `roles`;

CREATE TABLE roles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(30) NOT NULL UNIQUE,
  descripcion VARCHAR(120) NULL,
  activo TINYINT NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE puestos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  clave VARCHAR(20) NOT NULL UNIQUE,
  nombre VARCHAR(60) NOT NULL UNIQUE,
  activo TINYINT NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE empleados (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  numero_empleado VARCHAR(12) NOT NULL UNIQUE,
  puesto_id INT UNSIGNED NOT NULL,
  nombre VARCHAR(60) NOT NULL,
  apellido_paterno VARCHAR(60) NOT NULL,
  apellido_materno VARCHAR(60) NOT NULL,
  apellidos VARCHAR(121) NOT NULL,
  email VARCHAR(160) NULL UNIQUE,
  telefono VARCHAR(10) NULL,
  rfc CHAR(10) NULL UNIQUE,
  fecha_nacimiento DATE NULL,
  telefono_emergencia VARCHAR(10) NULL,
  servicio_medico VARCHAR(60) NULL,
  enfermedad_cronica VARCHAR(80) NULL,
  enfermedad_otra VARCHAR(120) NULL,
  fecha_ingreso DATE NOT NULL,
  estado VARCHAR(10) NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','activo','inactivo')),
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (puesto_id) REFERENCES puestos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE instructores (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  empleado_id INT UNSIGNED NOT NULL UNIQUE,
  especialidad VARCHAR(80) NULL,
  activo TINYINT NOT NULL DEFAULT 1,
  FOREIGN KEY (empleado_id) REFERENCES empleados(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE usuarios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(160) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  email_verificado_en DATETIME NULL,
  rol_id INT UNSIGNED NOT NULL,
  empleado_id INT UNSIGNED NULL UNIQUE,
  activo TINYINT NOT NULL DEFAULT 1,
  intentos_fallidos SMALLINT NOT NULL DEFAULT 0,
  bloqueado_hasta DATETIME NULL,
  ultimo_acceso DATETIME NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (rol_id) REFERENCES roles(id),
  FOREIGN KEY (empleado_id) REFERENCES empleados(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE empleado_documentos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  empleado_id INT UNSIGNED NOT NULL,
  tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('id_oficial','cert_medico','firma')),
  ruta_archivo VARCHAR(255) NOT NULL,
  mime VARCHAR(60) NOT NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (empleado_id) REFERENCES empleados(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE socios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo_credencial VARCHAR(16) NULL UNIQUE,
  usuario VARCHAR(40) NOT NULL UNIQUE,
  nombre VARCHAR(60) NOT NULL,
  apellido_paterno VARCHAR(60) NOT NULL,
  apellido_materno VARCHAR(60) NOT NULL,
  apellidos VARCHAR(121) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  telefono VARCHAR(10) NOT NULL UNIQUE,
  fecha_nacimiento DATE NOT NULL,
  genero VARCHAR(30) NOT NULL,
  sexo VARCHAR(20) NOT NULL,
  tipo_socio VARCHAR(10) NOT NULL DEFAULT 'mayor' CHECK (tipo_socio IN ('mayor','menor')),
  tutor_nombre VARCHAR(120) NULL,
  servicio_medico VARCHAR(60) NOT NULL,
  enfermedad_cronica VARCHAR(80) NOT NULL DEFAULT 'NINGUNA',
  enfermedad_otra VARCHAR(120) NULL,
  contacto_emergencia VARCHAR(120) NULL,
  telefono_emergencia VARCHAR(10) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  email_verificado_en DATETIME NULL,
  intentos_fallidos SMALLINT NOT NULL DEFAULT 0,
  bloqueado_hasta DATETIME NULL,
  activo TINYINT NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE socio_documentos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  socio_id INT UNSIGNED NOT NULL,
  tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('id_oficial','id_tutor','cert_medico','firma')),
  ruta_archivo VARCHAR(255) NOT NULL,
  mime VARCHAR(60) NOT NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (socio_id) REFERENCES socios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE codigos_registro (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo CHAR(6) NOT NULL,
  generado_por INT UNSIGNED NULL,
  usado_por_socio_id INT UNSIGNED NULL,
  creado_en DATETIME NOT NULL,
  expira_en DATETIME NOT NULL,
  usado_en DATETIME NULL,
  FOREIGN KEY (generado_por) REFERENCES usuarios(id) ON DELETE SET NULL,
  FOREIGN KEY (usado_por_socio_id) REFERENCES socios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE verificaciones_correo (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  socio_id INT UNSIGNED NULL,
  usuario_id INT UNSIGNED NULL,
  email VARCHAR(160) NOT NULL,
  codigo_hash CHAR(64) NOT NULL,
  codigo_demo CHAR(6) NULL,
  intentos TINYINT NOT NULL DEFAULT 0,
  creado_en DATETIME NOT NULL,
  expira_en DATETIME NOT NULL,
  verificado_en DATETIME NULL,
  invalidado_en DATETIME NULL,
  CHECK ((socio_id IS NOT NULL AND usuario_id IS NULL) OR (socio_id IS NULL AND usuario_id IS NOT NULL)),
  FOREIGN KEY (socio_id) REFERENCES socios(id) ON DELETE CASCADE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE sesiones (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED NULL,
  socio_id INT UNSIGNED NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  ip VARCHAR(45) NULL,
  creada_en DATETIME NOT NULL,
  expira_en DATETIME NOT NULL,
  cerrada_en DATETIME NULL,
  CHECK ((usuario_id IS NOT NULL AND socio_id IS NULL) OR (usuario_id IS NULL AND socio_id IS NOT NULL))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE bitacora (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT UNSIGNED NULL,
  socio_id INT UNSIGNED NULL,
  actor VARCHAR(10) NOT NULL,
  accion VARCHAR(60) NOT NULL,
  modulo VARCHAR(40) NOT NULL,
  detalle VARCHAR(255) NULL,
  ip VARCHAR(45) NULL,
  creado_en DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE tipos_membresia (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(60) NOT NULL UNIQUE,
  duracion_dias INT NOT NULL CHECK (duracion_dias > 0),
  precio DECIMAL(10,2) NOT NULL CHECK (precio >= 0),
  descripcion VARCHAR(255) NULL,
  beneficios_descripcion TEXT NULL,
  activo TINYINT NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE estados_membresia (
  codigo VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL,
  permite_acceso TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE membresias (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  socio_id INT UNSIGNED NOT NULL,
  tipo_membresia_id INT UNSIGNED NOT NULL,
  fecha_inicio DATE NOT NULL,
  fecha_fin DATE NOT NULL,
  estado VARCHAR(20) NOT NULL DEFAULT 'activa',
  precio_aplicado DECIMAL(10,2) NULL,
  creado_en DATETIME NOT NULL,
  CHECK (fecha_fin >= fecha_inicio),
  FOREIGN KEY (socio_id) REFERENCES socios(id),
  FOREIGN KEY (tipo_membresia_id) REFERENCES tipos_membresia(id),
  FOREIGN KEY (estado) REFERENCES estados_membresia(codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE metodos_pago (
  codigo VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL,
  requiere_referencia TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE pagos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  folio VARCHAR(20) NOT NULL UNIQUE,
  socio_id INT UNSIGNED NOT NULL,
  membresia_id INT UNSIGNED NULL,
  tipo_membresia_id INT UNSIGNED NOT NULL,
  concepto VARCHAR(120) NOT NULL,
  monto DECIMAL(10,2) NOT NULL CHECK (monto >= 0),
  metodo VARCHAR(20) NOT NULL,
  usuario_id INT UNSIGNED NULL,
  estado VARCHAR(12) NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','pagado','rechazado','cancelado','expirado','reembolsado')),
  referencia_externa VARCHAR(60) NULL,
  referencia_pago VARCHAR(20) NULL UNIQUE,
  expira_en DATETIME NULL,
  pagado_en DATETIME NULL,
  tarjeta_marca VARCHAR(20) NULL,
  tarjeta_ultimos4 CHAR(4) NULL,
  observaciones VARCHAR(255) NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (socio_id) REFERENCES socios(id),
  FOREIGN KEY (membresia_id) REFERENCES membresias(id) ON DELETE SET NULL,
  FOREIGN KEY (tipo_membresia_id) REFERENCES tipos_membresia(id),
  FOREIGN KEY (metodo) REFERENCES metodos_pago(codigo),
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE detalle_pagos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pago_id INT UNSIGNED NOT NULL,
  descripcion VARCHAR(160) NOT NULL,
  cantidad DECIMAL(10,2) NOT NULL DEFAULT 1,
  precio_unitario DECIMAL(10,2) NOT NULL,
  descuento DECIMAL(10,2) NOT NULL DEFAULT 0,
  subtotal DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (pago_id) REFERENCES pagos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE categorias_contables (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(60) NOT NULL UNIQUE,
  tipo VARCHAR(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE movimientos_contables (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  tipo VARCHAR(10) NOT NULL,
  categoria_id INT UNSIGNED NOT NULL,
  fecha_movimiento DATETIME NOT NULL,
  concepto VARCHAR(160) NOT NULL,
  monto DECIMAL(10,2) NOT NULL,
  pago_id INT UNSIGNED NULL,
  usuario_id INT UNSIGNED NULL,
  referencia VARCHAR(40) NULL,
  FOREIGN KEY (categoria_id) REFERENCES categorias_contables(id),
  FOREIGN KEY (pago_id) REFERENCES pagos(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE resultados_acceso (
  codigo VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL,
  acceso_permitido TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE asistencias (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  socio_id INT UNSIGNED NULL,
  codigo_leido VARCHAR(40) NOT NULL,
  resultado VARCHAR(20) NOT NULL,
  motivo VARCHAR(160) NULL,
  tipo_movimiento VARCHAR(10) NULL CHECK (tipo_movimiento IS NULL OR tipo_movimiento IN ('entrada','salida')),
  registrado_por INT UNSIGNED NULL,
  creado_en DATETIME NOT NULL,
  FOREIGN KEY (socio_id) REFERENCES socios(id) ON DELETE SET NULL,
  FOREIGN KEY (resultado) REFERENCES resultados_acceso(codigo),
  FOREIGN KEY (registrado_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE estados_equipo (
  codigo VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL,
  disponible_uso TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE equipos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  ubicacion VARCHAR(40) NULL,
  estado VARCHAR(20) NOT NULL DEFAULT 'operativo',
  FOREIGN KEY (estado) REFERENCES estados_equipo(codigo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE uso_equipos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  equipo_id INT UNSIGNED NOT NULL,
  socio_id INT UNSIGNED NULL,
  inicio DATETIME NOT NULL,
  fin DATETIME NULL,
  registrado_por INT UNSIGNED NULL,
  FOREIGN KEY (equipo_id) REFERENCES equipos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE expedientes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  socio_id INT UNSIGNED NOT NULL UNIQUE,
  objetivo_principal VARCHAR(20) NULL,
  nivel VARCHAR(15) NULL,
  dias_entrenamiento TINYINT NULL,
  actualizado_por INT UNSIGNED NULL,
  creado_en DATETIME NOT NULL,
  actualizado_en DATETIME NOT NULL,
  FOREIGN KEY (socio_id) REFERENCES socios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE mediciones (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  expediente_id INT UNSIGNED NOT NULL,
  fecha_medicion DATETIME NOT NULL,
  peso_kg DECIMAL(5,1) NOT NULL CHECK (peso_kg > 0),
  estatura_cm DECIMAL(5,1) NOT NULL CHECK (estatura_cm > 0),
  imc DECIMAL(4,1) NOT NULL,
  porcentaje_grasa DECIMAL(4,1) NULL,
  porcentaje_musculo DECIMAL(4,1) NULL,
  registrado_por INT UNSIGNED NULL,
  FOREIGN KEY (expediente_id) REFERENCES expedientes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ejercicios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL UNIQUE,
  activo TINYINT NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE rutinas (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  objetivo VARCHAR(20) NULL,
  nivel VARCHAR(15) NULL,
  dias_por_semana TINYINT NULL,
  creador_usuario_id INT UNSIGNED NULL,
  es_plantilla TINYINT NOT NULL DEFAULT 1,
  creada_en DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE rutina_ejercicios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  rutina_id INT UNSIGNED NOT NULL,
  ejercicio_id INT UNSIGNED NOT NULL,
  dia_numero TINYINT NOT NULL,
  enfoque VARCHAR(40) NULL,
  orden SMALLINT NOT NULL DEFAULT 1,
  series TINYINT NULL,
  repeticiones VARCHAR(12) NULL,
  descanso_segundos SMALLINT NULL,
  FOREIGN KEY (rutina_id) REFERENCES rutinas(id) ON DELETE CASCADE,
  FOREIGN KEY (ejercicio_id) REFERENCES ejercicios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE rutinas_socio (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  socio_id INT UNSIGNED NOT NULL,
  rutina_id INT UNSIGNED NOT NULL,
  instructor_id INT UNSIGNED NULL,
  fecha_inicio DATE NOT NULL,
  fecha_fin DATE NULL,
  estado VARCHAR(12) NOT NULL DEFAULT 'activa',
  asignada_en DATETIME NOT NULL,
  FOREIGN KEY (socio_id) REFERENCES socios(id),
  FOREIGN KEY (rutina_id) REFERENCES rutinas(id),
  FOREIGN KEY (instructor_id) REFERENCES instructores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX ix_asist_socio ON asistencias (socio_id, resultado, creado_en);

CREATE INDEX ix_memb_socio ON membresias (socio_id, fecha_fin);

CREATE INDEX ix_pagos_socio ON pagos (socio_id, creado_en);

CREATE INDEX ix_pagos_pend ON pagos (metodo, estado, expira_en);

CREATE INDEX ix_uso_abierto ON uso_equipos (equipo_id, fin);

INSERT INTO `roles` (`id`,`nombre`,`descripcion`,`activo`) VALUES
(1,'dueno',NULL,1),
(2,'administrador',NULL,1),
(3,'recepcion',NULL,1),
(4,'instructor',NULL,1),
(5,'socio',NULL,1);
INSERT INTO `puestos` (`id`,`clave`,`nombre`,`activo`) VALUES
(1,'dueno','Dueño',1),
(2,'administrador','Administrador',1),
(3,'recepcion','Recepcionista',1),
(4,'instructor','Coach',1);
INSERT INTO `empleados` (`id`,`numero_empleado`,`puesto_id`,`nombre`,`apellido_paterno`,`apellido_materno`,`apellidos`,`email`,`telefono`,`rfc`,`fecha_nacimiento`,`telefono_emergencia`,`servicio_medico`,`enfermedad_cronica`,`enfermedad_otra`,`fecha_ingreso`,`estado`,`creado_en`) VALUES
(1,'DUE-0001',1,'ROBERTO','MÉNDEZ','SALAS','MÉNDEZ SALAS','dueno@fitcode.mx','5550000000','MESR800101',NULL,NULL,NULL,NULL,NULL,'2025-01-15','activo','2026-10-21 15:49:36'),
(2,'ADM-0001',2,'LAURA','GÓMEZ','TREJO','GÓMEZ TREJO','admin@fitcode.mx','5550000000','GOTL900215',NULL,NULL,NULL,NULL,NULL,'2025-01-15','activo','2026-10-21 15:49:36'),
(3,'REC-0001',3,'DIANA','CRUZ','VEGA','CRUZ VEGA','recepcion@fitcode.mx','5550000000','CUVD980712',NULL,NULL,NULL,NULL,NULL,'2025-01-15','activo','2026-10-21 15:49:36'),
(4,'COA-0001',4,'CARLOS','RUIZ','ORTEGA','RUIZ ORTEGA','coach@fitcode.mx','5550000000','RUOC920304',NULL,NULL,NULL,NULL,NULL,'2025-01-15','activo','2026-10-21 15:49:36');
INSERT INTO `instructores` (`id`,`empleado_id`,`especialidad`,`activo`) VALUES
(1,4,'Hipertrofia y fuerza',1);
INSERT INTO `usuarios` (`id`,`nombre`,`email`,`password_hash`,`email_verificado_en`,`rol_id`,`empleado_id`,`activo`,`intentos_fallidos`,`bloqueado_hasta`,`ultimo_acceso`,`creado_en`) VALUES
(1,'ROBERTO MÉNDEZ SALAS','dueno@fitcode.mx','$2y$10$4sfisAXwDsvuOzWLSw1S9.enYanACmnQpXCkAx0ipNDusNgZrY32a','2026-10-21 15:49:36',1,1,1,0,NULL,NULL,'2026-10-21 15:49:36'),
(2,'LAURA GÓMEZ TREJO','admin@fitcode.mx','$2y$10$daBeOPHDYpukr9cPHows8uXtYezlWo.RFhl/NcolV1ah9YSH2Uc1G','2026-10-21 15:49:36',2,2,1,0,NULL,NULL,'2026-10-21 15:49:36'),
(3,'DIANA CRUZ VEGA','recepcion@fitcode.mx','$2y$10$dCRiJqjMXtyCr6RrGmTbrueAVeqmq/pCAYbElu7b.Psinp7vMtMfG','2026-10-21 15:49:36',3,3,1,0,NULL,NULL,'2026-10-21 15:49:36'),
(4,'CARLOS RUIZ ORTEGA','coach@fitcode.mx','$2y$10$lMNtT6UFQeWfzA35U8HsSu5ob0ZOZ4MGgtSR6lniQzrr74oVPL4..','2026-10-21 15:49:36',4,4,1,0,NULL,NULL,'2026-10-21 15:49:36');
INSERT INTO `socios` (`id`,`codigo_credencial`,`usuario`,`nombre`,`apellido_paterno`,`apellido_materno`,`apellidos`,`email`,`telefono`,`fecha_nacimiento`,`genero`,`sexo`,`tipo_socio`,`tutor_nombre`,`servicio_medico`,`enfermedad_cronica`,`enfermedad_otra`,`contacto_emergencia`,`telefono_emergencia`,`password_hash`,`email_verificado_en`,`intentos_fallidos`,`bloqueado_hasta`,`activo`,`creado_en`) VALUES
(1,'FC260000013','ANAPP-150398','ANA','PÉREZ','PÉREZ','PÉREZ PÉREZ','ana@demo.mx','5512345678','1998-03-15','FEMENINO','MUJER','mayor',NULL,'IMSS','NINGUNA',NULL,NULL,'5500000000','$2y$10$P7X/M2m.wDcj2abIcPHHTu3jruFvjb68iCXqXaqQtNd9m23JxzcCG','2026-10-21 15:49:36',0,NULL,1,'2026-03-01 10:00:00'),
(2,'FC260000021','LUISRM-020901','LUIS','RAMÍREZ','MORA','RAMÍREZ MORA','luis@demo.mx','5587654321','2001-09-02','MASCULINO','HOMBRE','mayor',NULL,'ISSSTE','ASMA',NULL,NULL,'5500000000','$2y$10$P7X/M2m.wDcj2abIcPHHTu3jruFvjb68iCXqXaqQtNd9m23JxzcCG','2026-10-21 15:49:36',0,NULL,1,'2026-06-10 10:00:00'),
(3,'FC260000039','SOFIAHL-110510','SOFÍA','HERNÁNDEZ','LUNA','HERNÁNDEZ LUNA','sofia@demo.mx','5511122233','2010-05-11','FEMENINO','MUJER','menor','MARTHA LUNA RÍOS','IMSS','NINGUNA',NULL,'MARTHA LUNA RÍOS','5500000000','$2y$10$P7X/M2m.wDcj2abIcPHHTu3jruFvjb68iCXqXaqQtNd9m23JxzcCG','2026-10-21 15:49:36',0,NULL,1,'2026-08-20 10:00:00');
INSERT INTO `codigos_registro` (`id`,`codigo`,`generado_por`,`usado_por_socio_id`,`creado_en`,`expira_en`,`usado_en`) VALUES
(1,'482915',3,NULL,'2026-10-20 12:00:00','2026-10-23 12:00:00',NULL),
(2,'731004',3,NULL,'2026-10-19 12:00:00','2026-10-22 12:00:00',NULL);
INSERT INTO `tipos_membresia` (`id`,`nombre`,`duracion_dias`,`precio`,`descripcion`,`beneficios_descripcion`,`activo`) VALUES
(1,'Visita',1,80,'Acceso por un día.','Acceso a piso de pesas
Regaderas',1),
(2,'Mensual',30,549,'El plan base para entrenar todo el mes.','Acceso ilimitado
Evaluación inicial
App FIT CODE',1),
(3,'Trimestral',90,1499,'Tres meses con precio preferente.','Todo lo del Mensual
1 rutina personalizada
Medición mensual',1),
(4,'Anual',365,5490,'Doce meses al mejor precio.','Todo lo del Trimestral
Clases grupales
Casillero fijo
2 pases de invitado al mes',1),
(5,'Estudiante',30,399,'Mensual con credencial vigente.','Acceso L–V 6:00–16:00
App FIT CODE',1);
INSERT INTO `estados_membresia` (`codigo`,`nombre`,`permite_acceso`) VALUES
('activa','Activa',1),
('pendiente','Pendiente',0),
('vencida','Vencida',0),
('cancelada','Cancelada',0),
('congelada','Congelada',0);
INSERT INTO `membresias` (`id`,`socio_id`,`tipo_membresia_id`,`fecha_inicio`,`fecha_fin`,`estado`,`precio_aplicado`,`creado_en`) VALUES
(1,1,2,'2026-07-23','2026-08-21','vencida',549,'2026-07-23 09:30:00'),
(2,1,3,'2026-08-22','2026-11-19','activa',1499,'2026-08-22 09:30:00'),
(3,2,2,'2026-09-25','2026-10-24','activa',549,'2026-09-25 09:30:00'),
(4,3,5,'2026-09-11','2026-10-10','vencida',399,'2026-09-11 09:30:00');
INSERT INTO `metodos_pago` (`codigo`,`nombre`,`requiere_referencia`) VALUES
('efectivo','Efectivo',0),
('tarjeta','Tarjeta en terminal',1),
('mercadopago','Tarjeta en línea',1),
('transferencia','Transferencia',1);
INSERT INTO `pagos` (`id`,`folio`,`socio_id`,`membresia_id`,`tipo_membresia_id`,`concepto`,`monto`,`metodo`,`usuario_id`,`estado`,`referencia_externa`,`referencia_pago`,`expira_en`,`pagado_en`,`tarjeta_marca`,`tarjeta_ultimos4`,`observaciones`,`creado_en`) VALUES
(1,'R260723A1B2C9',1,1,2,'Membresía Mensual',549,'efectivo',3,'pagado',NULL,NULL,NULL,'2026-07-23 09:30:00',NULL,NULL,NULL,'2026-07-23 09:30:00'),
(2,'R260822A1B2CA',1,2,3,'Membresía Trimestral',1499,'tarjeta',3,'pagado',NULL,NULL,NULL,'2026-08-22 09:30:00','VISA','4242',NULL,'2026-08-22 09:30:00'),
(3,'R260925A1B2D0',2,3,2,'Membresía Mensual',549,'efectivo',3,'pagado',NULL,NULL,NULL,'2026-09-25 09:30:00',NULL,NULL,NULL,'2026-09-25 09:30:00'),
(4,'R260911A1B2DA',3,4,5,'Membresía Estudiante',399,'transferencia',3,'pagado',NULL,NULL,NULL,'2026-09-11 09:30:00',NULL,NULL,NULL,'2026-09-11 09:30:00');
INSERT INTO `detalle_pagos` (`id`,`pago_id`,`descripcion`,`cantidad`,`precio_unitario`,`descuento`,`subtotal`) VALUES
(1,1,'Membresía Mensual',1,549,0,549),
(2,2,'Membresía Trimestral',1,1499,0,1499),
(3,3,'Membresía Mensual',1,549,0,549),
(4,4,'Membresía Estudiante',1,399,0,399);
INSERT INTO `categorias_contables` (`id`,`nombre`,`tipo`) VALUES
(1,'Membresías','ingreso');
INSERT INTO `resultados_acceso` (`codigo`,`nombre`,`acceso_permitido`) VALUES
('permitido','Permitido',1),
('membresia_vencida','Membresía vencida',0),
('sin_membresia','Sin membresía',0),
('codigo_invalido','Código inválido',0);
INSERT INTO `asistencias` (`id`,`socio_id`,`codigo_leido`,`resultado`,`motivo`,`tipo_movimiento`,`registrado_por`,`creado_en`) VALUES
(1,1,'FC260000013','permitido',NULL,'entrada',3,'2026-09-16 13:06:00'),
(2,1,'FC260000013','permitido',NULL,'salida',3,'2026-09-16 14:49:00'),
(3,1,'FC260000013','permitido',NULL,'entrada',3,'2026-09-18 10:59:00'),
(4,1,'FC260000013','permitido',NULL,'salida',3,'2026-09-18 12:31:00'),
(5,1,'FC260000013','permitido',NULL,'entrada',3,'2026-09-20 07:52:00'),
(6,1,'FC260000013','permitido',NULL,'salida',3,'2026-09-20 09:13:00'),
(7,1,'FC260000013','permitido',NULL,'entrada',3,'2026-09-22 16:45:00'),
(8,1,'FC260000013','permitido',NULL,'salida',3,'2026-09-22 17:55:00'),
(9,1,'FC260000013','permitido',NULL,'entrada',3,'2026-09-24 13:38:00'),
(10,1,'FC260000013','permitido',NULL,'salida',3,'2026-09-24 14:37:00'),
(11,1,'FC260000013','permitido',NULL,'entrada',3,'2026-09-26 10:31:00'),
(12,1,'FC260000013','permitido',NULL,'salida',3,'2026-09-26 12:09:00'),
(13,1,'FC260000013','permitido',NULL,'entrada',3,'2026-09-28 07:24:00'),
(14,1,'FC260000013','permitido',NULL,'salida',3,'2026-09-28 08:51:00'),
(15,1,'FC260000013','permitido',NULL,'entrada',3,'2026-09-30 16:17:00'),
(16,1,'FC260000013','permitido',NULL,'salida',3,'2026-09-30 17:33:00'),
(17,1,'FC260000013','permitido',NULL,'entrada',3,'2026-10-02 13:10:00'),
(18,1,'FC260000013','permitido',NULL,'salida',3,'2026-10-02 14:15:00'),
(19,1,'FC260000013','permitido',NULL,'entrada',3,'2026-10-04 10:03:00'),
(20,1,'FC260000013','permitido',NULL,'salida',3,'2026-10-04 11:47:00'),
(21,1,'FC260000013','permitido',NULL,'entrada',3,'2026-10-06 07:56:00'),
(22,1,'FC260000013','permitido',NULL,'salida',3,'2026-10-06 09:29:00'),
(23,1,'FC260000013','permitido',NULL,'entrada',3,'2026-10-08 16:49:00'),
(24,1,'FC260000013','permitido',NULL,'salida',3,'2026-10-08 18:11:00'),
(25,1,'FC260000013','permitido',NULL,'entrada',3,'2026-10-10 13:42:00'),
(26,1,'FC260000013','permitido',NULL,'salida',3,'2026-10-10 14:53:00'),
(27,1,'FC260000013','permitido',NULL,'entrada',3,'2026-10-12 10:35:00'),
(28,1,'FC260000013','permitido',NULL,'salida',3,'2026-10-12 11:35:00'),
(29,1,'FC260000013','permitido',NULL,'entrada',3,'2026-10-14 07:28:00'),
(30,1,'FC260000013','permitido',NULL,'salida',3,'2026-10-14 09:07:00'),
(31,1,'FC260000013','permitido',NULL,'entrada',3,'2026-10-16 16:21:00'),
(32,1,'FC260000013','permitido',NULL,'salida',3,'2026-10-16 17:49:00'),
(33,1,'FC260000013','permitido',NULL,'entrada',3,'2026-10-18 13:14:00'),
(34,1,'FC260000013','permitido',NULL,'salida',3,'2026-10-18 14:31:00'),
(35,1,'FC260000013','permitido',NULL,'entrada',3,'2026-10-20 10:07:00'),
(36,1,'FC260000013','permitido',NULL,'salida',3,'2026-10-20 11:13:00'),
(37,2,'FC260000021','permitido',NULL,'entrada',3,'2026-10-03 11:03:00'),
(38,2,'FC260000021','permitido',NULL,'salida',3,'2026-10-03 12:47:00'),
(39,2,'FC260000021','permitido',NULL,'entrada',3,'2026-10-05 08:56:00'),
(40,2,'FC260000021','permitido',NULL,'salida',3,'2026-10-05 10:29:00'),
(41,2,'FC260000021','permitido',NULL,'entrada',3,'2026-10-07 17:49:00'),
(42,2,'FC260000021','permitido',NULL,'salida',3,'2026-10-07 19:11:00'),
(43,2,'FC260000021','permitido',NULL,'entrada',3,'2026-10-09 14:42:00'),
(44,2,'FC260000021','permitido',NULL,'salida',3,'2026-10-09 15:53:00'),
(45,2,'FC260000021','permitido',NULL,'entrada',3,'2026-10-11 11:35:00'),
(46,2,'FC260000021','permitido',NULL,'salida',3,'2026-10-11 12:35:00'),
(47,2,'FC260000021','permitido',NULL,'entrada',3,'2026-10-13 08:28:00'),
(48,2,'FC260000021','permitido',NULL,'salida',3,'2026-10-13 10:07:00'),
(49,2,'FC260000021','permitido',NULL,'entrada',3,'2026-10-15 17:21:00'),
(50,2,'FC260000021','permitido',NULL,'salida',3,'2026-10-15 18:49:00'),
(51,2,'FC260000021','permitido',NULL,'entrada',3,'2026-10-17 14:14:00'),
(52,2,'FC260000021','permitido',NULL,'salida',3,'2026-10-17 15:31:00'),
(53,2,'FC260000021','permitido',NULL,'entrada',3,'2026-10-19 11:07:00'),
(54,2,'FC260000021','permitido',NULL,'salida',3,'2026-10-19 12:13:00'),
(55,3,'FC260000039','permitido',NULL,'entrada',3,'2026-10-14 09:28:00'),
(56,3,'FC260000039','permitido',NULL,'salida',3,'2026-10-14 11:07:00'),
(57,3,'FC260000039','permitido',NULL,'entrada',3,'2026-10-16 06:21:00'),
(58,3,'FC260000039','permitido',NULL,'salida',3,'2026-10-16 07:49:00'),
(59,3,'FC260000039','permitido',NULL,'entrada',3,'2026-10-18 15:14:00'),
(60,3,'FC260000039','permitido',NULL,'salida',3,'2026-10-18 16:31:00'),
(61,3,'FC260000039','permitido',NULL,'entrada',3,'2026-10-20 12:07:00'),
(62,3,'FC260000039','permitido',NULL,'salida',3,'2026-10-20 13:13:00');
INSERT INTO `estados_equipo` (`codigo`,`nombre`,`disponible_uso`) VALUES
('operativo','Operativo',1),
('mantenimiento','En mantenimiento',0),
('baja','Dado de baja',0);
INSERT INTO `equipos` (`id`,`nombre`,`ubicacion`,`estado`) VALUES
(1,'Caminadora 01','Cardio','operativo'),
(2,'Caminadora 02','Cardio','operativo'),
(3,'Caminadora 03','Cardio','operativo'),
(4,'Elíptica 01','Cardio','operativo'),
(5,'Bicicleta fija 01','Cardio','operativo'),
(6,'Remo 01','Cardio','mantenimiento'),
(7,'Rack de sentadilla 01','Pesas libres','operativo'),
(8,'Rack de sentadilla 02','Pesas libres','operativo'),
(9,'Banco plano 01','Pesas libres','operativo'),
(10,'Banco inclinado 01','Pesas libres','operativo'),
(11,'Prensa de pierna','Máquinas','operativo'),
(12,'Polea alta','Máquinas','operativo'),
(13,'Extensión de pierna','Máquinas','operativo'),
(14,'Smith','Máquinas','operativo'),
(15,'Peck deck','Máquinas','operativo'),
(16,'Remo sentado','Máquinas','operativo');
INSERT INTO `uso_equipos` (`id`,`equipo_id`,`socio_id`,`inicio`,`fin`,`registrado_por`) VALUES
(1,1,NULL,'2026-10-21 15:49:36',NULL,3),
(2,4,NULL,'2026-10-21 15:49:36',NULL,3),
(3,7,NULL,'2026-10-21 15:49:36',NULL,3),
(4,10,NULL,'2026-10-21 15:49:36',NULL,3),
(5,12,NULL,'2026-10-21 15:49:36',NULL,3),
(6,16,NULL,'2026-10-21 15:49:36',NULL,3);
INSERT INTO `expedientes` (`id`,`socio_id`,`objetivo_principal`,`nivel`,`dias_entrenamiento`,`actualizado_por`,`creado_en`,`actualizado_en`) VALUES
(1,1,'recomposicion','intermedio',4,4,'2026-10-21 15:49:36','2026-10-21 15:49:36'),
(2,2,NULL,NULL,NULL,NULL,'2026-10-21 15:49:36','2026-10-21 15:49:36'),
(3,3,NULL,NULL,NULL,NULL,'2026-10-21 15:49:36','2026-10-21 15:49:36');
INSERT INTO `mediciones` (`id`,`expediente_id`,`fecha_medicion`,`peso_kg`,`estatura_cm`,`imc`,`porcentaje_grasa`,`porcentaje_musculo`,`registrado_por`) VALUES
(1,1,'2026-08-22 08:00:00',70.1,165,25.7,25.4,30.1,4),
(2,1,'2026-09-21 08:00:00',68.5,165,25.2,24.1,30.9,4),
(3,1,'2026-10-18 08:00:00',67.2,165,24.7,23,31.6,4);
INSERT INTO `ejercicios` (`id`,`nombre`,`activo`) VALUES
(1,'Press de banca con mancuernas',1),
(2,'Dominadas asistidas',1),
(3,'Press militar con mancuernas',1),
(4,'Remo con mancuerna a una mano',1),
(5,'Elevaciones laterales con mancuerna',1),
(6,'Sentadilla goblet',1),
(7,'Peso muerto rumano con barra',1),
(8,'Zancadas con mancuernas',1),
(9,'Curl femoral acostado',1),
(10,'Hip thrust con barra',1);
INSERT INTO `rutinas` (`id`,`nombre`,`objetivo`,`nivel`,`dias_por_semana`,`creador_usuario_id`,`es_plantilla`,`creada_en`) VALUES
(1,'Recomposición corporal · 4 días','recomposicion','intermedio',4,4,0,'2026-10-21 15:49:36');
INSERT INTO `rutina_ejercicios` (`id`,`rutina_id`,`ejercicio_id`,`dia_numero`,`enfoque`,`orden`,`series`,`repeticiones`,`descanso_segundos`) VALUES
(1,1,1,1,'Tren superior',1,4,'8-12',75),
(2,1,2,1,'Tren superior',2,4,'8-12',75),
(3,1,3,1,'Tren superior',3,4,'8-12',75),
(4,1,4,1,'Tren superior',4,4,'8-12',75),
(5,1,5,1,'Tren superior',5,3,'12-15',60),
(6,1,6,2,'Tren inferior',1,4,'8-12',75),
(7,1,7,2,'Tren inferior',2,4,'8-12',75),
(8,1,8,2,'Tren inferior',3,4,'8-12',75),
(9,1,9,2,'Tren inferior',4,3,'12-15',60),
(10,1,10,2,'Tren inferior',5,4,'8-12',75),
(11,1,1,3,'Tren superior',1,4,'8-12',75),
(12,1,2,3,'Tren superior',2,4,'8-12',75),
(13,1,3,3,'Tren superior',3,4,'8-12',75),
(14,1,4,3,'Tren superior',4,4,'8-12',75),
(15,1,5,3,'Tren superior',5,3,'12-15',60),
(16,1,6,4,'Tren inferior',1,4,'8-12',75),
(17,1,7,4,'Tren inferior',2,4,'8-12',75),
(18,1,8,4,'Tren inferior',3,4,'8-12',75),
(19,1,9,4,'Tren inferior',4,3,'12-15',60),
(20,1,10,4,'Tren inferior',5,4,'8-12',75);
INSERT INTO `rutinas_socio` (`id`,`socio_id`,`rutina_id`,`instructor_id`,`fecha_inicio`,`fecha_fin`,`estado`,`asignada_en`) VALUES
(1,1,1,1,'2026-10-07',NULL,'activa','2026-10-21 15:49:36');

SET FOREIGN_KEY_CHECKS = 1;
