<?php
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
$tmp = sys_get_temp_dir() . '/fitcode_export_' . getmypid() . '.sqlite';
@unlink($tmp);
putenv("FITCODE_SQLITE=$tmp");
putenv('FITCODE_DB=sqlite');
require dirname(__DIR__) . '/includes/bootstrap.php';

$ddl = esquema_sql('mysql');
preg_match_all('/CREATE TABLE (\w+)/', implode("\n", $ddl), $m);
$tablas = $m[1];

$out = "CREATE DATABASE IF NOT EXISTS gimnasio_integral_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\nUSE gimnasio_integral_db;\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n";
foreach (array_reverse($tablas) as $t) $out .= "DROP TABLE IF EXISTS `$t`;\n";
$out .= "\n" . implode(";\n\n", array_map('trim', $ddl)) . ";\n\n";
$pdo = db();
foreach ($tablas as $t) {
    $rows = qa("SELECT * FROM $t");
    if (!$rows) continue;
    $cols = '`' . implode('`,`', array_keys($rows[0])) . '`';
    $vals = array_map(fn($r) => '(' . implode(',', array_map(fn($v) => $v === null ? 'NULL' : (is_int($v) || is_float($v) ? $v : $pdo->quote((string)$v)), $r)) . ')', $rows);
    foreach (array_chunk($vals, 200) as $chunk) $out .= "INSERT INTO `$t` ($cols) VALUES\n" . implode(",\n", $chunk) . ";\n";
}
$out .= "\nSET FOREIGN_KEY_CHECKS = 1;\n";
file_put_contents(__DIR__ . '/fitcode_mysql.sql', $out);
@unlink($tmp); @unlink("$tmp-wal"); @unlink("$tmp-shm");
echo 'OK · ' . count($tablas) . " tablas · database/fitcode_mysql.sql (" . round(strlen($out) / 1024) . " KB)\n";
