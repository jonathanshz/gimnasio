<?php
require __DIR__ . '/includes/bootstrap.php';
if (es_post()) csrf_verificar();
Sesion::cerrar('socio');
flash('ok', 'Sesión cerrada. ¡Buen entrenamiento!');
redirect('index.php');
