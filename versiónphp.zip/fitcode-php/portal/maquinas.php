<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$s = requiere_socio();
Equipos::simularMovimiento();
$L = Equipos::listar();
$zona = $_GET['zona'] ?? 'TODAS';
$zonas = array_values(array_unique(array_column($L, 'ubicacion')));
$c = ['LIBRE' => 0, 'OCUPADA' => 0, 'MANTENIMIENTO' => 0]; foreach ($L as $m) $c[$m['disponibilidad']]++;
$t = max(1, count($L));
portal_inicio('Máquinas disponibles', 'maquinas', $s); ?>
<section data-autorefresh="15">
  <div class="grid g-3" style="margin-bottom:18px"><div class="card kpi rise"><span class="label">Libres</span><strong style="color:var(--ok)"><?= $c['LIBRE'] ?></strong></div><div class="card kpi rise rise-2"><span class="label">Ocupadas</span><strong style="color:var(--warn)"><?= $c['OCUPADA'] ?></strong></div><div class="card kpi rise rise-3"><span class="label">En mantenimiento</span><strong class="muted"><?= $c['MANTENIMIENTO'] ?></strong></div></div>
  <div class="card rise rise-3"><div class="card-head"><div class="filters" role="group" aria-label="Filtrar por zona">
      <?php foreach (array_merge(['TODAS'], $zonas) as $z): ?><a class="<?= $z === $zona ? 'on' : '' ?>" href="<?= url('portal/maquinas.php?zona=' . urlencode($z)) ?>"><?= $z === 'TODAS' ? 'Todas' : e($z) ?></a><?php endforeach; ?></div>
    <span class="hint mono"><span class="dot dot-live"></span> En vivo · <?= date('H:i:s') ?></span></div>
    <div class="occupancy" style="margin-bottom:18px"><i style="width:<?= $c['LIBRE'] / $t * 100 ?>%;background:var(--ok)"></i><i style="width:<?= $c['OCUPADA'] / $t * 100 ?>%;background:var(--warn)"></i><i style="width:<?= $c['MANTENIMIENTO'] / $t * 100 ?>%;background:var(--dim)"></i></div>
    <div class="machine-grid"><?php foreach ($L as $m) if ($zona === 'TODAS' || $m['ubicacion'] === $zona): ?>
      <div class="machine <?= $m['disponibilidad'] ?>"><div class="machine-top"><span class="zone"><?= e($m['ubicacion']) ?></span><?= badge($m['disponibilidad']) ?></div><strong><?= e($m['nombre']) ?></strong></div>
    <?php endif; ?></div>
  </div>
</section>
<?php shell_fin();
