<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$s = requiere_socio(); $sid = (int)$s['id'];
$m = Membresias::actual($sid); $dentro = Asistencias::dentro($sid); $ultima = Asistencias::visitas($sid, 1)[0] ?? null; $ficha = Pagos::fichaPendiente($sid);
$maq = Equipos::listar(); $libres = count(array_filter($maq, fn($x) => $x['disponibilidad'] === 'LIBRE'));
$dias = []; for ($i = 13; $i >= 0; $i--) $dias[mas_dias(hoy(), -$i)] = 0;
foreach (Asistencias::visitas($sid, 60) as $v) { $k = substr($v['entrada'], 0, 10); if (isset($dias[$k])) $dias[$k]++; }
$racha = 0; foreach (array_reverse($dias, true) as $k => $n) { if ($n) $racha++; elseif ($k !== hoy()) break; }
$max = max(1, max($dias));

if ($ficha) $alerta = alerta('warn', 'receipt', 'Tienes una ficha de pago en efectivo por <strong>' . dinero($ficha['monto']) . '</strong>. Preséntala en recepción: <a class="link" href="' . url('portal/ficha.php') . '">ver ficha ' . e($ficha['referencia_pago']) . '</a>.');
elseif (!$m) $alerta = alerta('warn', 'alert', 'Aún no tienes membresía. <a class="link" href="' . url('portal/pagos.php') . '">Elige tu plan y paga con tarjeta o en efectivo</a>; tu código se activa al confirmarse el pago.');
elseif ($m['estado_real'] === 'vencida') $alerta = alerta('bad', 'alert', 'Tu membresía venció el ' . fecha_mx($m['fecha_fin']) . '. <a class="link" href="' . url('portal/pagos.php') . '">Renueva aquí</a>.');
elseif ($m['por_vencer']) $alerta = alerta('warn', 'clock', "Tu membresía vence en {$m['dias_restantes']} día(s). <a class=\"link\" href=\"" . url('portal/pagos.php') . '">Renueva</a> para no perder tu acceso.');
else $alerta = '';

portal_inicio('Mi acceso', 'inicio', $s); ?>
<div class="grid g-main">
  <section class="card access corners rise">
    <div class="access-top"><div><p class="card-kicker" style="margin-bottom:6px">Credencial digital</p><h2 class="card-title">Muestra este código en recepción</h2></div><?= $m ? badge($m['estado_real']) : badge('pendiente', 'sin membresía') ?></div>
    <div class="access-body">
      <div class="barcode-plate"><span class="laser" aria-hidden="true"></span><?= barcode_svg($s['codigo_credencial'], 118, 2.0, '#07080a') ?><div class="code-txt"><span><?= e($s['codigo_credencial']) ?></span><span>FIT·CODE</span></div></div>
      <div class="access-meta">
        <div><span class="label">Socio</span><strong><?= e($s['nombre'] . ' ' . $s['apellido_paterno']) ?></strong></div>
        <div><span class="label">Plan</span><strong><?= e($m['plan'] ?? 'Sin asignar') ?></strong></div>
        <div><span class="label">Vence</span><strong class="mono"><?= $m ? fecha_mx($m['fecha_fin']) : '—' ?></strong></div>
        <div><span class="label">Tipo</span><strong><?= $s['tipo_socio'] === 'menor' ? 'Menor de edad' : 'Mayor de edad' ?></strong></div>
      </div>
      <?= $alerta ?>
      <div class="access-state"><?php if ($dentro): ?><span class="dot dot-live"></span><span>Estás <strong>dentro del gimnasio</strong> desde las <span class="mono"><?= hora_de($dentro['entrada']) ?></span>. Escanea al salir.</span>
        <?php else: ?><span class="dot"></span><span class="muted">Fuera del gimnasio · última visita: <span class="mono"><?= $ultima ? fecha_mx($ultima['entrada'], true) : 'sin registros' ?></span></span><?php endif; ?></div>
      <div class="row row-between no-print"><p class="hint" style="margin:0">Sube el brillo de tu pantalla para un escaneo más rápido.</p><a class="btn btn-sm" href="<?= url('portal/codigo.php') ?>"><?= icon('scan', 16) ?> Pantalla completa</a></div>
    </div>
  </section>
  <div class="grid" style="align-content:start">
    <nav class="quick rise rise-2" aria-label="Opciones del socio">
      <a href="<?= url('portal/asignacion.php') ?>"><?= icon('id', 22) ?><span>Asignación y tipo de membresía<small>Tu plan y catálogo</small></span></a>
      <a href="<?= url('portal/membresia.php') ?>"><?= icon('card', 22) ?><span>Consulta tu membresía<small><?= $m ? $m['dias_restantes'] . ' días restantes' : 'Sin plan activo' ?></small></span></a>
      <a href="<?= url('portal/pagos.php') ?>"><?= icon('receipt', 22) ?><span>Pagos, recibos y cambio de plan<small>Tarjeta o efectivo</small></span></a>
      <a href="<?= url('portal/avance.php') ?>"><?= icon('chart', 22) ?><span>Avance, rutina y nutrición<small>Tu plan semanal</small></span></a>
    </nav>
    <a href="<?= url('portal/maquinas.php') ?>" class="card rise rise-3" style="display:grid;gap:14px">
      <div class="row row-between"><p class="card-kicker" style="margin:0">Máquinas en este momento</p><?= icon('arrow', 18) ?></div>
      <div class="row" style="align-items:baseline;gap:8px"><strong style="font:500 34px/1 var(--f-display)"><?= $libres ?></strong><span class="muted">de <?= count($maq) ?> libres</span></div>
      <div class="occupancy"><i style="width:<?= $libres / max(1, count($maq)) * 100 ?>%;background:var(--ok)"></i></div></a>
    <div class="card rise rise-4">
      <div class="row row-between" style="margin-bottom:16px"><p class="card-kicker" style="margin:0">Asistencia · 14 días</p><span class="chip mono"><?= icon('bolt', 14) ?> Racha: <?= $racha ?> día(s)</span></div>
      <div class="bars" role="img" aria-label="Asistencias de los últimos 14 días"><?php foreach ($dias as $k => $n): ?><i class="<?= $n ? 'on' : '' ?>" style="height:<?= $n ? max(18, $n / $max * 100) : 4 ?>%" title="<?= fecha_mx($k) ?>: <?= $n ?>"></i><?php endforeach; ?></div>
      <div class="bars-x"><span><?= fecha_mx(array_key_first($dias)) ?></span><span>hoy</span></div>
    </div>
  </div>
</div>
<?php shell_fin();
