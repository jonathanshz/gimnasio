<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$s = requiere_socio(); $sid = (int)$s['id'];
$m = Membresias::actual($sid);
portal_inicio('Consulta tu membresía', 'membresia', $s);
if (!$m): ?>
  <div class="card corners rise" style="max-width:640px"><div class="empty"><?= icon('card', 40) ?><h2 class="title">Aún no tienes membresía</h2><p class="muted">Tu cuenta está lista. Elige un plan y paga con tarjeta o en efectivo en recepción.</p><a href="<?= url('portal/pagos.php') ?>" class="btn btn-primary" style="margin-top:12px">Elegir plan <?= icon('arrow', 18) ?></a></div></div>
<?php shell_fin(); exit; endif;
$hist = Membresias::historial($sid); $sig = Membresias::siguiente($sid); $vis = Asistencias::visitas($sid);
$pago = null; foreach (Pagos::porSocio($sid) as $p) if ((int)$p['membresia_id'] === (int)$m['id']) $pago = $p;
$a30 = Asistencias::contarDesde($sid, 30);
$enPeriodo = count(array_filter($vis, fn($v) => $v['entrada'] >= $m['fecha_inicio']));
$rec = array_slice($vis, 0, 8);
$dur = array_map(fn($v) => (strtotime($v['salida']) - strtotime($v['entrada'])) / 60, array_filter($vis, fn($v) => $v['salida'] && $v['entrada'] >= mas_dias(hoy(), -30)));
$prom = $dur ? (int)round(array_sum($dur) / count($dur)) : 0;
$hc = []; foreach ($rec as $v) { $h = (int)date('G', strtotime($v['entrada'])); $hc[$h] = ($hc[$h] ?? 0) + 1; } arsort($hc); $fav = $hc ? array_key_first($hc) : null;
$ring = $m['estado_real'] === 'vencida' ? 'bad' : ($m['por_vencer'] ? 'warn' : '');
$durTxt = function ($v) { if (!$v['salida']) return '—'; $mi = (int)round((strtotime($v['salida']) - strtotime($v['entrada'])) / 60); return intdiv($mi, 60) . 'h ' . pad($mi % 60) . 'm'; };
?>
<div class="grid g-main">
  <section class="card corners rise">
    <div class="card-head"><div><p class="card-kicker">Membresía <span class="mono">#MEM-<?= pad($m['id'], 6) ?></span></p><h2 class="plan-name"><?= e($m['plan']) ?></h2><p class="muted" style="margin:0"><?= e($m['descripcion']) ?></p></div><?= badge($m['estado_real']) ?></div>
    <?php if ($m['estado_real'] === 'vencida') echo alerta('bad', 'alert', 'Tu membresía venció el <strong>' . fecha_mx($m['fecha_fin']) . '</strong>. Tu código de acceso no permitirá la entrada hasta renovar.', ' style="margin-bottom:20px"');
      elseif ($m['por_vencer']) echo alerta('warn', 'clock', "Quedan <strong>{$m['dias_restantes']} día(s)</strong>. Renueva antes del " . fecha_mx($m['fecha_fin']) . ' para no interrumpir tu acceso.', ' style="margin-bottom:20px"');
      if ($sig) echo alerta('ok', 'check', 'Ya tienes pagada tu siguiente membresía <strong>' . e($sig['plan']) . '</strong>: inicia el ' . fecha_mx($sig['fecha_inicio']) . '.', ' style="margin-bottom:20px"'); ?>
    <div class="ring-wrap">
      <div class="ring <?= $ring ?>" data-pct="<?= $m['porcentaje'] ?>" role="img" aria-label="<?= $m['dias_restantes'] ?> días restantes"><svg viewBox="0 0 160 160"><circle class="track" cx="80" cy="80" r="70" fill="none" stroke-width="8"/><circle class="bar" cx="80" cy="80" r="70" fill="none" stroke-width="8"/></svg>
        <div class="ring-center"><strong><?= $m['dias_restantes'] ?></strong><small>días<br>restantes</small></div></div>
      <dl class="dl" style="flex:1;min-width:240px">
        <div><dt>Inicio</dt><dd class="mono"><?= fecha_mx($m['fecha_inicio']) ?></dd></div><div><dt>Vencimiento</dt><dd class="mono"><?= fecha_mx($m['fecha_fin']) ?></dd></div>
        <div><dt>Duración</dt><dd><?= $m['dias_totales'] ?> días</dd></div><div><dt>Precio aplicado</dt><dd class="mono"><?= dinero($m['precio_aplicado']) ?></dd></div>
        <div><dt>Pagado con</dt><dd><?= $pago ? e(METODO_NOMBRE[$pago['metodo']]) . ($pago['tarjeta_ultimos4'] ? ' ···· ' . e($pago['tarjeta_ultimos4']) : '') : '—' ?></dd></div><div><dt>Código de acceso</dt><dd class="mono"><?= e($s['codigo_credencial']) ?></dd></div>
      </dl>
    </div>
    <div class="divider" style="margin:26px 0 18px">Incluye</div>
    <ul class="benefits"><?php foreach ($m['beneficios'] as $b): ?><li><?= icon('check', 16) . e($b) ?></li><?php endforeach; ?></ul>
    <div class="actions no-print" style="margin-top:24px"><a href="<?= url('portal/pagos.php') ?>" class="btn btn-primary"><?= icon('refresh', 18) ?> Renovar o cambiar plan</a><button type="button" class="btn btn-ghost" onclick="window.print()"><?= icon('print', 18) ?> Imprimir comprobante</button></div>
  </section>
  <div class="grid" style="align-content:start">
    <div class="grid g-2">
      <div class="card kpi rise rise-2"><span class="label">Visitas · 30 días</span><strong><?= $a30 ?></strong><span class="trend">≈ <?= number_format($a30 / 4.3, 1) ?> por semana</span></div>
      <div class="card kpi rise rise-2"><span class="label">En este periodo</span><strong><?= $enPeriodo ?></strong><span class="trend">desde <?= fecha_mx($m['fecha_inicio']) ?></span></div>
      <div class="card kpi rise rise-3"><span class="label">Sesión promedio</span><strong><?= $prom ?><small>min</small></strong><span class="trend">últimos 30 días</span></div>
      <div class="card kpi rise rise-3"><span class="label">Hora favorita</span><strong><?= $fav !== null ? pad($fav) . ':00' : '—' ?></strong><span class="trend">según tus entradas</span></div>
    </div>
    <div class="card rise rise-4"><p class="card-kicker">Historial de membresías</p>
      <ul class="timeline"><?php foreach ($hist as $h): ?><li class="<?= (int)$h['id'] === (int)$m['id'] ? 'now' : '' ?>"><div class="row row-between"><strong><?= e($h['plan']) ?></strong><?= badge($h['estado_real']) ?></div><span class="hint mono"><?= fecha_mx($h['fecha_inicio']) ?> → <?= fecha_mx($h['fecha_fin']) ?></span></li><?php endforeach; ?></ul></div>
  </div>
  <section class="card rise rise-4" style="grid-column:1/-1"><div class="card-head"><div><p class="card-kicker">Registro de asistencia</p><h3 class="card-title">Entradas y salidas recientes</h3></div></div>
    <?php if ($rec): ?><div class="table-wrap"><table class="t"><thead><tr><th>Fecha</th><th>Entrada</th><th>Salida</th><th class="num">Duración</th></tr></thead><tbody>
      <?php foreach ($rec as $v): ?><tr><td><?= fecha_mx($v['entrada']) ?></td><td class="mono"><?= hora_de($v['entrada']) ?></td><td class="mono"><?= $v['salida'] ? hora_de($v['salida']) : '<span class="badge badge-ok">DENTRO</span>' ?></td><td class="num"><?= $durTxt($v) ?></td></tr><?php endforeach; ?>
    </tbody></table></div><?php else: ?><div class="empty"><?= icon('clock', 32) ?>Aún no tienes visitas registradas.</div><?php endif; ?>
  </section>
</div>
<?php shell_fin();
