<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$s = requiere_socio(); $sid = (int)$s['id'];

if (es_post()) {
    csrf_verificar();
    if (($_POST['accion'] ?? '') === 'perfil') {
        if ($e = guardar_perfil($sid, $_POST, null)) flash('error', $e);
        else { flash('ok', 'Listo: tu rutina y tu plan nutricional se generaron con tus datos.'); redirect('portal/avance.php?tab=rutina'); }
        redirect('portal/avance.php?tab=objetivo');
    }
    if (($_POST['accion'] ?? '') === 'medicion') {
        if ($e = validar_medicion($_POST)) flash('error', $e);
        else { $r = Mediciones::registrar($sid, $_POST, null); flash('ok', 'Medición guardada. Tu IMC ahora es ' . num($r['imc']) . '.'); }
        redirect('portal/avance.php');
    }
}
$F = datos_fitness($s);
$tab = in_array($_GET['tab'] ?? '', ['resumen', 'rutina', 'nutricion', 'objetivo'], true) ? $_GET['tab'] : 'resumen';
$tabs = function ($t) {
    $h = '<nav class="tabs">';
    foreach (['resumen' => 'Progreso e IMC', 'rutina' => 'Rutina semanal', 'nutricion' => 'Plan nutricional sugerido', 'objetivo' => 'Objetivo'] as $k => $n) $h .= '<a href="' . url("portal/avance.php?tab=$k") . '" class="' . ($k === $t ? 'on' : '') . '">' . $n . '</a>';
    return $h . '</nav>';
};
portal_inicio('Avance, rutina y nutrición', 'avance', $s);
if (!$F || $tab === 'objetivo') {
    $meds = Mediciones::porSocio($sid);
    echo ($F ? $tabs('objetivo') : '') . onboarding_html(Expedientes::obtener($sid), end($meds) ?: null, (int)$s['edad'], 'perfil', '', $F ? 'Ajustar objetivo' : 'Primer paso');
} else {
    $o = OBJETIVOS[$F['objetivo']];
    echo $tabs($tab);
    if ($tab === 'resumen') {
        echo '<div class="goalbar card rise">' . icon($o['icono'], 24) . '<div><span class="label">Objetivo</span><strong>' . e($o['nombre']) . '</strong></div><div><span class="label">Nivel</span><strong>' . NIVELES[$F['nivel']] . '</strong></div>'
            . '<div><span class="label">Entrena</span><strong>' . $F['dias'] . ' días/sem</strong></div><div><span class="label">Edad</span><strong>' . $s['edad'] . ' años</strong></div><div><span class="label">Estatura</span><strong>' . num($F['estatura']) . ' cm</strong></div>'
            . '<a class="btn btn-sm" href="' . url('portal/avance.php?tab=objetivo') . '">Cambiar</a></div>' . progreso_html($F, (int)$s['edad'], 'medicion');
    } elseif ($tab === 'rutina') {
        $a = Rutinas::asignada($sid);
        echo ($a ? rutina_asignada_html($a) : '') . plan_html(generar_plan($F));
    } else {
        echo nutricion_html(plan_nutricional($F));
    }
}
shell_fin();
