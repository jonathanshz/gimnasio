<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$s = requiere_socio(); $sid = (int)$s['id'];
$p = Planes::porId((int)($_GET['plan'] ?? $_POST['plan'] ?? 0)) ?? redirect('portal/pagos.php');
$metodo = ($_GET['metodo'] ?? $_POST['metodo'] ?? 'tarjeta') === 'efectivo' ? 'efectivo' : 'tarjeta';
$m = Membresias::actual($sid); $err = null;
$luhn = function (string $n) { $s = 0; foreach (str_split(strrev($n)) as $i => $c) { $x = (int)$c; if ($i % 2) { $x *= 2; if ($x > 9) $x -= 9; } $s += $x; } return $s % 10 === 0; };
$marca = fn(string $n) => preg_match('/^4/', $n) ? 'VISA' : (preg_match('/^(5[1-5]|2[2-7])/', $n) ? 'MASTERCARD' : (preg_match('/^3[47]/', $n) ? 'AMEX' : null));

if (es_post()) {
    csrf_verificar();
    if ($metodo === 'efectivo') {
        Pagos::crearFicha($sid, (int)$p['id']);
        flash('ok', 'Ficha generada. Preséntala en recepción para activar tu membresía.');
        redirect('portal/ficha.php');
    }
    $n = preg_replace('/\D/', '', $_POST['numero'] ?? ''); $b = $marca($n);
    [$mm, $aa] = array_map('intval', explode('/', ($_POST['exp'] ?? '') . '/')) + [0, 0];
    $cvv = $_POST['cvv'] ?? '';
    if (mb_strlen(mayus($_POST['titular'] ?? '')) < 5) $err = 'Escribe el nombre del titular como aparece en la tarjeta.';
    elseif (!$b || strlen($n) < 15 || !$luhn($n)) $err = 'El número de tarjeta no es válido.';
    elseif ($mm < 1 || $mm > 12 || !$aa || date('Y-m-t', mktime(0, 0, 0, $mm, 1, 2000 + $aa)) < hoy()) $err = 'La fecha de vencimiento no es válida o la tarjeta ya venció.';
    elseif (!preg_match($b === 'AMEX' ? '/^\d{4}$/' : '/^\d{3}$/', $cvv)) $err = 'El CVV no es válido.';
    else {
        $r = Pagos::pagarTarjeta($sid, (int)$p['id'], $b, substr($n, -4), $n !== '4000000000000002');
        if ($r['ok']) { flash('ok', "Pago aprobado. Tu membresía {$r['pago']['plan']} quedó activa."); redirect('portal/recibo.php?folio=' . urlencode($r['pago']['folio'])); }
        $err = $r['error'];
    }
}
$ini = $m && $m['estado_real'] === 'activa' ? mas_dias($m['fecha_fin'], 1) : hoy();
$fin = mas_dias($ini, $p['duracion_dias'] - 1);
$tipo = !$m || $m['estado_real'] !== 'activa' ? ($m ? 'Renovación' : 'Nueva membresía') : ((int)$m['tipo_membresia_id'] === (int)$p['id'] ? 'Renovación anticipada' : 'Cambio de plan');
portal_inicio('Pagar membresía', 'pagos', $s); ?>
<a href="<?= url('portal/pagos.php') ?>" class="btn btn-ghost btn-sm" style="margin-bottom:18px"><?= icon('back', 16) ?> Volver a planes</a>
<div class="grid g-main">
  <section class="card rise">
    <p class="card-kicker">Método de pago</p>
    <div class="paytabs" role="tablist">
      <a href="<?= url("portal/pagar.php?plan={$p['id']}&metodo=tarjeta") ?>" class="<?= $metodo === 'tarjeta' ? 'on' : '' ?>"><?= icon('card', 20) ?><span><strong>Tarjeta</strong><small>Débito o crédito · se activa al instante</small></span></a>
      <a href="<?= url("portal/pagar.php?plan={$p['id']}&metodo=efectivo") ?>" class="<?= $metodo === 'efectivo' ? 'on' : '' ?>"><?= icon('receipt', 20) ?><span><strong>Efectivo</strong><small>Paga en recepción con tu ficha</small></span></a>
    </div>
    <?php if ($err) echo alerta('bad', 'alert', e($err), ' role="alert" style="margin:18px 0 0"'); ?>
    <?php if ($metodo === 'tarjeta'): ?>
    <form method="post" class="form" style="margin-top:20px" novalidate autocomplete="off" data-processing><?= csrf_field() ?><input type="hidden" name="plan" value="<?= $p['id'] ?>"><input type="hidden" name="metodo" value="tarjeta">
      <div class="field"><label for="cc-name">Nombre del titular</label><input class="input upper" id="cc-name" name="titular" placeholder="COMO APARECE EN LA TARJETA"></div>
      <div class="field"><label for="cc-num">Número de tarjeta</label><div class="input-wrap"><?= icon('card', 18) ?><input class="input mono" id="cc-num" name="numero" inputmode="numeric" placeholder="0000 0000 0000 0000" maxlength="19"><span class="cc-brand mono" id="cc-brand">TARJETA</span></div></div>
      <div class="form-grid"><div class="field col-6"><label for="cc-exp">Vencimiento</label><input class="input mono" id="cc-exp" name="exp" inputmode="numeric" placeholder="MM/AA" maxlength="5"></div>
        <div class="field col-6"><label for="cc-cvv">CVV</label><input class="input mono" id="cc-cvv" name="cvv" inputmode="numeric" placeholder="123" maxlength="3" type="password"></div></div>
      <button class="btn btn-primary btn-block" type="submit"><?= icon('lock', 18) ?> Pagar <?= dinero($p['precio']) ?></button>
      <?= alerta('', 'shield', '<span class="muted">Pago simulado (prototipo). En producción los datos de la tarjeta se envían cifrados directo a Mercado Pago y <strong>nunca</strong> se guardan en FIT CODE; solo se guarda la marca y los últimos 4 dígitos.<br>Prueba: <span class="mono">4242 4242 4242 4242</span> aprobada · <span class="mono">4000 0000 0000 0002</span> rechazada.</span>', ' style="font-size:13px"') ?>
    </form>
    <?php else: ?>
    <form method="post" class="form" style="margin-top:20px"><?= csrf_field() ?><input type="hidden" name="plan" value="<?= $p['id'] ?>"><input type="hidden" name="metodo" value="efectivo">
      <ol class="steps-list"><li>Genera tu ficha con una referencia única.</li><li>Preséntala en recepción (impresa o en tu celular) dentro de las próximas <strong>72 horas</strong>.</li><li>Recepción escanea la referencia, recibe el efectivo y tu membresía se activa al momento.</li></ol>
      <button class="btn btn-primary btn-block" type="submit"><?= icon('receipt', 18) ?> Generar ficha de pago</button>
      <p class="hint" style="margin:0">Si ya tenías una ficha pendiente, se reemplaza por esta.</p>
    </form>
    <?php endif; ?>
  </section>
  <aside class="card corners rise rise-2" style="align-self:start">
    <p class="card-kicker">Resumen</p><h2 class="plan-name" style="font-size:34px"><?= e($p['nombre']) ?></h2><p class="muted" style="margin:0 0 18px"><?= e($p['descripcion']) ?></p>
    <div class="r-row"><span class="muted">Operación</span><span><?= $tipo ?></span></div>
    <div class="r-row"><span class="muted">Vigencia</span><span class="mono"><?= fecha_mx($ini) ?> → <?= fecha_mx($fin) ?></span></div>
    <div class="r-row"><span class="muted">Duración</span><span><?= $p['duracion_dias'] ?> día(s)</span></div>
    <div class="row row-between" style="margin-top:20px"><span class="label">Total</span><span class="r-total"><?= dinero($p['precio']) ?></span></div>
    <?php if ($tipo === 'Cambio de plan'): ?><p class="hint" style="margin-top:14px">Tu plan actual (<?= e($m['plan']) ?>) sigue vigente hasta el <?= fecha_mx($m['fecha_fin']) ?>; el nuevo empieza al día siguiente.</p><?php endif; ?>
  </aside>
</div>
<div class="processing hidden" id="processing"><div class="card corners"><div class="spinner"></div><p>Procesando con el banco…</p></div></div>
<?php shell_fin();
