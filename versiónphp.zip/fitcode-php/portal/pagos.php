<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$s = requiere_socio(); $sid = (int)$s['id'];
$pagos = Pagos::porSocio($sid); $m = Membresias::actual($sid); $ficha = Pagos::fichaPendiente($sid);
$pagados = array_filter($pagos, fn($p) => $p['estado'] === 'pagado');
portal_inicio('Pagos, recibos y cambio de plan', 'pagos', $s);
if ($ficha) echo '<div class="alert alert-warn rise" style="margin-bottom:18px">' . icon('receipt', 18) . '<span style="flex:1">Ficha de pago en efectivo <strong class="mono">' . e($ficha['referencia_pago']) . '</strong> por <strong>' . dinero($ficha['monto']) . '</strong> (' . e($ficha['plan']) . '). Vence el ' . fecha_mx($ficha['expira_en'], true) . '.</span><a class="btn btn-sm" href="' . url('portal/ficha.php') . '">Ver ficha</a></div>'; ?>
<div class="grid g-3" style="margin-bottom:18px">
  <div class="card kpi rise"><span class="label">Pagos confirmados</span><strong><?= count($pagados) ?></strong><span class="trend">desde tu ingreso</span></div>
  <div class="card kpi rise rise-2"><span class="label">Total invertido</span><strong class="mono" style="font-size:24px"><?= dinero(array_sum(array_column($pagados, 'monto'))) ?></strong><span class="trend">en tu entrenamiento</span></div>
  <div class="card kpi rise rise-3"><span class="label">Próximo pago</span><strong class="mono" style="font-size:24px"><?= $m ? fecha_mx($m['fecha_fin']) : 'Hoy' ?></strong><span class="trend"><?= $m ? dinero($m['precio']) . ' · ' . e($m['plan']) : 'Elige tu plan' ?></span></div>
</div>
<section class="card rise rise-2" style="margin-bottom:18px"><div class="card-head"><div><p class="card-kicker">Pagar o cambiar de plan</p><h2 class="card-title">Elige un plan · paga con tarjeta o en efectivo</h2></div></div>
  <?= planes_html($m, true) ?>
  <p class="hint" style="margin-top:14px"><?= $m && $m['estado_real'] === 'activa' ? 'Si ya tienes una membresía activa, el plan nuevo empieza al terminar la actual (' . fecha_mx($m['fecha_fin']) . ').' : 'Tu membresía se activa en cuanto se confirma el pago.' ?></p></section>
<section class="card rise rise-3"><div class="card-head"><div><p class="card-kicker">Historial</p><h2 class="card-title">Pagos y recibos</h2></div></div>
  <?php if ($pagos): ?><div class="table-wrap"><table class="t"><thead><tr><th>Folio</th><th>Concepto</th><th>Fecha</th><th>Método</th><th>Estado</th><th class="num">Monto</th><th></th></tr></thead><tbody>
  <?php foreach ($pagos as $p): ?><tr><td class="mono"><?= e($p['folio']) ?></td><td><?= e($p['concepto']) ?></td><td class="mono"><?= fecha_mx($p['pagado_en'] ?: $p['creado_en']) ?></td>
    <td><?= e(METODO_NOMBRE[$p['metodo']] ?? $p['metodo']) . ($p['tarjeta_ultimos4'] ? ' ···· ' . e($p['tarjeta_ultimos4']) : '') ?></td><td><?= badge($p['estado']) ?></td><td class="num"><?= dinero($p['monto']) ?></td>
    <td><?= $p['estado'] === 'pagado' ? '<a class="btn btn-sm btn-ghost" href="' . url('portal/recibo.php?folio=' . urlencode($p['folio'])) . '">' . icon('file', 16) . ' Recibo</a>' : ($p['estado'] === 'pendiente' ? '<a class="btn btn-sm btn-ghost" href="' . url('portal/ficha.php') . '">Ficha</a>' : '') ?></td></tr><?php endforeach; ?>
  </tbody></table></div><?php else: ?><div class="empty"><?= icon('receipt', 32) ?>Aún no tienes pagos registrados.</div><?php endif; ?></section>
<?php shell_fin();
