<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$s = requiere_socio();
$r = Pagos::recibo((int)$s['id'], (string)($_GET['folio'] ?? '')) ?? redirect('portal/pagos.php');
portal_inicio('Recibo de pago', 'pagos', $s);
echo recibo_html($r, 'portal/pagos.php');
shell_fin();
