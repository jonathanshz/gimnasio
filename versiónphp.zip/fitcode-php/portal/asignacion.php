<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$s = requiere_socio();
$m = Membresias::actual((int)$s['id']);
$pago = null; if ($m) foreach (Pagos::porSocio((int)$s['id']) as $p) if ((int)$p['membresia_id'] === (int)$m['id']) $pago = $p;
portal_inicio('Asignación y tipo de membresía', 'asignacion', $s); ?>
<div class="grid g-3" style="margin-bottom:18px">
  <div class="card kpi rise"><span class="label">Tipo de socio</span><strong style="font-size:22px"><?= $s['tipo_socio'] === 'menor' ? 'Menor de edad' : 'Mayor de edad' ?></strong><span class="trend"><?= $s['tipo_socio'] === 'menor' ? 'Tutor: ' . e($s['tutor_nombre']) : 'Titular de la cuenta' ?></span></div>
  <div class="card kpi rise rise-2"><span class="label">Membresía asignada</span><strong style="font-size:22px"><?= e($m['plan'] ?? 'Sin asignar') ?></strong><span class="trend"><?= $m ? 'Desde ' . fecha_mx($m['fecha_inicio']) : 'Elige un plan' ?></span></div>
  <div class="card kpi rise rise-3"><span class="label">Asignada mediante</span><strong style="font-size:22px"><?= $pago ? e(METODO_NOMBRE[$pago['metodo']]) : '—' ?></strong><span class="trend"><?= $pago ? ($pago['cajero'] ? 'Cobró: ' . e(explode(' ', $pago['cajero'])[0]) : 'Pago en línea') : 'Pendiente' ?></span></div>
</div>
<section class="card rise rise-3"><div class="card-head"><div><p class="card-kicker">Catálogo</p><h2 class="card-title">Tipos de membresía FIT CODE</h2></div></div>
  <?= planes_html($m) ?>
  <p class="hint" style="margin-top:18px">La membresía se asigna automáticamente cuando se confirma tu pago (tarjeta en línea o efectivo cobrado en recepción).</p></section>
<?php shell_fin();
