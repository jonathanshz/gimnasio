<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$s = requiere_socio();
layout_inicio('Mi código'); ?>
<div class="fullcode"><div class="full"><?= barcode_svg($s['codigo_credencial'], 160, 3.0, '#07080a') ?><p class="code"><?= e($s['codigo_credencial']) ?></p><p class="name"><?= e($s['nombre_completo']) ?></p>
<a class="back" href="<?= url('portal/inicio.php') ?>"><?= icon('back', 16) ?> Volver</a></div></div>
<?php layout_fin();
