<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$s = requiere_socio();
if (es_post()) { csrf_verificar(); Pagos::cancelarFicha((int)$s['id'], (int)($_POST['id'] ?? 0)); flash('ok', 'Ficha cancelada.'); redirect('portal/pagos.php'); }
$f = Pagos::fichaPendiente((int)$s['id']);
portal_inicio('Ficha de pago en efectivo', 'pagos', $s);
if (!$f): ?><div class="card empty rise"><?= icon('receipt', 32) ?>No tienes fichas pendientes.<br><a class="btn btn-primary" style="margin-top:14px" href="<?= url('portal/pagos.php') ?>">Ir a pagos</a></div>
<?php else: ?>
<section class="card corners receipt rise">
  <div class="row row-between" style="margin-bottom:20px"><?= logo() ?><span class="mono dim">FICHA DE PAGO</span></div>
  <p class="card-kicker">Referencia</p><h2 class="title mono" style="letter-spacing:.12em"><?= e($f['referencia_pago']) ?></h2>
  <div style="background:#f4f6f2;padding:14px;border-radius:10px;margin:8px 0 18px"><?= barcode_svg($f['referencia_pago'], 70, 1.8, '#07080a') ?></div>
  <div class="r-row"><span class="muted">Socio</span><span><?= e($s['nombre_completo']) ?></span></div>
  <div class="r-row"><span class="muted">Concepto</span><span><?= e($f['concepto']) ?></span></div>
  <div class="r-row"><span class="muted">Generada</span><span class="mono"><?= fecha_mx($f['creado_en'], true) ?></span></div>
  <div class="r-row"><span class="muted">Vence</span><span class="mono" style="color:var(--warn)"><?= fecha_mx($f['expira_en'], true) ?></span></div>
  <div class="row row-between" style="margin-top:22px"><span class="label">Total a pagar en recepción</span><span class="r-total"><?= dinero($f['monto']) ?></span></div>
  <?= alerta('', 'alert', '<span class="muted">Tu membresía se activa en cuanto recepción registre el pago. Si la ficha vence, genera una nueva.</span>', ' style="margin-top:20px"') ?>
  <div class="actions no-print"><form method="post" data-confirm="¿Cancelar esta ficha de pago?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $f['id'] ?>"><button class="btn btn-ghost btn-danger">Cancelar ficha</button></form>
    <button class="btn btn-primary" type="button" onclick="window.print()"><?= icon('print', 18) ?> Imprimir</button></div>
</section>
<?php endif; shell_fin();
