<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
require ROOT_PATH . '/includes/registro.php';
$puesto = ($_GET['puesto'] ?? $_POST['puesto'] ?? '') === 'instructor' ? 'instructor' : 'recepcion';
$coach = $puesto === 'instructor';
$k = "reg_staff_$puesto";
$E = []; $v = $_SESSION[$k]['v'] ?? []; $docs = $_SESSION[$k]['docs'] ?? [];

if (es_post()) {
    csrf_verificar();
    $v = validar_persona($_POST, $E, 'coach', ['sin_fecha' => !$coach, 'sin_genero' => true, 'sin_salud' => !$coach]);
    $v['rfc'] = mb_strtoupper(trim($_POST['rfc'] ?? '')); $v['email'] = mb_strtolower(trim($_POST['email'] ?? ''));
    $v['telefono'] = preg_replace('/\D/', '', $_POST['telefono'] ?? ''); $v['telefono_emergencia'] = preg_replace('/\D/', '', $_POST['telefono_emergencia'] ?? '');
    if (!validar_rfc($v['rfc'])) $E['rfc'] = 'RFC no válido: 4 letras y 6 números, sin homoclave (ej. GOTL900215).';
    elseif (Personal::existeRFC($v['rfc'])) $E['rfc'] = 'Ese RFC ya está registrado.';
    if (!validar_email($v['email'])) $E['email'] = 'Correo no válido.'; elseif (Socios::existeEmail($v['email'])) $E['email'] = 'Ese correo ya está registrado.';
    if (!preg_match('/^\d{10}$/', $v['telefono'])) $E['telefono'] = 'Número a 10 dígitos.';
    if ($coach) { if (!preg_match('/^\d{10}$/', $v['telefono_emergencia'])) $E['telefono_emergencia'] = 'Número a 10 dígitos.'; elseif ($v['telefono_emergencia'] === $v['telefono']) $E['telefono_emergencia'] = 'Debe ser distinto al de contacto.'; }
    $pw = (string)($_POST['password'] ?? '');
    if ($f = validar_password($pw)) $E['password'] = 'La contraseña necesita: ' . implode(', ', $f) . '.'; elseif ($pw !== ($_POST['password2'] ?? '')) $E['password2'] = 'Las contraseñas no coinciden.';
    $req = ['id_oficial' => 'Identificación oficial'];
    if ($coach && $v['enfermedad_cronica'] && $v['enfermedad_cronica'] !== 'NINGUNA') $req['cert_medico'] = 'Constancia médica'; else unset($docs['cert_medico']);
    procesar_documentos($req, $docs, $E, 'firma electrónica');
    if (!$E) {
        $r = Personal::registrar($puesto, $v + ['password' => $pw], $docs);
        unset($_SESSION[$k]);
        $_SESSION['verif'] = ['tipo' => 'usuario', 'id' => $r['usuario_id']];
        flash('ok', "Registro recibido. Tu número de empleado es {$r['numero_empleado']}. Verifica tu correo.");
        redirect('verificar.php');
    }
    $_SESSION[$k] = ['v' => $v, 'docs' => $docs];
}
$val = fn($x) => e($v[$x] ?? '');
$rfcField = '<div class="field col-' . ($coach ? 6 : 6) . inv($E, 'rfc') . '"><label for="rfc">RFC <span class="req">*</span></label><input class="input mono" id="rfc" name="rfc" value="' . $val('rfc') . '" maxlength="10" style="text-transform:uppercase" placeholder="ABCD000000">'
    . (err($E, 'rfc') ?: '<p class="hint">4 letras y 6 números, sin homoclave.</p>') . '</div>';
layout_inicio('Registro de ' . ($coach ? 'coach' : 'recepcionista')); ?>
<div class="reg-page"><header class="reg-head"><a href="<?= url('index.php') ?>"><?= logo() ?></a><a href="<?= url('personal/index.php') ?>" class="btn btn-ghost btn-sm"><?= icon('back', 16) ?> Volver</a></header>
<div class="reg-body"><div class="panel panel-wide rise">
  <p class="kicker"><?= $coach ? 'Coaches y entrenadores' : 'Recepción' ?></p><h2 class="title">Registro de <?= $coach ? 'coach' : 'recepcionista' ?></h2>
  <p class="lead">Datos en <strong>MAYÚSCULAS</strong>. Tu cuenta se activa después de verificar tu correo y de que administración la apruebe.</p>
  <?php if ($E): ?><div class="alert alert-bad" role="alert" style="margin-bottom:22px"><?= icon('alert', 18) ?><span>Revisa <?= count($E) ?> campo(s) marcados abajo.</span></div><?php endif; ?>
  <form method="post" enctype="multipart/form-data" class="form" novalidate><?= csrf_field() ?><input type="hidden" name="puesto" value="<?= $puesto ?>">
    <?php if ($coach): echo bloque_identidad($v, $E, '01 · Identidad', 'coach', $rfcField); else: ?>
    <fieldset class="fieldset"><legend>01 · Identidad</legend><div class="form-grid">
      <div class="field col-4<?= inv($E, 'nombre') ?>"><label for="nombre">Nombre(s) <span class="req">*</span></label><input class="input upper" id="nombre" name="nombre" value="<?= $val('nombre') ?>" maxlength="60"><?= err($E, 'nombre') ?></div>
      <div class="field col-4<?= inv($E, 'apellido_paterno') ?>"><label for="ap">Apellido paterno <span class="req">*</span></label><input class="input upper" id="ap" name="apellido_paterno" value="<?= $val('apellido_paterno') ?>" maxlength="60"><?= err($E, 'apellido_paterno') ?></div>
      <div class="field col-4<?= inv($E, 'apellido_materno') ?>"><label for="am">Apellido materno <span class="req">*</span></label><input class="input upper" id="am" name="apellido_materno" value="<?= $val('apellido_materno') ?>" maxlength="60"><?= err($E, 'apellido_materno') ?></div>
      <?= $rfcField ?>
    </div></fieldset>
    <?php endif; ?>
    <fieldset class="fieldset"><legend>02 · Contacto</legend><div class="form-grid">
      <div class="field col-<?= $coach ? 4 : 6 ?><?= inv($E, 'email') ?>"><label for="email">Correo <span class="req">*</span></label><input class="input" type="email" id="email" name="email" value="<?= $val('email') ?>" autocomplete="email"><?= err($E, 'email') ?></div>
      <div class="field col-<?= $coach ? 4 : 6 ?><?= inv($E, 'telefono') ?>"><label for="tel">Número de contacto <span class="req">*</span></label><input class="input mono" id="tel" name="telefono" value="<?= $val('telefono') ?>" inputmode="tel" data-digits="10" placeholder="10 dígitos"><?= err($E, 'telefono') ?></div>
      <?php if ($coach): ?><div class="field col-4<?= inv($E, 'telefono_emergencia') ?>"><label for="tem">Número de emergencia <span class="req">*</span></label><input class="input mono" id="tem" name="telefono_emergencia" value="<?= $val('telefono_emergencia') ?>" inputmode="tel" data-digits="10" placeholder="10 dígitos"><?= err($E, 'telefono_emergencia') ?></div><?php endif; ?>
    </div></fieldset>
    <?php if ($coach) echo bloque_salud($v, $E, $docs, 'Adjunta un documento en el que un médico avale que puedes ejercer y laborar como coach.'); ?>
    <fieldset class="fieldset"><legend><?= $coach ? '04' : '03' ?> · Documentos y firma</legend><div class="form-grid">
      <div class="col-12"><?= campo_upload('id_oficial', 'Foto de identificación oficial', 'INE, pasaporte o cédula · JPG, PNG o PDF', $docs['id_oficial'] ?? null) . err($E, 'id_oficial') ?></div>
      <div class="col-12"><?= campo_firma('Firma electrónica', !empty($docs['firma'])) . err($E, 'firma') ?></div>
    </div></fieldset>
    <fieldset class="fieldset"><legend><?= $coach ? '05' : '04' ?> · Contraseña</legend><div class="form-grid">
      <div class="col-6"><?= campo_password() . err($E, 'password') ?></div>
      <div class="field col-6"><label for="pw2">Confirmar contraseña <span class="req">*</span></label><div class="input-wrap"><?= icon('lock', 18) ?><input class="input" type="password" id="pw2" name="password2" autocomplete="new-password" data-match="pw"></div><p class="hint"></p><?= err($E, 'password2') ?></div>
    </div></fieldset>
    <div class="actions"><span class="hint">Recibirás un código de verificación en tu correo.</span><button class="btn btn-primary" type="submit">Enviar registro <?= icon('arrow', 18) ?></button></div>
  </form>
</div></div></div>
<?php layout_fin();
