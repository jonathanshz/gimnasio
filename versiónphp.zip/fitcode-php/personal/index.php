<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
if ($st = staff_actual()) redirect($st['rol'] === 'instructor' ? 'coach/index.php' : 'staff/index.php');
$modo = ($_GET['modo'] ?? $_POST['modo'] ?? '') === 'admin' ? 'admin' : 'staff';
$error = null; $v = [];
if (es_post()) {
    csrf_verificar();
    $v = $_POST;
    if ($modo === 'admin') $r = empty($v['numero']) || empty($v['email']) || empty($v['password']) ? ['ok' => false, 'error' => 'Completa los tres campos.'] : Personal::loginAdmin($v['numero'], $v['email'], $v['password']);
    else $r = empty($v['identificador']) || empty($v['password']) ? ['ok' => false, 'error' => 'Completa ambos campos.'] : Personal::login($v['identificador'], $v['password']);
    if ($r['ok']) { flash('ok', "Hola, {$r['staff']['nombre_corto']}. Sesión de " . ROL_NOMBRE[$r['staff']['rol']] . ' iniciada.'); redirect($r['staff']['rol'] === 'instructor' ? 'coach/index.php' : 'staff/index.php'); }
    if (!empty($r['sin_verificar'])) { $_SESSION['verif'] = ['tipo' => 'usuario', 'id' => $r['usuario_id']]; flash('error', 'Primero verifica tu correo.'); redirect('verificar.php'); }
    $error = $r['error'];
}
layout_inicio('Acceso del personal'); ?>
<div class="reg-page"><header class="reg-head"><a href="<?= url('index.php') ?>"><?= logo() ?></a><span class="tag mono">ACCESO DEL PERSONAL</span></header>
<div class="reg-body" style="align-items:center"><div class="panel rise">
  <p class="kicker">Personal FIT CODE</p><h2 class="title">Inicia sesión</h2>
  <p class="lead"><?= $modo === 'admin' ? 'Administración y dirección: número de empleado, correo institucional y contraseña.' : 'Recepción y coaches: número de empleado o correo y tu contraseña.' ?></p>
  <div class="tabs" role="tablist"><a href="?modo=staff" class="<?= $modo === 'staff' ? 'on' : '' ?>"><?= icon('users', 16) ?> Recepción y coaches</a><a href="?modo=admin" class="<?= $modo === 'admin' ? 'on' : '' ?>"><?= icon('shield', 16) ?> Administración</a></div>
  <?php if ($error) echo alerta('bad', 'alert', e($error), ' role="alert" style="margin-bottom:18px"'); ?>
  <form method="post" class="form card corners" novalidate><?= csrf_field() ?><input type="hidden" name="modo" value="<?= $modo ?>">
    <?php if ($modo === 'admin'): ?>
    <div class="field"><label for="num">Número de empleado</label><div class="input-wrap"><?= icon('id', 18) ?><input class="input mono" id="num" name="numero" value="<?= e($v['numero'] ?? '') ?>" placeholder="ADM-0001" style="text-transform:uppercase" autofocus></div></div>
    <div class="field"><label for="mail">Correo institucional</label><div class="input-wrap"><?= icon('file', 18) ?><input class="input" type="email" id="mail" name="email" value="<?= e($v['email'] ?? '') ?>" placeholder="nombre@fitcode.mx" autocomplete="username"></div></div>
    <?php else: ?>
    <div class="field"><label for="sid">Número de empleado o correo</label><div class="input-wrap"><?= icon('user', 18) ?><input class="input" id="sid" name="identificador" value="<?= e($v['identificador'] ?? '') ?>" placeholder="REC-0001 · nombre@fitcode.mx" autocomplete="username" autofocus></div></div>
    <?php endif; ?>
    <div class="field"><label for="spw">Contraseña</label><div class="input-wrap"><?= icon('lock', 18) ?><input class="input" type="password" id="spw" name="password" autocomplete="current-password"><button type="button" class="peek" aria-label="Mostrar contraseña"><?= icon('eye', 18) ?></button></div></div>
    <button class="btn btn-primary btn-block" type="submit">Entrar al panel <?= icon('arrow', 18) ?></button>
  </form>
  <?php if ($modo === 'staff'): ?>
  <div class="divider" style="margin:24px 0 16px">¿Eres nuevo?</div>
  <div class="grid g-2"><a class="btn btn-ghost" href="<?= url('personal/registro.php?puesto=recepcion') ?>"><?= icon('user', 16) ?> Registro de recepción</a><a class="btn btn-ghost" href="<?= url('personal/registro.php?puesto=instructor') ?>"><?= icon('dumbbell', 16) ?> Registro de coach</a></div>
  <p class="hint" style="text-align:center;margin-top:12px">Tu cuenta se activa cuando verifiques tu correo y administración la apruebe.</p>
  <?php else: ?><p class="hint" style="text-align:center;margin-top:16px">Las cuentas de administración las da de alta la dirección del gimnasio.</p><?php endif; ?>
  <?= demo_box('Administración: <span class="mono">ADM-0001</span> · <span class="mono">admin@fitcode.mx</span> · <span class="mono">Admin#2026</span><br>Dueño: <span class="mono">DUE-0001</span> · <span class="mono">dueno@fitcode.mx</span> · <span class="mono">Dueno#2026</span><br>Recepción: <span class="mono">REC-0001</span> · <span class="mono">Recep#2026</span><br>Coach: <span class="mono">COA-0001</span> · <span class="mono">Coach#2026</span>') ?>
</div></div></div>
<?php layout_fin();
