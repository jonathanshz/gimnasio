<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
if (es_post()) csrf_verificar();
Sesion::cerrar('usuario');
flash('ok', 'Sesión del personal cerrada.');
redirect('personal/index.php');
