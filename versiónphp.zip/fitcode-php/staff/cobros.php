<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$st = requiere_staff();
if (es_post()) { csrf_verificar(); $_SESSION['cobro'] = Pagos::cobrarFicha($_POST['referencia'] ?? '', (int)$st['usuario_id']); redirect('staff/cobros.php'); }
$r = $_SESSION['cobro'] ?? null; unset($_SESSION['cobro']);
$pend = Pagos::pendientesEfectivo();
staff_inicio('Cobros en efectivo', 'cobros', $st); ?>
<form method="post" class="scanbar rise"><?= csrf_field() ?><span class="scan-ico"><?= icon('receipt', 22) ?></span>
  <div style="flex:1;min-width:200px"><label class="label" for="ref">Referencia de la ficha</label><input class="input" id="ref" name="referencia" data-scan placeholder="Escanea o escribe · EF-XXXXXXXX" autocomplete="off" style="margin-top:8px"></div>
  <button class="btn btn-primary" type="submit"><?= icon('check', 18) ?> Cobrar</button></form>
<?php if ($r): ?><div class="alert <?= $r['ok'] ? 'alert-ok' : 'alert-bad' ?> rise" style="margin-bottom:22px"><?= icon($r['ok'] ? 'check' : 'alert', 20) ?><span style="flex:1">
  <?= $r['ok'] ? '<strong>Cobro registrado · ' . dinero($r['pago']['monto']) . '</strong> · ' . e($r['pago']['socio']) . ' · ' . e($r['pago']['plan']) . ' activa ' . fecha_mx($r['pago']['fecha_inicio']) . ' → ' . fecha_mx($r['pago']['fecha_fin']) . ' · folio <span class="mono">' . e($r['pago']['folio']) . '</span>' : e($r['error']) ?></span>
  <?php if ($r['ok']): ?><a class="btn btn-sm" href="<?= url('staff/recibo.php?folio=' . urlencode($r['pago']['folio'])) ?>">Recibo</a><?php endif; ?></div><?php endif; ?>
<section class="card rise rise-2"><div class="card-head"><div><p class="card-kicker">Fichas generadas por los socios</p><h3 class="card-title"><?= count($pend) ?> pendiente(s) de cobro</h3></div></div>
  <?php if ($pend): ?><div class="table-wrap"><table class="t"><thead><tr><th>Referencia</th><th>Socio</th><th>Plan</th><th>Vence</th><th class="num">Monto</th><th></th></tr></thead><tbody>
  <?php foreach ($pend as $p): ?><tr><td class="mono"><?= e($p['referencia_pago']) ?></td><td><?= e($p['socio']) ?><br><span class="hint mono"><?= e($p['socio_usuario']) ?></span></td><td><?= e($p['plan']) ?></td><td class="mono"><?= fecha_mx($p['expira_en'], true) ?></td><td class="num"><?= dinero($p['monto']) ?></td>
    <td><form method="post" data-confirm="¿Confirmas que recibiste el efectivo de la ficha <?= e($p['referencia_pago']) ?>?"><?= csrf_field() ?><input type="hidden" name="referencia" value="<?= e($p['referencia_pago']) ?>"><button class="btn btn-sm btn-primary">Recibí el efectivo</button></form></td></tr><?php endforeach; ?>
  </tbody></table></div><?php else: ?><div class="empty"><?= icon('receipt', 32) ?>No hay fichas pendientes.</div><?php endif; ?>
  <p class="hint">Confirma el cobro solo cuando tengas el efectivo en mano. La membresía se activa al instante y queda tu usuario como cajero.</p></section>
<?php shell_fin();
