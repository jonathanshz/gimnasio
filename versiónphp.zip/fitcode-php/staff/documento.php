<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$st = requiere_staff(['recepcion', 'administrador', 'dueno', 'instructor']);
$tipo = $_GET['tipo'] ?? ''; $id = (int)($_GET['id'] ?? 0);
if ($tipo === 'empleado' && !in_array($st['rol'], ['administrador', 'dueno'], true)) { http_response_code(403); exit('Sin permiso.'); }
if ($tipo === 'socio' && $st['rol'] === 'instructor') { http_response_code(403); exit('Sin permiso.'); }
$d = match ($tipo) {
    'socio' => q1('SELECT * FROM socio_documentos WHERE id = ?', [$id]),
    'empleado' => q1('SELECT * FROM empleado_documentos WHERE id = ?', [$id]),
    default => null,
};
$ruta = $d ? realpath(UPLOAD_PATH . '/' . basename($d['ruta_archivo'])) : false;
if (!$ruta || !str_starts_with($ruta, realpath(UPLOAD_PATH)) || !is_file($ruta)) { http_response_code(404); exit('Documento no encontrado.'); }
bitacora('staff', (int)$st['usuario_id'], 'ver_documento', 'documentos', "$tipo:$id");
header('Content-Type: ' . (in_array($d['mime'], ['image/png', 'image/jpeg', 'image/webp', 'application/pdf'], true) ? $d['mime'] : 'application/octet-stream'));
header('Content-Disposition: inline; filename="' . $d['tipo'] . '-' . $id . '.' . pathinfo($ruta, PATHINFO_EXTENSION) . '"');
header('Content-Length: ' . filesize($ruta));
header('Cache-Control: private, no-store');
readfile($ruta);
