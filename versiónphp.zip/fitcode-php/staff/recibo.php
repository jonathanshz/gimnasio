<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$st = requiere_staff();
$r = Pagos::recibo(null, (string)($_GET['folio'] ?? '')) ?? redirect('staff/cobros.php');
staff_inicio('Recibo de pago', 'cobros', $st);
echo recibo_html($r, 'staff/cobros.php');
shell_fin();
