<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$st = requiere_staff();
if (es_post()) {
    csrf_verificar();
    if (($_POST['accion'] ?? '') === 'scan') $_SESSION['scan'] = Asistencias::escanear($_POST['codigo'] ?? '', (int)$st['usuario_id']);
    if (($_POST['accion'] ?? '') === 'codigo') $_SESSION['codigo_nuevo'] = Codigos::generar((int)$st['usuario_id']);
    redirect('staff/index.php');
}
$sc = $_SESSION['scan'] ?? null; $cn = $_SESSION['codigo_nuevo'] ?? null; unset($_SESSION['scan'], $_SESSION['codigo_nuevo']);
$k = Asistencias::kpisHoy(); $pend = Pagos::pendientesEfectivo(); $venc = count(Membresias::porVencer());
$esAdmin = in_array($st['rol'], ['administrador', 'dueno'], true);
staff_inicio('Panel de recepción', 'panel', $st); ?>
<form method="post" class="scanbar rise"><?= csrf_field() ?><input type="hidden" name="accion" value="scan"><span class="scan-ico"><?= icon('scan', 22) ?></span>
  <div style="flex:1;min-width:200px"><label class="label" for="scan">Entrada / salida de socios</label><input class="input" id="scan" name="codigo" data-scan placeholder="Escanea o escribe el código · FC2600000…" autocomplete="off" style="margin-top:8px"></div>
  <button class="btn btn-primary" type="submit"><?= icon('check', 18) ?> Registrar</button></form>
<?php if ($sc): ?>
  <div class="alert <?= $sc['ok'] ? 'alert-ok' : 'alert-bad' ?> rise" style="margin-bottom:22px;padding:16px 18px"><?= icon($sc['ok'] ? 'check' : 'alert', 22) ?><div style="flex:1">
    <?php if ($sc['ok']): ?><strong style="font:500 17px/1.3 var(--f-display)"><?= $sc['tipo'] ?> · <?= e($sc['socio']['nombre_completo']) ?></strong><div class="muted mono" style="font-size:13px;margin-top:4px"><?= substr($sc['hora'], 11) ?> · <?= e($sc['m']['plan'] ?? '') ?> · vence <?= fecha_mx($sc['m']['fecha_fin'] ?? null) ?><?= isset($sc['minutos']) ? ' · estancia ' . $sc['minutos'] . ' min' : '' ?></div>
    <?php else: ?><strong style="font:500 17px/1.3 var(--f-display)">ACCESO DENEGADO<?= isset($sc['socio']) ? ' · ' . e($sc['socio']['nombre_completo']) : '' ?></strong><div class="muted" style="font-size:13.5px;margin-top:4px"><?= e($sc['motivo']) ?></div><?php endif; ?>
  </div><?php if (isset($sc['socio'])): ?><a class="btn btn-sm" href="<?= url('staff/usuario.php?id=' . $sc['socio']['id']) ?>">Ver ficha</a><?php endif; ?></div>
<?php endif; ?>
<div class="grid g-4" style="margin-bottom:22px">
  <div class="card kpi rise"><span class="label">Dentro ahora</span><strong><?= $k['dentro'] ?></strong></div>
  <div class="card kpi rise rise-2"><span class="label">Entradas hoy</span><strong><?= $k['entradas'] ?></strong><span class="trend"><?= $k['rechazos'] ?> rechazo(s)</span></div>
  <div class="card kpi rise rise-3"><span class="label">Vencen en 7 días</span><strong style="color:var(--warn)"><?= $venc ?></strong></div>
  <a href="<?= url('staff/cobros.php') ?>" class="card kpi rise rise-4"><span class="label">Cobros en efectivo pendientes</span><strong style="color:<?= $pend ? 'var(--accent)' : 'inherit' ?>"><?= count($pend) ?></strong><span class="trend">ver fichas →</span></a>
</div>
<div class="big-choice" style="margin-bottom:22px">
  <a href="<?= url('staff/usuarios.php') ?>" class="rise rise-2"><span class="ico-box"><?= icon('users', 26) ?></span><h3>Información del usuario</h3><p>Busca socios por nombre: datos, membresía, asistencias, pagos y documentos. Cobra en mostrador.</p><span class="go">Buscar socio <?= icon('arrow', 16) ?></span></a>
  <a href="<?= url('staff/admin.php') ?>" class="rise rise-3<?= $esAdmin ? '' : ' locked' ?>"><span class="ico-box"><?= icon($esAdmin ? 'shield' : 'lock', 26) ?></span><h3>Acceso administración</h3><p><?= $esAdmin ? 'Ingresos, corte de caja, personal, máquinas, códigos y bitácora.' : 'Solo para administración y dirección.' ?></p><span class="go"><?= $esAdmin ? 'Entrar' : 'Restringido' ?> <?= icon('arrow', 16) ?></span></a>
</div>
<div class="grid g-2">
  <section class="card rise rise-3"><div class="card-head"><div><p class="card-kicker">Registro</p><h3 class="card-title">Código para nuevo socio</h3></div></div>
    <?php if ($cn): ?><div class="user-reveal corners"><span class="label">Entrega este código al cliente</span><span class="mono" style="letter-spacing:.3em"><?= e($cn) ?></span></div><?php endif; ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="accion" value="codigo"><button class="btn btn-block" type="submit"><?= icon('key', 18) ?> Generar código de 6 dígitos</button></form>
    <p class="hint" style="margin-bottom:0">Vigente 72 horas. El cliente lo usa en “Registrarme con mi código de recepción”.</p></section>
  <section class="card rise rise-4"><p class="card-kicker">Actividad reciente</p>
    <?php $rec = Asistencias::recientes(6); if (!$rec) echo '<div class="empty">Sin movimientos.</div>';
    foreach ($rec as $a): ?><a href="<?= url('staff/usuario.php?id=' . $a['socio_id']) ?>" class="row row-between" style="padding:9px 0;border-bottom:1px solid var(--line)"><span><?= e($a['nombre'] . ' ' . $a['apellido_paterno']) ?></span><span class="mono dim" style="font-size:12.5px"><?= $a['tipo_movimiento'] === 'entrada' ? '<span class="accent">ENTRADA</span>' : 'SALIDA' ?> <?= date('d/m H:i', strtotime($a['creado_en'])) ?></span></a><?php endforeach; ?></section>
</div>
<p class="hint" style="margin-top:22px">Prueba el escáner: <span class="mono">FC260000013</span> (Ana · activa) · <span class="mono">FC260000039</span> (Sofía · vencida)</p>
<?php shell_fin();
