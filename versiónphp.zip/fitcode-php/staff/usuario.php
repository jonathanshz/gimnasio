<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$st = requiere_staff();
$id = (int)($_GET['id'] ?? 0);
$s = Socios::porId($id) ?? redirect('staff/usuarios.php');

if (es_post()) {
    csrf_verificar();
    $acc = $_POST['accion'] ?? '';
    if ($acc === 'cobro') {
        $plan = Planes::porId((int)($_POST['plan'] ?? 0));
        if (!$plan) flash('error', 'Elige un plan.');
        else {
            $p = Pagos::cobroMostrador($id, (int)$plan['id'], $_POST['metodo'] ?? 'efectivo', (int)$st['usuario_id']);
            flash('ok', 'Cobro registrado: ' . dinero($p['monto']) . ' · folio ' . $p['folio'] . '.');
            redirect('staff/recibo.php?folio=' . urlencode($p['folio']));
        }
    }
    if ($acc === 'acceso') {
        $r = Asistencias::escanear((string)$s['codigo_credencial'], (int)$st['usuario_id']);
        $r['ok'] ? flash('ok', "{$r['tipo']} registrada manualmente.") : flash('error', $r['motivo']);
    }
    redirect("staff/usuario.php?id=$id");
}

$m = Membresias::actual($id); $sig = Membresias::siguiente($id); $docs = Socios::documentos($id);
$vis = Asistencias::visitas($id, 10); $pagos = Pagos::porSocio($id); $dentro = Asistencias::dentro($id);
$fila = fn($a, $b) => '<div class="r-row"><span class="muted">' . $a . '</span><span>' . $b . '</span></div>';
staff_inicio('Ficha del socio', 'usuarios', $st); ?>
<a class="btn btn-ghost btn-sm" href="<?= url('staff/usuarios.php') ?>" style="margin-bottom:16px"><?= icon('back', 16) ?> Volver a la búsqueda</a>
<section class="card corners rise" style="margin-bottom:22px"><div class="row row-between" style="gap:18px;flex-wrap:wrap">
  <div class="person"><span class="avatar" style="width:54px;height:54px;font-size:18px"><?= e(mb_substr($s['nombre'], 0, 1) . mb_substr($s['apellido_paterno'], 0, 1)) ?></span>
    <div><h2 class="title" style="font-size:24px;margin:0"><?= e($s['nombre_completo']) ?></h2><small class="mono"><?= e($s['usuario']) ?> · <?= e($s['codigo_credencial']) ?> · <?= $s['edad'] ?> años · <?= $s['tipo_socio'] === 'menor' ? 'MENOR' : 'MAYOR' ?></small></div></div>
  <div class="row" style="gap:8px;flex-wrap:wrap"><?= $m ? badge($m['estado_real']) : badge('mute', 'sin membresía') ?><?= $dentro ? badge('activa', 'en el gimnasio') : '' ?><?= $s['email_verificado_en'] ? badge('activa', 'correo verificado') : badge('pendiente', 'correo sin verificar') ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="accion" value="acceso"><button class="btn btn-sm"><?= icon('scan', 16) ?> Registrar <?= $dentro ? 'salida' : 'entrada' ?></button></form></div>
</div></section>

<div class="grid g-main">
  <div class="stack">
    <section class="card rise rise-2"><p class="card-kicker">Membresía</p>
      <?php if ($m): ?><h3 class="card-title"><?= e($m['plan']) ?></h3>
        <?= $fila('Vigencia', '<span class="mono">' . fecha_mx($m['fecha_inicio']) . ' → ' . fecha_mx($m['fecha_fin']) . '</span>') . $fila('Días restantes', '<strong>' . $m['dias_restantes'] . '</strong>') ?>
        <?= $sig ? $fila('Siguiente', e($sig['plan']) . ' desde <span class="mono">' . fecha_mx($sig['fecha_inicio']) . '</span>') : '' ?>
        <div class="occupancy" style="margin-top:14px"><i style="width:<?= $m['porcentaje'] ?>%;background:var(--accent)"></i></div>
      <?php else: ?><div class="empty">Este socio aún no tiene membresía.</div><?php endif; ?></section>

    <section class="card rise rise-3"><p class="card-kicker">Datos personales</p>
      <?= $fila('Correo', e($s['email'])) . $fila('Teléfono', '<span class="mono">' . e($s['telefono']) . '</span>') . $fila('Nacimiento', '<span class="mono">' . fecha_mx($s['fecha_nacimiento']) . '</span>')
        . $fila('Género / sexo', e($s['genero'] . ' · ' . $s['sexo'])) . $fila('Servicio médico', e(CAT_SERVICIO[$s['servicio_medico']] ?? $s['servicio_medico']))
        . $fila('Enfermedad crónica', e($s['enfermedad_cronica'] === 'OTRA' ? $s['enfermedad_otra'] : (CAT_ENF[$s['enfermedad_cronica']] ?? $s['enfermedad_cronica'])))
        . $fila('Emergencia', e(($s['contacto_emergencia'] ?: '—') . ' · ') . '<span class="mono">' . e($s['telefono_emergencia']) . '</span>')
        . ($s['tutor_nombre'] ? $fila('Tutor', e($s['tutor_nombre'])) : '') ?></section>

    <section class="card rise rise-3"><p class="card-kicker">Asistencias recientes</p>
      <?php if ($vis): ?><div class="table-wrap"><table class="t"><thead><tr><th>Fecha</th><th>Entrada</th><th>Salida</th><th class="num">Minutos</th></tr></thead><tbody>
      <?php foreach ($vis as $v): ?><tr><td><?= fecha_mx(substr($v['entrada'], 0, 10)) ?></td><td class="mono"><?= hora_de($v['entrada']) ?></td><td class="mono"><?= $v['salida'] ? hora_de($v['salida']) : '<span class="accent">dentro</span>' ?></td><td class="num"><?= $v['salida'] ? round((strtotime($v['salida']) - strtotime($v['entrada'])) / 60) : '—' ?></td></tr><?php endforeach; ?>
      </tbody></table></div><?php else: ?><div class="empty">Sin asistencias registradas.</div><?php endif; ?></section>

    <section class="card rise rise-4"><p class="card-kicker">Pagos</p>
      <?php if ($pagos): ?><div class="table-wrap"><table class="t"><thead><tr><th>Folio</th><th>Plan</th><th>Método</th><th>Estado</th><th class="num">Monto</th></tr></thead><tbody>
      <?php foreach ($pagos as $p): ?><tr><td class="mono"><?= $p['estado'] === 'pagado' ? '<a href="' . url('staff/recibo.php?folio=' . urlencode($p['folio'])) . '">' . e($p['folio']) . '</a>' : e($p['referencia_pago'] ?: $p['folio']) ?></td><td><?= e($p['plan']) ?></td><td><?= e(METODO_NOMBRE[$p['metodo']] ?? $p['metodo']) ?></td><td><?= badge($p['estado']) ?></td><td class="num"><?= dinero($p['monto']) ?></td></tr><?php endforeach; ?>
      </tbody></table></div><?php else: ?><div class="empty">Sin pagos.</div><?php endif; ?></section>
  </div>

  <div class="stack" style="align-self:start">
    <section class="card rise rise-2"><p class="card-kicker">Cobro en mostrador</p><h3 class="card-title" style="margin-bottom:14px">Asignar o renovar membresía</h3>
      <form method="post" class="form" data-confirm="¿Confirmas el cobro? La membresía se activará al terminar la actual."><?= csrf_field() ?><input type="hidden" name="accion" value="cobro">
        <div class="field"><label for="c-plan">Plan</label><select class="input" id="c-plan" name="plan"><?php foreach (Planes::listar() as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['nombre']) ?> · $<?= number_format($p['precio']) ?></option><?php endforeach; ?></select></div>
        <div class="field"><label for="c-met">Método</label><select class="input" id="c-met" name="metodo"><option value="efectivo">Efectivo</option><option value="tarjeta">Tarjeta (terminal)</option></select></div>
        <button class="btn btn-primary btn-block" type="submit"><?= icon('receipt', 18) ?> Cobrar y generar recibo</button></form>
      <p class="hint" style="margin-bottom:0">Si el socio tenía una ficha de efectivo pendiente, se cancela para no cobrar dos veces.</p></section>

    <section class="card rise rise-3"><p class="card-kicker">Credencial</p><div style="background:#f4f6f2;padding:12px;border-radius:10px"><?= barcode_svg((string)$s['codigo_credencial'], 56, 1.6, '#07080a') ?></div><p class="mono dim" style="text-align:center;margin:8px 0 0"><?= e($s['codigo_credencial']) ?></p></section>

    <section class="card rise rise-4"><p class="card-kicker">Documentos</p>
      <?php if ($docs): foreach ($docs as $d): ?><a class="row row-between doc-row" target="_blank" rel="noopener" href="<?= url('staff/documento.php?tipo=socio&id=' . $d['id']) ?>" style="padding:9px 0;border-bottom:1px solid var(--line)"><span><?= icon('file', 16) ?> <?= e(DOC_NOMBRE[$d['tipo']] ?? $d['tipo']) ?></span><span class="hint mono"><?= e($d['mime']) ?></span></a><?php endforeach;
      else: ?><div class="empty">Sin documentos.</div><?php endif; ?></section>
  </div>
</div>
<?php shell_fin();
