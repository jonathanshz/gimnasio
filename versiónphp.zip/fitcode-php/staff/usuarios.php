<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$st = requiere_staff();
$q = trim($_GET['q'] ?? '');
staff_inicio('Información del usuario', 'usuarios', $st);
echo lista_socios_html($q, 'staff/usuario.php', false);
shell_fin();
