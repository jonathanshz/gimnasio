<?php
require dirname(__DIR__) . '/includes/bootstrap.php';
$st = requiere_staff(['administrador', 'dueno']);
$TABS = ['resumen' => 'Resumen', 'personal' => 'Personal', 'pagos' => 'Pagos y corte', 'maquinas' => 'Máquinas', 'codigos' => 'Códigos', 'bitacora' => 'Bitácora'];
$tab = isset($TABS[$_GET['tab'] ?? '']) ? $_GET['tab'] : 'resumen';
$uid = (int)$st['usuario_id'];

if (es_post()) {
    csrf_verificar();
    $acc = $_POST['accion'] ?? '';
    if ($acc === 'personal') {
        $emp = (int)($_POST['empleado_id'] ?? 0); $estado = $_POST['estado'] ?? '';
        $p = array_values(array_filter(Personal::listar(), fn($x) => (int)$x['empleado_id'] === $emp))[0] ?? null;
        if (!$p || !in_array($estado, ['activo', 'inactivo'], true) || in_array($p['rol'], ['dueno'], true)) flash('error', 'Operación no permitida.');
        elseif ($estado === 'activo' && !$p['verificado']) flash('error', 'No se puede aprobar: el empleado aún no verifica su correo.');
        elseif ((int)$p['usuario_id'] === $uid) flash('error', 'No puedes cambiar tu propia cuenta.');
        else { Personal::cambiarEstado($emp, $estado, $uid); flash('ok', "{$p['nombre']} ahora está " . ($estado === 'activo' ? 'activo' : 'inactivo') . '.'); }
    }
    if ($acc === 'equipo') { Equipos::cambiarEstado((int)($_POST['id'] ?? 0), $_POST['estado'] ?? '', $uid); flash('ok', 'Estado del equipo actualizado.'); }
    if ($acc === 'codigo') { $_SESSION['codigo_nuevo'] = Codigos::generar($uid); }
    redirect("staff/admin.php?tab=$tab" . (isset($_POST['fecha']) ? '&fecha=' . urlencode($_POST['fecha']) : ''));
}

staff_inicio('Administración', 'admin', $st);
echo '<nav class="tabs">'; foreach ($TABS as $k => $n) echo '<a class="' . ($k === $tab ? 'on' : '') . '" href="' . url("staff/admin.php?tab=$k") . '">' . $n . '</a>'; echo '</nav>';

if ($tab === 'resumen'):
    $hoy = Pagos::ingresosDesde(hoy() . ' 00:00:00'); $sem = Pagos::ingresosDesde(mas_dias(hoy(), -6) . ' 00:00:00'); $mes = Pagos::ingresosDesde(date('Y-m-01') . ' 00:00:00');
    $activos = 0; $total = 0; foreach (Socios::buscar('') as $s) { $total++; $m = Membresias::actual((int)$s['id']); if ($m && $m['estado_real'] === 'activa') $activos++; }
    $af = Asistencias::afluenciaPorHora(); $mx = max(1, max($af)); $pico = array_search(max($af), $af);
    $pend = count(array_filter(Personal::listar(), fn($p) => $p['estado'] === 'pendiente')); ?>
  <div class="grid g-4" style="margin-bottom:22px">
    <div class="card kpi rise"><span class="label">Ingresos hoy</span><strong><?= dinero($hoy) ?></strong></div>
    <div class="card kpi rise rise-2"><span class="label">Últimos 7 días</span><strong><?= dinero($sem) ?></strong></div>
    <div class="card kpi rise rise-3"><span class="label">Este mes</span><strong><?= dinero($mes) ?></strong></div>
    <div class="card kpi rise rise-4"><span class="label">Socios con membresía activa</span><strong><?= $activos ?><small>/ <?= $total ?></small></strong></div>
  </div>
  <div class="grid g-main">
    <section class="card rise rise-2"><p class="card-kicker">Afluencia por hora · últimos 30 días</p><h3 class="card-title">Hora pico: <?= pad($pico, 2) ?>:00</h3>
      <div class="bars" style="margin-top:18px;height:140px"><?php foreach ($af as $h => $n): ?><i class="<?= $n === max($af) ? 'on' : '' ?>" style="height:<?= round($n / $mx * 100) ?>%" title="<?= $h ?>:00 · <?= $n ?> entradas"></i><?php endforeach; ?></div>
      <div class="bars-x"><span>05h</span><span>09h</span><span>13h</span><span>17h</span><span>22h</span></div></section>
    <section class="card rise rise-3" style="align-self:start"><p class="card-kicker">Pendientes</p>
      <a class="row row-between" href="<?= url('staff/admin.php?tab=personal') ?>" style="padding:10px 0;border-bottom:1px solid var(--line)"><span>Personal por aprobar</span><strong class="<?= $pend ? 'accent' : '' ?>"><?= $pend ?></strong></a>
      <a class="row row-between" href="<?= url('staff/cobros.php') ?>" style="padding:10px 0;border-bottom:1px solid var(--line)"><span>Fichas de efectivo</span><strong><?= count(Pagos::pendientesEfectivo()) ?></strong></a>
      <div class="row row-between" style="padding:10px 0"><span>Membresías por vencer (7 días)</span><strong style="color:var(--warn)"><?= count(Membresias::porVencer()) ?></strong></div></section>
  </div>

<?php elseif ($tab === 'personal'): $L = Personal::listar(); ?>
  <section class="card rise"><div class="card-head"><div><p class="card-kicker">Recepción, coaches y administración</p><h3 class="card-title"><?= count($L) ?> cuenta(s)</h3></div>
    <div class="row" style="gap:8px"><a class="btn btn-sm" href="<?= url('personal/registro.php?puesto=recepcion') ?>">+ Recepcionista</a><a class="btn btn-sm" href="<?= url('personal/registro.php?puesto=instructor') ?>">+ Coach</a></div></div>
    <div class="table-wrap"><table class="t"><thead><tr><th>Empleado</th><th>Rol</th><th>RFC</th><th>Correo</th><th>Estado</th><th>Documentos</th><th></th></tr></thead><tbody>
    <?php foreach ($L as $p): $docs = Personal::documentos((int)$p['empleado_id']); ?>
      <tr><td><div class="person"><span class="avatar"><?= e(mb_substr($p['nombre'], 0, 1)) ?></span><div><strong><?= e($p['nombre']) ?></strong><small class="mono"><?= e($p['numero_empleado']) ?></small></div></div></td>
        <td><?= e(ROL_NOMBRE[$p['rol']] ?? $p['rol']) ?></td><td class="mono"><?= e($p['rfc'] ?: '—') ?></td>
        <td><?= e($p['email']) ?><br><?= $p['verificado'] ? badge('activa', 'verificado') : badge('pendiente', 'sin verificar') ?></td><td><?= badge($p['estado']) ?></td>
        <td><?php if ($docs): foreach ($docs as $d): ?><a class="hint" style="display:block" target="_blank" rel="noopener" href="<?= url('staff/documento.php?tipo=empleado&id=' . $d['id']) ?>"><?= icon('file', 13) ?> <?= e(DOC_NOMBRE[$d['tipo']] ?? $d['tipo']) ?></a><?php endforeach; else: ?><span class="hint">—</span><?php endif; ?></td>
        <td><?php if ($p['rol'] !== 'dueno' && (int)$p['usuario_id'] !== $uid): $nuevo = $p['estado'] === 'activo' ? 'inactivo' : 'activo'; ?>
          <form method="post"><?= csrf_field() ?><input type="hidden" name="accion" value="personal"><input type="hidden" name="empleado_id" value="<?= $p['empleado_id'] ?>"><input type="hidden" name="estado" value="<?= $nuevo ?>">
            <button class="btn btn-sm <?= $nuevo === 'activo' ? 'btn-primary' : '' ?>" <?= $nuevo === 'activo' && !$p['verificado'] ? 'disabled title="Debe verificar su correo primero"' : '' ?>><?= $p['estado'] === 'pendiente' ? 'Aprobar' : ($nuevo === 'activo' ? 'Reactivar' : 'Desactivar') ?></button></form><?php endif; ?></td></tr>
    <?php endforeach; ?></tbody></table></div>
    <p class="hint">Las cuentas nuevas de recepción y coach quedan <strong>pendientes</strong>. Solo se aprueban si ya verificaron su correo; revisa la identificación y, para coaches, la constancia médica.</p></section>

<?php elseif ($tab === 'pagos'):
    $f = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['fecha'] ?? '') ? $_GET['fecha'] : hoy();
    $corte = Pagos::corte($f); $tot = array_sum(array_column($corte, 'total')); ?>
  <div class="grid g-main">
    <section class="card rise"><p class="card-kicker">Últimos movimientos</p>
      <div class="table-wrap"><table class="t"><thead><tr><th>Folio / ref.</th><th>Socio</th><th>Plan</th><th>Método</th><th>Estado</th><th>Cobrado</th><th class="num">Monto</th></tr></thead><tbody>
      <?php foreach (Pagos::listar() as $p): ?><tr><td class="mono"><?= $p['estado'] === 'pagado' ? '<a href="' . url('staff/recibo.php?folio=' . urlencode($p['folio'])) . '">' . e($p['folio']) . '</a>' : e($p['referencia_pago'] ?: $p['folio']) ?></td><td><?= e($p['socio']) ?></td><td><?= e($p['plan']) ?></td>
        <td><?= e(METODO_NOMBRE[$p['metodo']] ?? $p['metodo']) ?><?= $p['tarjeta_ultimos4'] ? ' <span class="hint mono">···· ' . e($p['tarjeta_ultimos4']) . '</span>' : '' ?></td><td><?= badge($p['estado']) ?></td><td class="mono hint"><?= $p['pagado_en'] ? fecha_mx($p['pagado_en'], true) : '—' ?></td><td class="num"><?= dinero($p['monto']) ?></td></tr><?php endforeach; ?>
      </tbody></table></div></section>
    <section class="card corners rise rise-2" style="align-self:start"><p class="card-kicker">Corte de caja</p>
      <form method="get" class="row" style="gap:8px;margin:10px 0 16px"><input type="hidden" name="tab" value="pagos"><input class="input mono" type="date" name="fecha" value="<?= e($f) ?>"><button class="btn btn-sm">Ver</button></form>
      <?php foreach (['efectivo', 'tarjeta', 'mercadopago', 'transferencia'] as $mt): $r = array_values(array_filter($corte, fn($c) => $c['metodo'] === $mt))[0] ?? null; if (!$r && in_array($mt, ['mercadopago', 'transferencia'])) continue; ?>
        <div class="r-row"><span class="muted"><?= METODO_NOMBRE[$mt] ?> <span class="hint">(<?= (int)($r['pagos'] ?? 0) ?>)</span></span><span class="mono"><?= dinero((float)($r['total'] ?? 0)) ?></span></div><?php endforeach; ?>
      <div class="row row-between" style="margin-top:18px"><span class="label">Total del <?= fecha_mx($f) ?></span><span class="r-total"><?= dinero($tot) ?></span></div>
      <button class="btn btn-block no-print" style="margin-top:18px" type="button" onclick="window.print()"><?= icon('print', 18) ?> Imprimir corte</button>
      <p class="hint" style="margin-bottom:0">Se calcula por fecha de cobro (pagado_en), no por fecha de creación de la ficha.</p></section>
  </div>

<?php elseif ($tab === 'maquinas'): $L = Equipos::listar(); ?>
  <section class="card rise"><p class="card-kicker">Inventario operativo</p><h3 class="card-title" style="margin-bottom:16px"><?= count($L) ?> equipos</h3>
    <div class="machine-grid"><?php foreach ($L as $m): $mant = $m['estado'] === 'mantenimiento'; ?>
      <div class="machine <?= $m['disponibilidad'] ?>"><div class="machine-top"><span class="zone"><?= e($m['ubicacion']) ?></span><?= badge($m['disponibilidad']) ?></div><strong><?= e($m['nombre']) ?></strong>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="accion" value="equipo"><input type="hidden" name="id" value="<?= $m['id'] ?>"><input type="hidden" name="estado" value="<?= $mant ? 'operativo' : 'mantenimiento' ?>">
          <button class="btn btn-sm btn-block"><?= icon($mant ? 'check' : 'alert', 14) ?> <?= $mant ? 'Marcar operativo' : 'Enviar a mantenimiento' ?></button></form></div>
    <?php endforeach; ?></div></section>

<?php elseif ($tab === 'codigos'): $cn = $_SESSION['codigo_nuevo'] ?? null; unset($_SESSION['codigo_nuevo']); ?>
  <div class="grid g-main">
    <section class="card rise"><p class="card-kicker">Últimos 40 códigos</p>
      <div class="table-wrap"><table class="t"><thead><tr><th>Código</th><th>Generó</th><th>Creado</th><th>Expira</th><th>Usado por</th></tr></thead><tbody>
      <?php foreach (Codigos::listar() as $c): ?><tr><td class="mono" style="letter-spacing:.15em"><?= e($c['codigo']) ?></td><td><?= e($c['generado_por_nombre'] ?: 'Autoservicio (prototipo)') ?></td><td class="mono hint"><?= fecha_mx($c['creado_en'], true) ?></td>
        <td class="mono hint"><?= fecha_mx($c['expira_en'], true) ?></td><td><?= $c['usado_por'] ? '<span class="mono">' . e($c['usado_por']) . '</span>' : ($c['expira_en'] < ahora() ? badge('vencida', 'expirado') : badge('activa', 'disponible')) ?></td></tr><?php endforeach; ?>
      </tbody></table></div></section>
    <section class="card rise rise-2" style="align-self:start"><p class="card-kicker">Nuevo código</p>
      <?php if ($cn): ?><div class="user-reveal corners"><span class="label">Código generado</span><span class="mono" style="letter-spacing:.3em"><?= e($cn) ?></span></div><?php endif; ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="accion" value="codigo"><button class="btn btn-primary btn-block"><?= icon('key', 18) ?> Generar código</button></form></section>
  </div>

<?php else: $B = qa('SELECT b.*, u.nombre AS u_nombre, s.usuario AS s_usuario FROM bitacora b LEFT JOIN usuarios u ON u.id = b.usuario_id LEFT JOIN socios s ON s.id = b.socio_id ORDER BY b.id DESC LIMIT 80'); ?>
  <section class="card rise"><p class="card-kicker">Últimos 80 eventos</p>
    <div class="table-wrap"><table class="t"><thead><tr><th>Fecha</th><th>Actor</th><th>Acción</th><th>Módulo</th><th>Detalle</th><th>IP</th></tr></thead><tbody>
    <?php foreach ($B as $b): ?><tr><td class="mono hint"><?= fecha_mx($b['creado_en'], true) ?></td><td><?= e($b['actor'] === 'staff' ? ($b['u_nombre'] ?? 'Personal') : ($b['s_usuario'] ?? $b['actor'])) ?></td><td class="mono"><?= e($b['accion']) ?></td><td><?= e($b['modulo']) ?></td><td class="hint"><?= e($b['detalle'] ?? '') ?></td><td class="mono hint"><?= e($b['ip'] ?? '') ?></td></tr><?php endforeach; ?>
    </tbody></table></div></section>
<?php endif;
shell_fin();
