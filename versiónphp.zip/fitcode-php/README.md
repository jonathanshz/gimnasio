# FIT CODE · versión PHP + CSS

Sistema del gimnasio FIT CODE: portal del socio, recepción, coach y administración.
PHP 8 con páginas renderizadas en el servidor, CSS propio y un JavaScript pequeño solo para mejorar la experiencia (máscaras, firma, IMC en vivo).

## Arrancar en 1 minuto (sin instalar MySQL)

```bash
cd fitcode-php
php -S localhost:8000 router.php
```

Abre http://localhost:8000. La base **SQLite** se crea sola en `storage/fitcode.sqlite` con datos de demostración.
Para reiniciar la demo, borra ese archivo.

## XAMPP + MySQL (gimnasio_integral_db)

1. Copia la carpeta `fitcode-php` a `C:\xampp\htdocs\`.
2. En phpMyAdmin → **Importar** → `database/fitcode_mysql.sql` (crea `gimnasio_integral_db` con las 31 tablas y la demo).
3. En `includes/config.php` cambia `DB_DRIVER` a `'mysql'` (o define la variable de entorno `FITCODE_DB=mysql`) y ajusta usuario/contraseña.
4. Abre http://localhost/fitcode-php/

> Para regenerar el .sql con fechas de hoy: `php database/exportar_mysql.php`.
> El .sql se generó desde el mismo esquema que usa SQLite, pero **no se ha probado en un servidor MySQL real**: impórtalo primero en una base de prueba.

## Cuentas de demostración

| Rol | Acceso | Usuario | Contraseña |
|---|---|---|---|
| Socio (activa) | Inicio | `ANAPP-150398` | `Socio#2026` |
| Socio (por vencer) | Inicio | `LUISRM-020901` | `Socio#2026` |
| Socio menor (vencida) | Inicio | `SOFIAHL-110510` | `Socio#2026` |
| Recepción | Personal | `REC-0001` | `Recep#2026` |
| Coach | Personal | `COA-0001` | `Coach#2026` |
| Administración | Personal → Administración | `ADM-0001` + `admin@fitcode.mx` | `Admin#2026` |
| Dueño | Personal → Administración | `DUE-0001` + `dueno@fitcode.mx` | `Dueno#2026` |

- Código de registro: cualquier combinación de 6 dígitos (prototipo). Recepción también genera códigos reales.
- Correo: modo simulado; el código de verificación aparece en la "bandeja simulada" de la pantalla.
- Tarjeta de prueba aprobada `4242 4242 4242 4242`, rechazada `4000 0000 0000 0002` (cualquier fecha futura y CVV).
- Escáner de recepción: `FC260000013` (Ana, activa) · `FC260000039` (Sofía, vencida).
- RFC: 4 letras + 6 números, sin homoclave (ej. `GOTL900215`).

## Estructura

```
index.php, verificar.php, logout.php   Bienvenida/login del socio y verificación de correo
registro/      codigo → tipo → datos → cuenta (→ verificar)
portal/        inicio, codigo (credencial), membresia, pagos, pagar, ficha, recibo, avance, asignacion, maquinas
personal/      login de recepción/coach y de administración, registro de recepción y coach
staff/         panel de recepción, búsqueda de usuarios, ficha, cobros, recibo, administración, documento
coach/         mis socios, ficha de entrenamiento (progreso, rutina, nutrición, objetivo)
includes/      config, schema (DDL), db (PDO + semilla), repo (capa de datos), fitness (motor), layout, ui
assets/        css/style.css, js/app.js
database/      exportar_mysql.php → fitcode_mysql.sql
storage/       base SQLite, uploads/ (documentos privados), tmp/
```

Toda la lectura/escritura de datos pasa por `includes/repo.php` (clases `Socios`, `Pagos`, `Membresias`…), con consultas preparadas PDO. Las carpetas `includes/`, `storage/` y `database/` están bloqueadas para el navegador (`.htaccess` y `router.php`).
