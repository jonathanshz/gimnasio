<?php
require __DIR__ . '/includes/bootstrap.php';
require ROOT_PATH . '/includes/registro.php';

$v = $_SESSION['verif'] ?? null;
if (!$v) redirect('index.php');
$err = null;

if (es_post()) {
    csrf_verificar();
    if (($_POST['accion'] ?? '') === 'reenviar') {
        $r = Verificacion::enviar($v['tipo'], $v['id']);
        flash($r['ok'] ? 'ok' : 'error', $r['ok'] ? 'Te enviamos un código nuevo.' : $r['error']);
        redirect('verificar.php');
    }
    $r = Verificacion::confirmar($v['tipo'], $v['id'], preg_replace('/\D/', '', $_POST['codigo'] ?? ''));
    if ($r['ok']) {
        unset($_SESSION['verif']);
        if ($v['tipo'] === 'socio') { $_SESSION['nuevo_usuario'] = $v['usuario']; flash('ok', '¡Correo verificado! Tu cuenta está lista. Inicia sesión.'); redirect('index.php'); }
        flash('ok', 'Correo verificado. Tu cuenta quedó pendiente de aprobación por administración.');
        redirect('personal/index.php');
    }
    $err = $r['error'];
}
$info = Verificacion::vigente($v['tipo'], $v['id']);
if (!$info) { Verificacion::enviar($v['tipo'], $v['id']); $info = Verificacion::vigente($v['tipo'], $v['id']); }
$pasos = $v['tipo'] === 'socio' && !empty($v['registro']);

layout_inicio('Verifica tu correo'); ?>
<div class="reg-page">
  <?php if ($pasos) reg_cabecera(5); else echo '<header class="reg-head"><a href="' . url('index.php') . '">' . logo() . '</a><span class="tag mono">VERIFICACIÓN</span></header>'; ?>
  <div class="reg-body"><div class="panel rise">
    <p class="kicker"><?= $pasos ? 'Paso 5 de 5' : 'Seguridad de la cuenta' ?></p><h2 class="title">Verifica tu correo</h2>
    <p class="lead">Enviamos un código de 6 dígitos a <strong><?= e($info['email']) ?></strong>. Vence en 15 minutos.</p>
    <?php if (CORREO_SIMULADO): ?>
    <div class="mailbox"><div class="mailbox-head"><?= icon('file', 16) ?> Bandeja simulada <span class="tag mono">PROTOTIPO</span></div>
      <p><strong>FIT CODE</strong> &lt;no-responder@fitcode.mx&gt;<br>Tu código de verificación es <span class="mono accent" style="font-size:18px;letter-spacing:.2em"><?= e($info['codigo_demo']) ?></span></p>
      <p class="hint" style="margin:0">En producción (CORREO_SIMULADO = false) el código llega al correo real por SMTP y no se muestra aquí.</p></div>
    <?php endif; ?>
    <form method="post" class="form card corners" autocomplete="off"><?= csrf_field() ?>
      <input type="hidden" name="codigo" id="vcod"><span class="label">Código de verificación</span>
      <div class="otp<?= $err ? ' shake' : '' ?>" data-target="vcod"><?php for ($i = 0; $i < 6; $i++): ?><input inputmode="numeric" maxlength="1" aria-label="Dígito <?= $i + 1 ?>"<?= $i ? '' : ' autofocus' ?>><?php endfor; ?></div>
      <?php if ($err): ?><p class="hint err" role="alert" style="margin:0"><?= e($err) ?></p><?php endif; ?>
      <button class="btn btn-primary btn-block" type="submit" disabled>Verificar correo <?= icon('check', 18) ?></button>
    </form>
    <form method="post" style="text-align:center;margin-top:18px"><?= csrf_field() ?><input type="hidden" name="accion" value="reenviar"><span class="hint">¿No te llegó? </span><button class="link" style="background:none;border:0;cursor:pointer;font:inherit;font-size:12.5px">Reenviar código</button></form>
  </div></div>
</div>
<?php layout_fin();
