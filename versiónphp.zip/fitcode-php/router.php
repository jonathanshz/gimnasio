<?php
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (preg_match('#^/(includes|storage|database)(/|$)#', $path)) {
    http_response_code(403);
    exit('403 · Acceso denegado');
}
return false;
