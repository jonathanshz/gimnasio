const BADGE = { activa: 'ok', ACTIVA: 'ok', LIBRE: 'ok', pagado: 'ok', activo: 'ok', permitido: 'ok', pendiente: 'warn', OCUPADA: 'warn', vencida: 'bad', cancelada: 'bad', cancelado: 'mute', expirado: 'mute', rechazado: 'bad', inactivo: 'bad', MANTENIMIENTO: 'mute' };
const badge = (e, txt) => `<span class="badge badge-${BADGE[e] || (/denegad|invalid|sin_|vencid/.test(e) ? 'bad' : 'mute')}">${esc((txt || e).toUpperCase().replace(/_/g, ' '))}</span>`;
const errP = (E, k) => E[k] ? `<p class="hint err" data-server="1">${esc(E[k])}</p>` : '';
const opts = (cat, sel) => '<option value="">Selecciona…</option>' + cat.map(c => `<option${c === sel ? ' selected' : ''}>${esc(c)}</option>`).join('');
const RE_NOMBRE = /^[A-ZÁÉÍÓÚÜÑ][A-ZÁÉÍÓÚÜÑ '.-]{0,59}$/;
const RE_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const uploadField = (name, titulo, ayuda, cargado) => `
<div class="field"><span class="label">${esc(titulo)} <span class="req">*</span></span>
  <label class="drop"><span class="drop-ico">${icon('upload', 18)}</span><span><strong>Selecciona o arrastra un archivo</strong><small>${esc(ayuda)}</small></span>
  <input type="file" name="${name}" accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/*"></label>
  ${cargado ? `<p class="hint" style="color:var(--ok)">✓ Ya cargado (${esc(cargado.nombre)}). Puedes reemplazarlo.</p>` : ''}</div>`;
const firmaField = (titulo, cargada) => `
<div class="field" data-signature>
  <span class="label">${titulo} <span class="req">*</span></span>
  <div class="sig-tabs" role="tablist"><button type="button" class="on" data-pane="draw">Dibujar firma</button><button type="button" data-pane="file">Subir imagen</button></div>
  <div data-sig-pane="draw"><div class="sig"><canvas aria-label="Lienzo para firmar"></canvas>
    <div class="sig-bar"><span data-sig-status>Firma dentro del recuadro</span><button type="button" class="btn btn-ghost btn-sm" data-sig-clear>Limpiar</button></div></div>
    <input type="hidden" name="firma_data"></div>
  <div data-sig-pane="file" class="hidden"><label class="drop"><span class="drop-ico">${icon('pen', 18)}</span><span><strong>Imagen de la firma</strong><small>PNG o JPG · máx. 5 MB</small></span>
    <input type="file" name="firma_file" accept="image/png,image/jpeg,image/webp"></label></div>
  ${cargada ? '<p class="hint" style="color:var(--ok)">✓ Firma ya capturada. Puedes volver a firmar si quieres.</p>' : ''}
</div>`;
const pwField = (id = 'pw', label = 'Contraseña') => `
<div class="field"><label for="${id}">${label} <span class="req">*</span></label>
  <div class="input-wrap">${icon('lock', 18)}<input class="input" type="password" id="${id}" name="password" autocomplete="new-password" data-password><button type="button" class="peek" aria-label="Mostrar contraseña">${icon('eye', 18)}</button></div>
  <div class="pw-meter"><i></i></div>
  <ul class="pw-rules"><li data-rule="lower">Letras minúsculas (a-z)</li><li data-rule="upper">Al menos una MAYÚSCULA</li><li data-rule="num">Al menos un número</li><li data-rule="sym">Al menos un signo (#$!%*)</li><li data-rule="len">Mínimo 8 caracteres</li></ul></div>`;

async function leerDocumentos(form, requeridos, docs, E, etiquetaFirma) {
  for (const [campo, lbl] of Object.entries(requeridos)) {
    const f = form.querySelector(`input[name=${campo}]`)?.files[0];
    if (f) { try { docs[campo] = await prepararArchivo(f); } catch (e) { E[campo] = `${lbl}: ${e.message}.`; } }
    else if (!docs[campo]) E[campo] = `${lbl}: adjunta el archivo.`;
  }
  const dibujo = form.querySelector('input[name=firma_data]')?.value;
  if (dibujo) docs.firma = { nombre: 'firma.png', mime: 'image/png', data: dibujo };
  else { const f = form.querySelector('input[name=firma_file]')?.files[0]; if (f) { try { docs.firma = await prepararArchivo(f); } catch (e) { E.firma = 'Firma: ' + e.message + '.'; } } }
  if (!docs.firma && !E.firma) E.firma = `Falta la ${etiquetaFirma}.`;
}

let loginState = { error: null, id: '' };
route('/', () => {
  if (socioActual()) return redirect('/portal');
  const nuevo = SS.get('nuevo'); SS.del('nuevo');
  const st = loginState; loginState = { error: null, id: '' };
  const k = Repo.asistencias.kpisHoy(), libres = Repo.equipos.listar().filter(m => m.disponibilidad === 'LIBRE').length;
  const activos = Repo.socios.buscar('').filter(s => Repo.membresias.actual(s.id)?.estado === 'activa').length;
  return `
<div class="welcome">
  <section class="hero">
    <div class="hero-scan" aria-hidden="true"></div><div class="hero-ring" aria-hidden="true"></div>
    <div class="hero-top rise">${logo()}<span class="chip mono"><span class="dot dot-live"></span>ABIERTO · 05:00 — 23:00</span></div>
    <div>
      <p class="kicker rise rise-2">Bienvenid@ a</p>
      <h1 class="hero-title rise rise-2" aria-label="FIT CODE"><span>FIT</span><span class="outline">CODE<span class="lime" aria-hidden="true"></span></span></h1>
      <p class="hero-sub rise rise-3">Tu entrenamiento, tu acceso y tu progreso en un solo código. Entra, escanea y entrena.</p>
      <div class="hero-stats rise rise-4"><div><strong class="mono">${activos}</strong><small>Socios activos</small></div><div><strong class="mono">${libres}</strong><small>Máquinas libres ahora</small></div><div><strong class="mono">${k.dentro}</strong><small>Entrenando ahora</small></div></div>
    </div>
    <p class="dim mono" style="font-size:11px;letter-spacing:.1em;margin:40px 0 0">FIT CODE © ${new Date().getFullYear()} · ACCESO DIGITAL</p>
  </section>
  <section class="auth-side"><div class="panel rise rise-3">
    <p class="kicker">Socios</p><h2 class="title">Inicia sesión</h2><p class="lead">Usa tu usuario, correo o número de teléfono.</p>
    ${nuevo ? `<div class="user-reveal corners"><span class="label">Correo verificado · tu usuario es</span><span class="mono">${esc(nuevo)}</span></div>` : ''}
    ${st.error ? `<div class="alert alert-bad" role="alert" style="margin-bottom:18px">${icon('alert', 18)}<span>${esc(st.error)}</span></div>` : ''}
    <form class="form" data-form="login" novalidate>
      <div class="field"><label for="identificador">Usuario, correo o número</label>
        <div class="input-wrap">${icon('user', 18)}<input class="input" id="identificador" name="identificador" value="${esc(st.id || nuevo || '')}" autocomplete="username" placeholder="ANAPP-150398 · ana@correo.mx · 5512345678" ${nuevo ? '' : 'autofocus'}></div></div>
      <div class="field"><label for="password">Contraseña</label>
        <div class="input-wrap">${icon('lock', 18)}<input class="input" type="password" id="password" name="password" autocomplete="current-password" placeholder="••••••••" ${nuevo ? 'autofocus' : ''}><button type="button" class="peek" aria-label="Mostrar contraseña">${icon('eye', 18)}</button></div></div>
      <button class="btn btn-primary btn-block" type="submit">Entrar ${icon('arrow', 18, 'ico-arrow')}</button>
    </form>
    <div class="divider" style="margin:26px 0 18px">¿Primera vez?</div>
    <a href="#/registro/codigo" class="btn btn-ghost btn-block">${icon('key', 18)} Registrarme con mi código de recepción</a>
    <p class="hint" style="text-align:center;margin-top:14px">El código de 6 dígitos se entrega únicamente en la recepción del gimnasio.</p>
    <p class="hint" style="text-align:center;margin-top:30px"><a class="link" href="#/personal">Acceso para personal (recepción, coaches y administración)</a></p>
    <details class="demo-box"><summary>Cuentas de demostración</summary>
      <p>Socia activa: <span class="mono">ANAPP-150398</span> · <span class="mono">Socio#2026</span><br>Por vencer: <span class="mono">LUISRM-020901</span> · Vencida (menor): <span class="mono">SOFIAHL-110510</span></p>
      <button class="btn btn-sm btn-ghost" data-action="reset">${icon('refresh', 14)} Reiniciar demo</button></details>
  </div></section>
</div>`;
});
FORMS.login = d => {
  const id = (d.identificador || '').trim(), pw = d.password || ''; loginState.id = id;
  if (!id || !pw) { loginState.error = 'Escribe tu usuario, correo o número y tu contraseña.'; return render(); }
  const r = Repo.socios.login(id, pw);
  if (r.ok) { SS.set('socio', r.socio.id); SS.del('reg'); flash('ok', `Bienvenid@, ${r.socio.nombre}. Tu código de acceso está listo.`); return go('/portal'); }
  if (r.sinVerificar) { SS.set('verif', { tipo: 'socio', id: r.socio.id, usuario: r.socio.usuario }); flash('error', 'Antes de entrar, verifica tu correo.'); return go('/verificar'); }
  loginState.error = r.error; render();
};

let verifErr = null;
route('/verificar', () => {
  const v = SS.get('verif'); if (!v) return redirect('/');
  let info = Repo.verificacion.ultimo(v.tipo, v.id);
  if (!info || info.expira_en < ahoraISO()) { const r = Repo.verificacion.enviar(v.tipo, v.id); info = { email: r.email, codigoDemo: r.codigoDemo }; }
  const err = verifErr; verifErr = null;
  const pasos = v.tipo === 'socio' && v.registro;
  return `<div class="reg-page">${pasos ? regHead(5) : `<header class="reg-head"><a href="#/">${logo()}</a><span class="tag mono">VERIFICACIÓN</span></header>`}
  <div class="reg-body"><div class="panel rise">
    <p class="kicker">${pasos ? 'Paso 5 de 5' : 'Seguridad de la cuenta'}</p><h2 class="title">Verifica tu correo</h2>
    <p class="lead">Enviamos un código de 6 dígitos a <strong>${esc(info.email)}</strong>. Vence en 15 minutos.</p>
    <div class="mailbox"><div class="mailbox-head">${icon('file', 16)} Bandeja simulada <span class="tag mono">PROTOTIPO</span></div>
      <p><strong>FIT CODE</strong> &lt;no-responder@fitcode.mx&gt;<br>Tu código de verificación es <span class="mono accent" style="font-size:18px;letter-spacing:.2em">${info.codigoDemo || '••••••'}</span></p>
      <p class="hint" style="margin:0">En producción este mensaje llega al correo real (PHPMailer/SMTP) y nunca se muestra aquí.</p></div>
    <form class="form card corners" data-form="verificar" autocomplete="off">
      <input type="hidden" name="codigo" id="vcod"><span class="label">Código de verificación</span>
      <div class="otp${err ? ' shake' : ''}" data-target="vcod">${'<input inputmode="numeric" maxlength="1" aria-label="Dígito">'.repeat(6)}</div>
      ${err ? `<p class="hint err" role="alert" style="margin:0">${esc(err)}</p>` : ''}
      <button class="btn btn-primary btn-block" type="submit" disabled>Verificar correo ${icon('check', 18)}</button>
    </form>
    <p class="hint" style="text-align:center;margin-top:18px">¿No te llegó? <a class="link" href="#" data-action="reenviar">Reenviar código</a></p>
  </div></div></div>`;
});
FORMS.verificar = d => {
  const v = SS.get('verif'), r = Repo.verificacion.confirmar(v.tipo, v.id, d.codigo || '');
  if (!r.ok) { verifErr = r.error; return render(); }
  SS.del('verif');
  if (v.tipo === 'socio') { SS.set('nuevo', v.usuario); flash('ok', '¡Correo verificado! Tu cuenta está lista. Inicia sesión.'); return go('/'); }
  flash('ok', 'Correo verificado. Tu cuenta quedó pendiente de aprobación por administración; te avisaremos por correo.');
  go('/personal');
};
ACTIONS.reenviar = () => { const v = SS.get('verif'), r = Repo.verificacion.enviar(v.tipo, v.id); if (!r.ok) toast('error', r.error); else { flash('ok', 'Te enviamos un código nuevo.'); render(); } };

const PASOS = ['Código', 'Tipo', 'Datos', 'Cuenta', 'Verificar'];
const regHead = paso => `
<header class="reg-head"><a href="#/">${logo()}</a>
  <ol class="steps" aria-label="Progreso del registro">${PASOS.map((t, i) => { const n = i + 1; return `<li class="${n < paso ? 'done' : n === paso ? 'on' : ''}"><span class="n mono">${n < paso ? '✓' : n}</span><span class="t">${t}</span></li>`; }).join('')}</ol>
  <a href="#/" class="btn btn-ghost btn-sm">Cancelar</a></header>`;
function regRequiere(...claves) {
  const r = SS.get('reg');
  if (!r || !r.codigo_id || Date.now() - r.t > 45 * 60000) { SS.del('reg'); flash('error', 'Ingresa tu código de recepción para comenzar el registro.'); return { rd: redirect('/registro/codigo') }; }
  for (const c of claves) if (!r[c]) return { rd: redirect(c === 'tipo' ? '/registro/tipo' : '/registro/datos') };
  return { r };
}

let codigoErr = null;
route('/registro/codigo', () => {
  if (socioActual()) return redirect('/portal');
  const err = codigoErr; codigoErr = null;
  return `<div class="reg-page">${regHead(1)}<div class="reg-body"><div class="panel rise">
    <p class="kicker">Paso 1 de 5</p><h2 class="title">Tu código de recepción</h2>
    <p class="lead">Por seguridad y privacidad del gimnasio, solo puedes registrarte con el código único de 6 dígitos que te entregan en recepción.</p>
    <form class="form card corners" data-form="codigo" autocomplete="off"><input type="hidden" name="codigo" id="codigo"><span class="label">Código único</span>
      <div class="otp${err ? ' shake' : ''}" data-target="codigo">${'<input inputmode="numeric" maxlength="1" aria-label="Dígito">'.repeat(6)}</div>
      ${err ? `<p class="hint err" role="alert" style="margin:0">${esc(err)}</p>` : ''}
      <button class="btn btn-primary btn-block" type="submit" disabled>Validar código ${icon('arrow', 18)}</button></form>
    <div class="alert" style="margin-top:18px">${icon('shield', 18)}<span class="muted" style="font-size:13.5px">Prototipo: cualquier combinación de 6 dígitos del 0 al 9 es válida. Recepción genera códigos reales desde su panel.</span></div>
    <p class="hint" style="text-align:center;margin-top:22px">¿Ya tienes cuenta? <a class="link" href="#/">Inicia sesión</a></p>
  </div></div></div>`;
});
FORMS.codigo = d => {
  const r = Repo.codigos.validar((d.codigo || '').replace(/\s/g, ''));
  if (!r.ok) { codigoErr = r.error; return render(); }
  SS.set('reg', { codigo_id: r.id, t: Date.now() }); flash('ok', 'Código validado. Continuemos con tu registro.'); go('/registro/tipo');
};

route('/registro/tipo', () => {
  const { r, rd } = regRequiere(); if (!r) return rd;
  return `<div class="reg-page">${regHead(2)}<div class="reg-body"><div class="panel panel-wide rise">
    <p class="kicker">Paso 2 de 5</p><h2 class="title">¿Quién se va a registrar?</h2>
    <p class="lead">Los socios menores de edad necesitan la identificación y la firma de su padre, madre o tutor.</p>
    <form class="choice-grid" data-form="tipo">
      <button class="choice" name="tipo" value="mayor" type="submit"><span class="big">18<small>+ años</small></span><h3>Mayor de edad</h3><p>Registro con tus datos, identificación oficial y tu firma electrónica.</p><span class="go">Continuar ${icon('arrow', 16)}</span></button>
      <button class="choice" name="tipo" value="menor" type="submit"><span class="big">−18<small>años</small></span><h3>Menor de edad</h3><p>Identificación del menor y del padre/tutor, más la firma electrónica del padre/tutor.</p><span class="go">Continuar ${icon('arrow', 16)}</span></button>
    </form></div></div></div>`;
});
FORMS.tipo = d => { const r = SS.get('reg'); if (['mayor', 'menor'].includes(d.tipo)) { r.tipo = d.tipo; delete r.datos; delete r.datos_ok; SS.set('reg', r); go('/registro/datos'); } };

let datosErr = {};
route('/registro/datos', () => {
  const { r, rd } = regRequiere('tipo'); if (!r) return rd;
  const menor = r.tipo === 'menor', v = r.datos || {}, docs = r.docs || {}, E = datosErr; datosErr = {};
  const val = k => esc(v[k] || ''), inv = k => E[k] ? ' invalid' : '', n = Object.keys(E).length;
  return `<div class="reg-page">${regHead(3)}<div class="reg-body"><div class="panel panel-wide rise">
    <p class="kicker">Paso 3 de 5 · ${menor ? 'Menor de edad' : 'Mayor de edad'}</p><h2 class="title">Datos del socio</h2>
    <p class="lead">Escribe todo en <strong>MAYÚSCULAS</strong> (el formulario lo convierte automáticamente). Los campos con <span class="accent">*</span> son obligatorios.</p>
    ${n ? `<div class="alert alert-bad" role="alert" style="margin-bottom:22px">${icon('alert', 18)}<span>Revisa ${n} campo(s) marcados abajo.</span></div>` : ''}
    <form class="form" data-form="datos" novalidate>
      ${bloqueIdentidad(v, E, menor ? '01 · Identidad del menor' : '01 · Identidad', r.tipo)}
      <fieldset class="fieldset"><legend>02 · Contacto</legend><div class="form-grid">
        <div class="field col-6${inv('tel_contacto')}"><label for="tc">Número de contacto <span class="req">*</span></label><input class="input mono" id="tc" name="tel_contacto" value="${val('tel_contacto')}" inputmode="tel" data-digits="10" placeholder="10 dígitos">${errP(E, 'tel_contacto')}</div>
        <div class="field col-6${inv('tel_emergencia')}"><label for="te">Número de emergencia <span class="req">*</span></label><input class="input mono" id="te" name="tel_emergencia" value="${val('tel_emergencia')}" inputmode="tel" data-digits="10" placeholder="10 dígitos">${errP(E, 'tel_emergencia')}</div>
        ${menor ? `<div class="field col-12${inv('tutor_nombre')}"><label for="tutor">Nombre completo del padre, madre o tutor <span class="req">*</span></label><input class="input upper" id="tutor" name="tutor_nombre" value="${val('tutor_nombre')}" maxlength="120">${errP(E, 'tutor_nombre')}</div>` : ''}
      </div></fieldset>
      ${bloqueSalud(v, E, docs, 'Al indicar una enfermedad crónica, adjunta un documento en el que un médico avale que puedes realizar actividad física.')}
      <fieldset class="fieldset"><legend>04 · Documentos y firma</legend><div class="form-grid">
        <div class="col-${menor ? 6 : 12}">${uploadField('id_oficial', menor ? 'Identificación oficial del menor' : 'Foto de identificación oficial', menor ? 'Credencial escolar, pasaporte o CURP con foto' : 'INE, pasaporte o licencia · JPG, PNG o PDF', docs.id_oficial)}${errP(E, 'id_oficial')}</div>
        ${menor ? `<div class="col-6">${uploadField('id_tutor', 'Identificación oficial del padre/tutor', 'INE o pasaporte · JPG, PNG o PDF', docs.id_tutor)}${errP(E, 'id_tutor')}</div>` : ''}
        <div class="col-12">${firmaField(menor ? 'Firma electrónica del padre/tutor' : 'Firma electrónica', docs.firma)}${errP(E, 'firma')}
          <p class="hint">${menor ? 'Al firmar como padre/tutor autorizas la inscripción del menor, confirmas que la información es verídica y aceptas' : 'Al firmar confirmas que la información es verídica y aceptas'} el reglamento interno de FIT CODE.</p></div>
      </div></fieldset>
      <div class="actions"><a href="#/registro/tipo" class="btn btn-ghost">${icon('back', 18)} Cambiar tipo</a><button class="btn btn-primary" type="submit">Continuar ${icon('arrow', 18)}</button></div>
    </form></div></div></div>`;
});
function bloqueIdentidad(v, E, leyenda, tipo, extra = '') {
  const val = k => esc(v[k] || ''), inv = k => E[k] ? ' invalid' : '';
  return `<fieldset class="fieldset"><legend>${leyenda}</legend><div class="form-grid">
    <div class="field col-4${inv('nombre')}"><label for="nombre">Nombre(s) <span class="req">*</span></label><input class="input upper" id="nombre" name="nombre" value="${val('nombre')}" maxlength="60">${errP(E, 'nombre')}</div>
    <div class="field col-4${inv('apellido_paterno')}"><label for="ap">Apellido paterno <span class="req">*</span></label><input class="input upper" id="ap" name="apellido_paterno" value="${val('apellido_paterno')}" maxlength="60">${errP(E, 'apellido_paterno')}</div>
    <div class="field col-4${inv('apellido_materno')}"><label for="am">Apellido materno <span class="req">*</span></label><input class="input upper" id="am" name="apellido_materno" value="${val('apellido_materno')}" maxlength="60">${errP(E, 'apellido_materno')}</div>
    <div class="field col-4${inv('fecha_nacimiento')}"><label for="fn">Fecha de nacimiento <span class="req">*</span></label>
      <input class="input mono" id="fn" name="fecha_nacimiento" value="${val('fecha_nacimiento')}" placeholder="DD/MM/AAAA" inputmode="numeric" maxlength="10" data-date data-age-for="edad" data-tipo="${tipo === 'menor' ? 'MENOR' : 'MAYOR'}">
      ${E.fecha_nacimiento ? errP(E, 'fecha_nacimiento') : '<p class="hint">Formato DD/MM/AAAA</p>'}</div>
    <div class="field col-2"><label for="edad">Edad <span class="req">*</span></label><input class="input mono" id="edad" name="edad" value="${val('edad')}" readonly tabindex="-1"></div>
    ${extra || `<div class="field col-3${inv('genero')}"><label for="genero">Género <span class="req">*</span></label><select class="input" id="genero" name="genero">${opts(CAT_GENERO, v.genero)}</select>${errP(E, 'genero')}</div>
    <div class="field col-3${inv('sexo')}"><label for="sexo">Sexo <span class="req">*</span></label><select class="input" id="sexo" name="sexo">${opts(CAT_SEXO, v.sexo)}</select>${errP(E, 'sexo')}</div>`}
  </div></fieldset>`;
}
function bloqueSalud(v, E, docs, aviso, leyenda = '03 · Salud') {
  const inv = k => E[k] ? ' invalid' : '';
  return `<fieldset class="fieldset"><legend>${leyenda}</legend><div class="form-grid">
    <div class="field col-6${inv('servicio_medico')}"><label for="sm">Servicio médico con el que cuenta <span class="req">*</span></label><select class="input" id="sm" name="servicio_medico">${opts(CAT_SERVICIO, v.servicio_medico)}</select>${errP(E, 'servicio_medico')}</div>
    <div class="field col-6${inv('enfermedad_cronica')}"><label for="enf">¿Padece alguna enfermedad crónica? <span class="req">*</span></label><select class="input" id="enf" name="enfermedad_cronica" data-toggle-when="NINGUNA">${opts(CAT_ENF, v.enfermedad_cronica)}</select>${errP(E, 'enfermedad_cronica')}</div>
    <div class="field col-12 hidden" data-show-if="enf" data-values="OTRA"><label for="enf_o">Especifique la enfermedad <span class="req">*</span></label><input class="input upper" id="enf_o" name="enfermedad_otra" value="${esc(v.enfermedad_otra || '')}" maxlength="120">${errP(E, 'enfermedad_otra')}</div>
    <div class="col-12 hidden" data-show-if="enf"><div class="alert alert-warn" style="margin-bottom:12px">${icon('alert', 18)}<span>${aviso}</span></div>
      ${uploadField('cert_medico', 'Constancia médica', 'PDF o imagen firmada por un médico · máx. 5 MB', docs.cert_medico)}${errP(E, 'cert_medico')}</div>
  </div></fieldset>`;
}
function validarPersona(d, E, tipo, op = {}) {
  const v = {
    nombre: mayus(d.nombre), apellido_paterno: mayus(d.apellido_paterno), apellido_materno: mayus(d.apellido_materno),
    fecha_nacimiento: (d.fecha_nacimiento || '').trim(), edad: '', genero: d.genero || '', sexo: d.sexo || '',
    servicio_medico: d.servicio_medico || '', enfermedad_cronica: d.enfermedad_cronica || '', enfermedad_otra: mayus(d.enfermedad_otra),
  };
  [['nombre', 'Nombre'], ['apellido_paterno', 'Apellido paterno'], ['apellido_materno', 'Apellido materno']].forEach(([k, l]) => { if (!RE_NOMBRE.test(v[k])) E[k] = `${l}: solo letras en MAYÚSCULAS.`; });
  if (!op.sinFecha) {
    const nac = parseDMY(v.fecha_nacimiento);
    if (!nac) E.fecha_nacimiento = 'Usa el formato DD/MM/AAAA con una fecha real.';
    else {
      const edad = edadDesde(nac); v.edad = String(edad); v.fecha_iso = isoDate(nac);
      if (tipo === 'mayor' && edad < 18) E.fecha_nacimiento = 'Es menor de edad: regresa y elige “Menor de edad”.';
      if (tipo === 'menor' && edad >= 18) E.fecha_nacimiento = 'Es mayor de edad: regresa y elige “Mayor de edad”.';
      if (tipo === 'coach' && edad < 18) E.fecha_nacimiento = 'Para trabajar como coach debes ser mayor de edad.';
      if (edad > 110) E.fecha_nacimiento = 'Revisa el año de nacimiento.';
    }
  }
  if (!op.sinGenero) { if (!CAT_GENERO.includes(v.genero)) E.genero = 'Selecciona un género.'; if (!CAT_SEXO.includes(v.sexo)) E.sexo = 'Selecciona el sexo.'; }
  if (!op.sinSalud) {
    if (!CAT_SERVICIO.includes(v.servicio_medico)) E.servicio_medico = 'Selecciona el servicio médico.';
    if (!CAT_ENF.includes(v.enfermedad_cronica)) E.enfermedad_cronica = 'Indica si padece alguna enfermedad crónica.';
    if (v.enfermedad_cronica === 'OTRA' && v.enfermedad_otra.length < 3) E.enfermedad_otra = 'Especifica la enfermedad.';
  }
  return v;
}
FORMS.datos = async (d, form) => {
  const r = SS.get('reg'); if (!r) return go('/registro/codigo');
  const menor = r.tipo === 'menor', E = {}, docs = r.docs || {};
  const v = validarPersona(d, E, r.tipo);
  v.tel_contacto = (d.tel_contacto || '').replace(/\D/g, ''); v.tel_emergencia = (d.tel_emergencia || '').replace(/\D/g, ''); v.tutor_nombre = menor ? mayus(d.tutor_nombre) : '';
  if (menor && !/^[A-ZÁÉÍÓÚÜÑ][A-ZÁÉÍÓÚÜÑ '.-]{4,119}$/.test(v.tutor_nombre)) E.tutor_nombre = 'Escribe el nombre completo del padre, madre o tutor en MAYÚSCULAS.';
  if (!/^\d{10}$/.test(v.tel_contacto)) E.tel_contacto = 'Número de contacto a 10 dígitos.';
  if (!/^\d{10}$/.test(v.tel_emergencia)) E.tel_emergencia = 'Número de emergencia a 10 dígitos.'; else if (v.tel_emergencia === v.tel_contacto) E.tel_emergencia = 'Debe ser distinto al número de contacto.';
  const btn = form.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'Procesando…';
  const req = { id_oficial: menor ? 'Identificación del menor' : 'Identificación oficial' };
  if (menor) req.id_tutor = 'Identificación del padre/tutor';
  if (v.enfermedad_cronica && v.enfermedad_cronica !== 'NINGUNA') req.cert_medico = 'Constancia médica'; else delete docs.cert_medico;
  await leerDocumentos(form, req, docs, E, menor ? 'firma electrónica del padre/tutor' : 'firma electrónica');
  r.datos = v; r.docs = docs;
  if (!Object.keys(E).length) { r.datos_ok = true; if (SS.set('reg', r)) return go('/registro/cuenta'); }
  delete r.datos_ok; SS.set('reg', r); datosErr = E; render();
};

let cuentaState = { E: {}, email: '', telefono: null };
route('/registro/cuenta', () => {
  const { r, rd } = regRequiere('tipo', 'datos_ok'); if (!r) return rd;
  const d = r.datos, usuario = Repo.socios.generarUsuario(d.nombre, d.apellido_paterno, d.apellido_materno, d.fecha_iso);
  const st = cuentaState; cuentaState = { E: {}, email: '', telefono: null }; const E = st.E;
  return `<div class="reg-page">${regHead(4)}<div class="reg-body"><div class="panel rise" style="max-width:520px">
    <p class="kicker">Paso 4 de 5</p><h2 class="title">Crea tu cuenta</h2><p class="lead">Generamos tu usuario con tu nombre y fecha de nacimiento. Completa tus datos de acceso.</p>
    <div class="user-reveal corners"><span class="label">Tu usuario asignado</span><span class="mono">${esc(usuario)}</span><p class="hint" style="margin:10px 0 0">Nombre + iniciales de apellidos + fecha (DDMMAA). También podrás entrar con tu correo o número.</p></div>
    <form class="form" data-form="cuenta" novalidate>
      <div class="field"><label for="email">Correo electrónico <span class="req">*</span></label><div class="input-wrap">${icon('file', 18)}<input class="input" type="email" id="email" name="email" value="${esc(st.email)}" autocomplete="email" placeholder="tucorreo@ejemplo.com"></div>${errP(E, 'email')}<p class="hint">Te enviaremos un código para verificarlo.</p></div>
      <div class="field"><label for="tel">Número de teléfono <span class="req">*</span></label><div class="input-wrap">${icon('user', 18)}<input class="input mono" id="tel" name="telefono" value="${esc(st.telefono ?? d.tel_contacto)}" inputmode="tel" data-digits="10"></div>${errP(E, 'telefono')}</div>
      ${pwField()}${errP(E, 'password')}
      <div class="field"><label for="pw2">Confirmar contraseña <span class="req">*</span></label><div class="input-wrap">${icon('lock', 18)}<input class="input" type="password" id="pw2" name="password2" autocomplete="new-password" data-match="pw"></div><p class="hint"></p>${errP(E, 'password2')}</div>
      <button class="btn btn-primary btn-block" type="submit">${icon('check', 18)} Crear cuenta y verificar correo</button>
    </form></div></div></div>`;
});
function validarCuenta(d, E, usuarioBase = '') {
  const email = (d.email || '').trim().toLowerCase(), pw = d.password || '';
  if (!RE_EMAIL.test(email)) E.email = 'Escribe un correo válido.'; else if (Repo.socios.existeEmail(email)) E.email = 'Ese correo ya está registrado.';
  const f = validarPassword(pw);
  if (f.length) E.password = 'La contraseña necesita: ' + f.join(', ') + '.';
  else if (pw !== d.password2) E.password2 = 'Las contraseñas no coinciden.';
  else if (usuarioBase && pw.toUpperCase().includes(usuarioBase)) E.password = 'No uses tu nombre de usuario dentro de la contraseña.';
  return email;
}
FORMS.cuenta = d => {
  const r = SS.get('reg'); if (!r) return go('/registro/codigo');
  const D = r.datos, E = {}, usuario = Repo.socios.generarUsuario(D.nombre, D.apellido_paterno, D.apellido_materno, D.fecha_iso);
  const email = validarCuenta(d, E, usuario.split('-')[0]), tel = (d.telefono || '').replace(/\D/g, '');
  if (!/^\d{10}$/.test(tel)) E.telefono = 'El número debe tener 10 dígitos.'; else if (Repo.socios.existeTelefono(tel)) E.telefono = 'Ese número ya está registrado.';
  if (Object.keys(E).length) { cuentaState = { E, email, telefono: tel }; return render(); }
  const s = Repo.socios.crear({ ...D, usuario, email, telefono: tel, fecha_nacimiento: D.fecha_iso, tipo_socio: r.tipo, telefono_emergencia: D.tel_emergencia, password: d.password }, r.docs || {}, r.codigo_id);
  SS.del('reg'); SS.set('verif', { tipo: 'socio', id: s.id, usuario: s.usuario, registro: true });
  go('/verificar');
};
