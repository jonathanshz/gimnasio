'use strict';
const $ = (s, c = document) => c.querySelector(s);
const $$ = (s, c = document) => [...c.querySelectorAll(s)];

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const pad = (n, l = 2) => String(n).padStart(l, '0');
const isoDate = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const isoDateTime = d => `${isoDate(d)} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
const hoy = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
const hoyISO = () => isoDate(new Date());
const ahoraISO = () => isoDateTime(new Date());
const parseISO = s => { const [d, t = '00:00:00'] = String(s).split(' '); const [y, m, dd] = d.split('-').map(Number); const [h, mi, se] = t.split(':').map(Number); return new Date(y, m - 1, dd, h || 0, mi || 0, se || 0); };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const diasEntre = (a, b) => Math.round((parseISO(isoDate(b)) - parseISO(isoDate(a))) / 864e5);
const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];
const fechaMx = (s, hora = false) => { if (!s) return '—'; const d = parseISO(s); return `${pad(d.getDate())} ${MESES[d.getMonth()]} ${d.getFullYear()}` + (hora ? ` · ${pad(d.getHours())}:${pad(d.getMinutes())}` : ''); };
const horaDe = s => { const d = parseISO(s); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const dinero = n => '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' MXN';
const quitarAcentos = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9 ]/g, '');
const nombreCompleto = s => `${s.nombre} ${s.apellido_paterno} ${s.apellido_materno}`.trim();
const mayus = s => String(s ?? '').toLocaleUpperCase('es-MX').replace(/\s+/g, ' ').trim();
const hashPw = s => { let h1 = 0xdeadbeef, h2 = 0x41c6ce57; for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); h1 = Math.imul(h1 ^ c, 2654435761); h2 = Math.imul(h2 ^ c, 1597334677); } h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909); h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909); return 'h' + (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36); };

function validarPassword(p) {
  const e = [];
  if (p.length < 8) e.push('al menos 8 caracteres');
  if (!/[a-z]/.test(p)) e.push('una letra minúscula (a-z)');
  if (!/[A-Z]/.test(p)) e.push('una letra MAYÚSCULA');
  if (!/\d/.test(p)) e.push('un número');
  if (!/[^a-zA-Z0-9]/.test(p)) e.push('un signo (ej. # $ ! % *)');
  return e;
}
const validarRFC = r => /^[A-ZÑ&]{4}\d{6}$/.test(r);
function parseDMY(s) {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(s); if (!m) return null;
  const [dd, mm, yy] = [+m[1], +m[2], +m[3]]; const d = new Date(yy, mm - 1, dd);
  if (d.getDate() !== dd || d.getMonth() !== mm - 1 || d > hoy() || yy < 1900) return null;
  return d;
}
function edadDesde(d) { const n = new Date(); let a = n.getFullYear() - d.getFullYear(); if (n.getMonth() < d.getMonth() || (n.getMonth() === d.getMonth() && n.getDate() < d.getDate())) a--; return a; }
function luhn(num) { let s = 0; [...num].reverse().forEach((c, i) => { let d = +c; if (i % 2 === 0) { d *= 2; if (d > 9) d -= 9; } s += d; }); return (10 - s % 10) % 10; }
function generarCodigoBarras(id, ingreso) { const c = ingreso.slice(2, 4) + pad(id, 6); return 'FC' + c + luhn(c); }
function codigoValido(c) { const m = /^FC(\d{8})(\d)$/.exec(c); return !!m && luhn(m[1]) === +m[2]; }

const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5V21h-6v-6H9v6H3z"/>',
  id: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="12" r="2.5"/><path d="M14 10h4M14 14h4"/>',
  card: '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/>',
  receipt: '<path d="M5 3h14v18l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  logout: '<path d="M15 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4M10 17l5-5-5-5M15 12H3"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M2 20c0-3.5 3-5.5 7-5.5s7 2 7 5.5M16 4.5a3.5 3.5 0 0 1 0 7M18 14.6c2.4.6 4 2.3 4 5.4"/>',
  shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/>',
  scan: '<path d="M3 7V4h3M18 4h3v3M21 17v3h-3M6 20H3v-3M7 8v8M10 8v8M13 8v8M17 8v8"/>',
  check: '<path d="m5 12 5 5 9-10"/>',
  alert: '<path d="M12 3 2 20h20zM12 10v4M12 17v.5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  back: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  lock: '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
  file: '<path d="M6 2h8l5 5v15H6z"/><path d="M14 2v5h5"/>',
  dumbbell: '<path d="M6 7v10M3 9v6M18 7v10M21 9v6M6 12h12"/>',
  bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  pen: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.9-3M4 4v4h4M4 13a8 8 0 0 0 14.9 3M20 20v-4h-4"/>',
  print: '<path d="M6 9V3h12v6M6 17H4v-7h16v7h-2M7 14h10v7H7z"/>',
  key: '<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  swap: '<path d="M7 4 3 8l4 4M3 8h14M17 20l4-4-4-4M21 16H7"/>',
};
const icon = (n, s = 20, cls = '') => `<svg class="ico ${cls}" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;
const logo = () => `<span class="logo"><span class="logo-mark">${icon('bolt', 16)}</span><span>FIT<b>CODE</b></span></span>`;

const C128 = ['212222','222122','222221','121223','121322','131222','122213','122312','132212','221213','221312','231212','112232','122132','122231','113222','123122','123221','223211','221132','221231','213212','223112','312131','311222','321122','321221','312212','322112','322211','212123','212321','232121','111323','131123','131321','112313','132113','132311','211313','231113','231311','112133','112331','132131','113123','113321','133121','313121','211331','231131','213113','213311','213131','311123','311321','331121','312113','312311','332111','314111','221411','431111','111224','111422','121124','121421','141122','141221','112214','112412','122114','122411','142112','142211','241211','221114','413111','241112','134111','111242','121142','121241','114212','124112','124211','411212','421112','421211','212141','214121','412121','111143','111341','131141','114113','114311','411113','411311','113141','114131','311141','411131','211412','211214','211232'];
function barcodeSVG(text, alto = 90, mod = 2, color = '#07080a') {
  const v = [104, ...[...text].map(c => c.charCodeAt(0) - 32)];
  let chk = v[0]; for (let i = 1; i < v.length; i++) chk += v[i] * i;
  v.push(chk % 103);
  const anchos = v.map(x => C128[x]).join('') + '2331112';
  let x = 10 * mod, r = '';
  [...anchos].forEach((w, i) => { const ww = +w * mod; if (i % 2 === 0) r += `<rect x="${x.toFixed(2)}" y="0" width="${ww.toFixed(2)}" height="${alto}"/>`; x += ww; });
  return `<svg class="barcode" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${(x + 10 * mod).toFixed(2)} ${alto}" preserveAspectRatio="none" role="img" aria-label="Código de barras ${esc(text)}"><g fill="${color}">${r}</g></svg>`;
}

const SS = {
  get: k => { try { return JSON.parse(sessionStorage.getItem('fc_' + k) || 'null'); } catch (_) { return null; } },
  set: (k, v) => { try { sessionStorage.setItem('fc_' + k, JSON.stringify(v)); return true; } catch (_) { toast('error', 'Los archivos son demasiado pesados para la demo. Usa imágenes más ligeras.'); return false; } },
  del: k => sessionStorage.removeItem('fc_' + k),
};
const socioActual = () => { const id = SS.get('socio'); return id ? Repo.socios.porId(id) : null; };
const staffActual = () => { const id = SS.get('staff'); return id ? Repo.personal.sesionActiva(id) : null; };

let pendingToasts = [];
function flash(t, m) { pendingToasts.push([t, m]); }
function toast(t, m) {
  let box = $('.toasts'); if (!box) { box = document.createElement('div'); box.className = 'toasts'; document.body.appendChild(box); }
  const el = document.createElement('div');
  el.className = `toast toast-${t}`; el.setAttribute('role', 'status');
  el.innerHTML = `${icon(t === 'ok' ? 'check' : 'alert', 18)}<span>${esc(m)}</span><button type="button" class="toast-x" aria-label="Cerrar">×</button>`;
  box.appendChild(el);
  const close = () => { el.style.opacity = '0'; el.style.transition = '.25s'; setTimeout(() => el.remove(), 260); };
  el.querySelector('.toast-x').onclick = close; setTimeout(close, 6000);
}

const ROUTES = [];
function route(pattern, fn) { ROUTES.push([new RegExp('^' + pattern.replace(/:(\w+)/g, '([^/]+)') + '$'), fn]); }
function go(path) { if (location.hash === '#' + path) render(); else location.hash = path; }
let cleanup = [];
function render() {
  cleanup.forEach(fn => fn()); cleanup = [];
  const full = location.hash.slice(1) || '/';
  const [path, qs] = full.split('?');
  const query = Object.fromEntries(new URLSearchParams(qs || ''));
  for (const [re, fn] of ROUTES) {
    const m = re.exec(path);
    if (m) {
      const app = $('#app');
      const html = fn({ params: m.slice(1).map(decodeURIComponent), query });
      if (html === null) return;
      app.innerHTML = html;
      document.title = (app.querySelector('h1,h2')?.textContent || 'Inicio') + ' · FIT CODE';
      window.scrollTo(0, 0);
      initUI(app);
      (window.__after || []).forEach(f => f(app)); window.__after = [];
      pendingToasts.forEach(([t, msg]) => toast(t, msg)); pendingToasts = [];
      return;
    }
  }
  go('/');
}
const after = fn => (window.__after = window.__after || []).push(fn);
function redirect(p) { setTimeout(() => go(p)); return null; }
window.addEventListener('hashchange', render);

const FORMS = {};
document.addEventListener('submit', ev => {
  const f = ev.target.closest('form[data-form]'); if (!f) return;
  ev.preventDefault();
  const fd = new FormData(f); const data = {};
  for (const [k, v] of fd.entries()) if (!(v instanceof File)) data[k] = v;
  if (ev.submitter?.name) data[ev.submitter.name] = ev.submitter.value;
  FORMS[f.dataset.form](data, f, ev);
});
document.addEventListener('click', ev => {
  const a = ev.target.closest('[data-action]'); if (!a) return;
  ev.preventDefault();
  ACTIONS[a.dataset.action](a, ev);
});
const ACTIONS = {
  print: () => window.print(),
  logout: () => { Repo.sesion.cerrar('socio', SS.get('socio')); SS.del('socio'); flash('ok', 'Sesión cerrada. ¡Buen entrenamiento!'); go('/'); },
  logoutStaff: () => { Repo.sesion.cerrar('usuario', SS.get('staff')); SS.del('staff'); flash('ok', 'Sesión del personal cerrada.'); go('/personal'); },
  reset: () => { if (confirm('¿Reiniciar la demo? Se borran las cuentas, pagos y asistencias que hayas creado.')) { Repo.reiniciar(); sessionStorage.clear(); flash('ok', 'Demo reiniciada con los datos originales.'); go('/'); } },
};

function initUI(root) {
  $$('input.upper, textarea.upper', root).forEach(el => el.addEventListener('input', () => {
    const s = el.selectionStart, e = el.selectionEnd;
    const v = el.value.toLocaleUpperCase('es-MX').replace(/[^A-ZÁÉÍÓÚÜÑ\s'.-]/g, '');
    if (v !== el.value) { el.value = v; try { el.setSelectionRange(s, e); } catch (_) {} }
  }));
  $$('[data-digits]', root).forEach(el => el.addEventListener('input', () => { el.value = el.value.replace(/\D/g, '').slice(0, +el.dataset.digits || 99); }));
  $$('[data-date]', root).forEach(el => {
    const ageEl = el.dataset.ageFor ? document.getElementById(el.dataset.ageFor) : null;
    const tipo = el.dataset.tipo, hint = el.closest('.field')?.querySelector('.hint'), original = hint?.textContent;
    el.addEventListener('input', () => {
      let d = el.value.replace(/\D/g, '').slice(0, 8);
      if (d.length > 4) d = d.slice(0, 2) + '/' + d.slice(2, 4) + '/' + d.slice(4); else if (d.length > 2) d = d.slice(0, 2) + '/' + d.slice(2);
      el.value = d; el.classList.remove('invalid', 'valid');
      if (hint && !hint.dataset.server) { hint.textContent = original; hint.classList.remove('err'); }
      const dt = parseDMY(d);
      if (!dt) { if (ageEl) ageEl.value = ''; if (d.length === 10) { el.classList.add('invalid'); if (hint) { hint.textContent = 'Fecha no válida.'; hint.classList.add('err'); } } return; }
      const age = edadDesde(dt); if (ageEl) ageEl.value = age;
      const fuera = (tipo === 'MAYOR' && age < 18) || (tipo === 'MENOR' && age >= 18);
      el.classList.add(fuera ? 'invalid' : 'valid');
      if (fuera && hint) { hint.textContent = tipo === 'MAYOR' ? 'La edad indica que eres menor de edad: regresa y elige “Menor de edad”.' : 'La edad indica mayoría de edad: regresa y elige “Mayor de edad”.'; hint.classList.add('err'); }
    });
    if (el.value) el.dispatchEvent(new Event('input'));
  });
  $$('.otp', root).forEach(box => {
    const cells = $$('input', box), hidden = document.getElementById(box.dataset.target), btn = box.closest('form')?.querySelector('[type=submit]');
    const sync = () => { const v = cells.map(c => c.value).join(''); hidden.value = v; cells.forEach(c => c.classList.toggle('filled', !!c.value)); if (btn) btn.disabled = v.length !== 6; };
    cells.forEach((c, i) => {
      c.addEventListener('input', () => { c.value = c.value.replace(/\D/g, '').slice(-1); if (c.value && cells[i + 1]) cells[i + 1].focus(); sync(); });
      c.addEventListener('keydown', ev => {
        if (ev.key === 'Backspace' && !c.value && cells[i - 1]) { cells[i - 1].focus(); cells[i - 1].value = ''; sync(); }
        if (ev.key === 'ArrowLeft' && cells[i - 1]) cells[i - 1].focus();
        if (ev.key === 'ArrowRight' && cells[i + 1]) cells[i + 1].focus();
      });
      c.addEventListener('paste', ev => { const d = (ev.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6); if (!d) return; ev.preventDefault(); [...d].forEach((ch, j) => { if (cells[j]) cells[j].value = ch; }); (cells[d.length] || cells[5]).focus(); sync(); });
    });
    sync();
    if (box.classList.contains('shake')) setTimeout(() => box.classList.remove('shake'), 500);
    cells[0].focus();
  });
  $$('.drop', root).forEach(drop => {
    const input = $('input[type=file]', drop), title = $('strong', drop), sub = $('small', drop), t0 = title.textContent, s0 = sub.textContent;
    ['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, () => drop.classList.add('over')));
    ['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, () => drop.classList.remove('over')));
    input.addEventListener('change', () => {
      $('.drop-thumb', drop)?.remove();
      const f = input.files[0];
      if (!f) { drop.classList.remove('has-file'); title.textContent = t0; sub.textContent = s0; return; }
      if (f.size > 5 * 1024 * 1024) { alert('El archivo supera los 5 MB.'); input.value = ''; return input.dispatchEvent(new Event('change')); }
      drop.classList.add('has-file'); title.textContent = f.name; sub.textContent = (f.size / 1024).toFixed(0) + ' KB · listo';
      if (f.type.startsWith('image/')) { const img = document.createElement('img'); img.className = 'drop-thumb'; img.alt = ''; img.src = URL.createObjectURL(f); drop.appendChild(img); }
    });
  });
  $$('[data-toggle-when]', root).forEach(sel => {
    const run = () => { const v = sel.value; $$(`[data-show-if="${sel.id}"]`, root).forEach(box => { const vals = box.dataset.values ? box.dataset.values.split('|') : null; box.classList.toggle('hidden', !(vals ? vals.includes(v) : (v && v !== sel.dataset.toggleWhen))); }); };
    sel.addEventListener('change', run); run();
  });
  $$('[data-signature]', root).forEach(wrap => {
    const canvas = $('canvas', wrap), out = $('input[type=hidden]', wrap), ctx = canvas.getContext('2d');
    let drawing = false, dirty = false, last = null;
    const fit = () => {
      const r = canvas.getBoundingClientRect(); if (!r.width) return; const dpr = window.devicePixelRatio || 1;
      canvas.width = r.width * dpr; canvas.height = r.height * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#c8ff2e'; dirty = false; out.value = '';
      $('[data-sig-status]', wrap).textContent = 'Firma dentro del recuadro';
    };
    const pos = ev => { const r = canvas.getBoundingClientRect(); return { x: ev.clientX - r.left, y: ev.clientY - r.top }; };
    canvas.addEventListener('pointerdown', ev => { drawing = true; last = pos(ev); canvas.setPointerCapture(ev.pointerId); });
    canvas.addEventListener('pointermove', ev => { if (!drawing) return; const p = pos(ev); ctx.beginPath(); ctx.moveTo(last.x, last.y); ctx.lineTo(p.x, p.y); ctx.stroke(); last = p; dirty = true; });
    const end = () => {
      if (!drawing) return; drawing = false; if (!dirty) return;
      const tmp = document.createElement('canvas'); tmp.width = canvas.width / 2; tmp.height = canvas.height / 2;
      const t = tmp.getContext('2d'); t.drawImage(canvas, 0, 0, tmp.width, tmp.height); t.globalCompositeOperation = 'source-in'; t.fillStyle = '#0b0e14'; t.fillRect(0, 0, tmp.width, tmp.height);
      out.value = tmp.toDataURL('image/png'); $('[data-sig-status]', wrap).textContent = 'Firma capturada ✓';
    };
    canvas.addEventListener('pointerup', end); canvas.addEventListener('pointerleave', end);
    $('[data-sig-clear]', wrap).addEventListener('click', () => { ctx.clearRect(0, 0, canvas.width, canvas.height); fit(); });
    const tabs = $$('.sig-tabs button', wrap);
    tabs.forEach(b => b.addEventListener('click', () => { tabs.forEach(x => x.classList.toggle('on', x === b)); $$('[data-sig-pane]', wrap).forEach(p => p.classList.toggle('hidden', p.dataset.sigPane !== b.dataset.pane)); if (b.dataset.pane === 'draw') requestAnimationFrame(fit); }));
    requestAnimationFrame(fit);
    const onR = () => { if (!dirty) fit(); }; window.addEventListener('resize', onR); cleanup.push(() => window.removeEventListener('resize', onR));
  });
  $$('[data-password]', root).forEach(input => {
    const box = input.closest('.field'), meter = $('.pw-meter i', box), rules = $$('[data-rule]', box);
    const T = { len: v => v.length >= 8, lower: v => /[a-z]/.test(v), upper: v => /[A-Z]/.test(v), num: v => /\d/.test(v), sym: v => /[^a-zA-Z0-9]/.test(v) };
    input.addEventListener('input', () => { let ok = 0; rules.forEach(li => { const p = T[li.dataset.rule](input.value); li.classList.toggle('ok', p); ok += p; }); meter.style.width = ok * 20 + '%'; meter.style.background = ok < 3 ? 'var(--bad)' : ok < 5 ? 'var(--warn)' : 'var(--accent)'; });
  });
  $$('[data-match]', root).forEach(c => {
    const other = document.getElementById(c.dataset.match), hint = c.closest('.field').querySelector('.hint');
    const run = () => { if (!c.value) { c.classList.remove('invalid', 'valid'); hint.textContent = ''; return; } const ok = c.value === other.value; c.classList.toggle('invalid', !ok); c.classList.toggle('valid', ok); hint.textContent = ok ? 'Las contraseñas coinciden.' : 'No coinciden.'; hint.classList.toggle('err', !ok); };
    c.addEventListener('input', run); other.addEventListener('input', run);
  });
  $$('.peek', root).forEach(b => b.addEventListener('click', () => { const i = b.parentElement.querySelector('input'); i.type = i.type === 'password' ? 'text' : 'password'; }));
  $$('.ring[data-pct]', root).forEach(r => { const bar = $('.bar', r), len = 2 * Math.PI * 70; bar.style.strokeDasharray = len; bar.style.strokeDashoffset = len; setTimeout(() => { bar.style.strokeDashoffset = len * (1 - r.dataset.pct / 100); }, 120); });
  const af = $('[autofocus]', root); if (af && !$('.otp', root)) af.focus();
}

const leerArchivo = f => new Promise((ok, ko) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = ko; r.readAsDataURL(f); });
async function prepararArchivo(f) {
  const tipos = ['application/pdf', 'image/jpeg', 'image/png', 'image/webp'];
  if (!tipos.includes(f.type)) throw new Error('formato no permitido (usa PDF, JPG, PNG o WEBP)');
  if (f.size > 5 * 1024 * 1024) throw new Error('supera los 5 MB');
  let data = await leerArchivo(f);
  if (f.type.startsWith('image/') && f.size > 250 * 1024) {
    const img = await new Promise(ok => { const i = new Image(); i.onload = () => ok(i); i.src = data; });
    const k = Math.min(1, 1200 / Math.max(img.width, img.height)), c = document.createElement('canvas');
    c.width = img.width * k; c.height = img.height * k; c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    data = c.toDataURL('image/jpeg', .75);
  }
  if (data.length > 1.5 * 1024 * 1024) data = null;
  return { nombre: f.name, mime: f.type, data };
}
function verDocumento(d) {
  if (!d) return;
  if (!d.data) return alert('Este archivo era muy pesado para guardarse en la demo; solo se registró su nombre: ' + d.nombre);
  const w = window.open('', '_blank'); if (!w) return alert('Permite las ventanas emergentes para ver el documento.');
  w.document.write(`<title>${esc(d.nombre)}</title><body style="margin:0;background:#111;display:grid;place-items:center;min-height:100vh">` + (d.mime === 'application/pdf' ? `<iframe src="${d.data}" style="border:0;width:100vw;height:100vh"></iframe>` : `<img src="${d.data}" style="max-width:100%;max-height:100vh">`));
}
