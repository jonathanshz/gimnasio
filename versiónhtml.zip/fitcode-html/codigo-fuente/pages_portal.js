const MENU_SOCIO = [
  ['inicio', '/portal', 'home', 'Mi acceso'],
  ['asignacion', '/portal/asignacion', 'id', 'Asignación y tipo de membresía'],
  ['membresia', '/portal/membresia', 'card', 'Consulta tu membresía'],
  ['pagos', '/portal/pagos', 'receipt', 'Pagos, recibos y cambio de plan'],
  ['avance', '/portal/avance', 'chart', 'Avance, rutina y nutrición'],
  ['maquinas', '/portal/maquinas', 'grid', 'Máquinas disponibles'],
];
function portal(titulo, activo, s, contenido) {
  return `<div class="shell">
  <aside class="side"><a href="#/portal" class="side-logo">${logo()}</a>
    <nav class="side-nav" aria-label="Menú del socio">${MENU_SOCIO.map(([k, h, ic, t]) => `<a href="#${h}" class="${k === activo ? 'on' : ''}">${icon(ic)}<span>${t}</span></a>`).join('')}</nav>
    <div class="side-user"><div class="avatar">${esc(s.nombre[0] + s.apellido_paterno[0])}</div>
      <div class="side-user-txt"><strong>${esc(s.nombre + ' ' + s.apellido_paterno)}</strong><small class="mono">${esc(s.usuario)}</small></div>
      <button class="icon-btn" data-action="logout" title="Cerrar sesión" aria-label="Cerrar sesión">${icon('logout')}</button></div></aside>
  <main class="main"><header class="topbar"><h1>${esc(titulo)}</h1><span class="chip mono"><span class="dot dot-live"></span>${fechaMx(hoyISO())}</span></header>${contenido}</main>
</div>`;
}
const conSocio = fn => ctx => { const s = socioActual(); if (!s) { flash('error', 'Inicia sesión para continuar.'); return redirect('/'); } return fn(s, ctx); };
const durTxt = v => { if (!v.salida) return '—'; const mi = Math.round((parseISO(v.salida) - parseISO(v.entrada)) / 60000); return `${Math.floor(mi / 60)}h ${pad(mi % 60)}m`; };

route('/portal', conSocio(s => {
  const m = Repo.membresias.actual(s.id), dentro = Repo.asistencias.dentro(s.id), ultima = Repo.asistencias.visitas(s.id, 1)[0], ficha = Repo.pagos.fichaPendiente(s.id);
  const maq = Repo.equipos.listar(), libres = maq.filter(x => x.disponibilidad === 'LIBRE').length;
  const dias = {}; for (let i = 13; i >= 0; i--) dias[isoDate(addDays(hoy(), -i))] = 0;
  Repo.asistencias.visitas(s.id, 60).forEach(v => { const k = v.entrada.slice(0, 10); if (k in dias) dias[k]++; });
  let racha = 0; for (const [k, n] of Object.entries(dias).reverse()) { if (n) racha++; else if (k !== hoyISO()) break; }
  const max = Math.max(1, ...Object.values(dias));
  let alerta = '';
  if (ficha) alerta = `<div class="alert alert-warn">${icon('receipt', 18)}<span>Tienes una ficha de pago en efectivo por <strong>${dinero(ficha.monto)}</strong>. Preséntala en recepción: <a class="link" href="#/portal/ficha">ver ficha ${esc(ficha.referencia_pago)}</a>.</span></div>`;
  else if (!m) alerta = `<div class="alert alert-warn">${icon('alert', 18)}<span>Aún no tienes membresía. <a class="link" href="#/portal/pagos">Elige tu plan y paga con tarjeta o en efectivo</a>; tu código se activa al confirmarse el pago.</span></div>`;
  else if (m.estado === 'vencida') alerta = `<div class="alert alert-bad">${icon('alert', 18)}<span>Tu membresía venció el ${fechaMx(m.fecha_fin)}. <a class="link" href="#/portal/pagos">Renueva aquí</a>.</span></div>`;
  else if (m.por_vencer) alerta = `<div class="alert alert-warn">${icon('clock', 18)}<span>Tu membresía vence en ${m.dias_restantes} día(s). <a class="link" href="#/portal/pagos">Renueva</a> para no perder tu acceso.</span></div>`;
  return portal('Mi acceso', 'inicio', s, `
<div class="grid g-main">
  <section class="card access corners rise">
    <div class="access-top"><div><p class="card-kicker" style="margin-bottom:6px">Credencial digital</p><h2 class="card-title">Muestra este código en recepción</h2></div>${badge(m ? m.estado : 'pendiente', m ? m.estado : 'sin membresía')}</div>
    <div class="access-body">
      <div class="barcode-plate"><span class="laser" aria-hidden="true"></span>${barcodeSVG(s.codigo_credencial, 118, 2)}<div class="code-txt"><span>${esc(s.codigo_credencial)}</span><span>FIT·CODE</span></div></div>
      <div class="access-meta">
        <div><span class="label">Socio</span><strong>${esc(s.nombre + ' ' + s.apellido_paterno)}</strong></div>
        <div><span class="label">Plan</span><strong>${esc(m ? m.plan : 'Sin asignar')}</strong></div>
        <div><span class="label">Vence</span><strong class="mono">${m ? fechaMx(m.fecha_fin) : '—'}</strong></div>
        <div><span class="label">Tipo</span><strong>${s.tipo_socio === 'menor' ? 'Menor de edad' : 'Mayor de edad'}</strong></div>
      </div>
      ${alerta}
      <div class="access-state">${dentro ? `<span class="dot dot-live"></span><span>Estás <strong>dentro del gimnasio</strong> desde las <span class="mono">${horaDe(dentro.entrada)}</span>. Escanea al salir.</span>` : `<span class="dot"></span><span class="muted">Fuera del gimnasio · última visita: <span class="mono">${ultima ? fechaMx(ultima.entrada, true) : 'sin registros'}</span></span>`}</div>
      <div class="row row-between no-print"><p class="hint" style="margin:0">Sube el brillo de tu pantalla para un escaneo más rápido.</p><a class="btn btn-sm" href="#/portal/codigo">${icon('scan', 16)} Pantalla completa</a></div>
    </div>
  </section>
  <div class="grid" style="align-content:start">
    <nav class="quick rise rise-2" aria-label="Opciones del socio">
      <a href="#/portal/asignacion">${icon('id', 22)}<span>Asignación y tipo de membresía<small>Tu plan y catálogo</small></span></a>
      <a href="#/portal/membresia">${icon('card', 22)}<span>Consulta tu membresía<small>${m ? m.dias_restantes + ' días restantes' : 'Sin plan activo'}</small></span></a>
      <a href="#/portal/pagos">${icon('receipt', 22)}<span>Pagos, recibos y cambio de plan<small>Tarjeta o efectivo</small></span></a>
      <a href="#/portal/avance">${icon('chart', 22)}<span>Avance, rutina y nutrición<small>Tu plan semanal</small></span></a>
    </nav>
    <a href="#/portal/maquinas" class="card rise rise-3" style="display:grid;gap:14px">
      <div class="row row-between"><p class="card-kicker" style="margin:0">Máquinas en este momento</p>${icon('arrow', 18)}</div>
      <div class="row" style="align-items:baseline;gap:8px"><strong style="font:500 34px/1 var(--f-display)">${libres}</strong><span class="muted">de ${maq.length} libres</span></div>
      <div class="occupancy"><i style="width:${libres / maq.length * 100}%;background:var(--ok)"></i></div></a>
    <div class="card rise rise-4">
      <div class="row row-between" style="margin-bottom:16px"><p class="card-kicker" style="margin:0">Asistencia · 14 días</p><span class="chip mono">${icon('bolt', 14)} Racha: ${racha} día(s)</span></div>
      <div class="bars" role="img" aria-label="Asistencias de los últimos 14 días">${Object.entries(dias).map(([k, n]) => `<i class="${n ? 'on' : ''}" style="height:${n ? Math.max(18, n / max * 100) : 4}%" title="${fechaMx(k)}: ${n}"></i>`).join('')}</div>
      <div class="bars-x"><span>${fechaMx(Object.keys(dias)[0])}</span><span>hoy</span></div>
    </div>
  </div>
</div>`);
}));
route('/portal/codigo', conSocio(s => `<div class="fullcode"><div class="full">${barcodeSVG(s.codigo_credencial, 160, 3)}<p class="code">${esc(s.codigo_credencial)}</p><p class="name">${esc(s.nombre_completo)}</p><a class="back" href="#/portal">${icon('back', 16)} Volver</a></div></div>`));

route('/portal/membresia', conSocio(s => {
  const m = Repo.membresias.actual(s.id);
  if (!m) return portal('Consulta tu membresía', 'membresia', s, `<div class="card corners rise" style="max-width:640px"><div class="empty">${icon('card', 40)}<h2 class="title">Aún no tienes membresía</h2><p class="muted">Tu cuenta está lista. Elige un plan y paga con tarjeta o en efectivo en recepción.</p><a href="#/portal/pagos" class="btn btn-primary" style="margin-top:12px">Elegir plan ${icon('arrow', 18)}</a></div></div>`);
  const hist = Repo.membresias.historial(s.id), sig = Repo.membresias.siguiente(s.id), vis = Repo.asistencias.visitas(s.id);
  const pago = Repo.pagos.porSocio(s.id).find(p => p.membresia_id === m.id);
  const a30 = Repo.asistencias.contarDesde(s.id, 30), enPeriodo = vis.filter(v => v.entrada >= m.fecha_inicio).length, rec = vis.slice(0, 8);
  const lim = isoDate(addDays(hoy(), -30)), dur = vis.filter(v => v.entrada >= lim && v.salida).map(v => (parseISO(v.salida) - parseISO(v.entrada)) / 60000);
  const prom = dur.length ? Math.round(dur.reduce((a, b) => a + b, 0) / dur.length) : 0;
  const hc = {}; rec.forEach(v => { const h = parseISO(v.entrada).getHours(); hc[h] = (hc[h] || 0) + 1; }); const fav = Object.entries(hc).sort((a, b) => b[1] - a[1])[0];
  const ring = m.estado === 'vencida' ? 'bad' : m.por_vencer ? 'warn' : '';
  return portal('Consulta tu membresía', 'membresia', s, `
<div class="grid g-main">
  <section class="card corners rise">
    <div class="card-head"><div><p class="card-kicker">Membresía <span class="mono">#MEM-${pad(m.id, 6)}</span></p><h2 class="plan-name">${esc(m.plan)}</h2><p class="muted" style="margin:0">${esc(m.descripcion)}</p></div>${badge(m.estado)}</div>
    ${m.estado === 'vencida' ? `<div class="alert alert-bad" style="margin-bottom:20px">${icon('alert', 18)}<span>Tu membresía venció el <strong>${fechaMx(m.fecha_fin)}</strong>. Tu código de acceso no permitirá la entrada hasta renovar.</span></div>` : m.por_vencer ? `<div class="alert alert-warn" style="margin-bottom:20px">${icon('clock', 18)}<span>Quedan <strong>${m.dias_restantes} día(s)</strong>. Renueva antes del ${fechaMx(m.fecha_fin)} para no interrumpir tu acceso.</span></div>` : ''}
    ${sig ? `<div class="alert alert-ok" style="margin-bottom:20px">${icon('check', 18)}<span>Ya tienes pagada tu siguiente membresía <strong>${esc(sig.plan)}</strong>: inicia el ${fechaMx(sig.fecha_inicio)}.</span></div>` : ''}
    <div class="ring-wrap">
      <div class="ring ${ring}" data-pct="${m.porcentaje}" role="img" aria-label="${m.dias_restantes} días restantes"><svg viewBox="0 0 160 160"><circle class="track" cx="80" cy="80" r="70" fill="none" stroke-width="8"/><circle class="bar" cx="80" cy="80" r="70" fill="none" stroke-width="8"/></svg>
        <div class="ring-center"><strong>${m.dias_restantes}</strong><small>días<br>restantes</small></div></div>
      <dl class="dl" style="flex:1;min-width:240px">
        <div><dt>Inicio</dt><dd class="mono">${fechaMx(m.fecha_inicio)}</dd></div><div><dt>Vencimiento</dt><dd class="mono">${fechaMx(m.fecha_fin)}</dd></div>
        <div><dt>Duración</dt><dd>${m.dias_totales} días</dd></div><div><dt>Precio aplicado</dt><dd class="mono">${dinero(m.precio_aplicado)}</dd></div>
        <div><dt>Pagado con</dt><dd>${pago ? METODO_NOMBRE[pago.metodo] + (pago.tarjeta_ultimos4 ? ' ···· ' + pago.tarjeta_ultimos4 : '') : '—'}</dd></div><div><dt>Código de acceso</dt><dd class="mono">${esc(s.codigo_credencial)}</dd></div>
      </dl>
    </div>
    <div class="divider" style="margin:26px 0 18px">Incluye</div>
    <ul class="benefits">${m.beneficios.map(b => `<li>${icon('check', 16)}${esc(b)}</li>`).join('')}</ul>
    <div class="actions no-print" style="margin-top:24px"><a href="#/portal/pagos" class="btn btn-primary">${icon('refresh', 18)} Renovar o cambiar plan</a><button type="button" class="btn btn-ghost" data-action="print">${icon('print', 18)} Imprimir comprobante</button></div>
  </section>
  <div class="grid" style="align-content:start">
    <div class="grid g-2">
      <div class="card kpi rise rise-2"><span class="label">Visitas · 30 días</span><strong>${a30}</strong><span class="trend">≈ ${(a30 / 4.3).toFixed(1)} por semana</span></div>
      <div class="card kpi rise rise-2"><span class="label">En este periodo</span><strong>${enPeriodo}</strong><span class="trend">desde ${fechaMx(m.fecha_inicio)}</span></div>
      <div class="card kpi rise rise-3"><span class="label">Sesión promedio</span><strong>${prom}<small>min</small></strong><span class="trend">últimos 30 días</span></div>
      <div class="card kpi rise rise-3"><span class="label">Hora favorita</span><strong>${fav ? pad(fav[0]) + ':00' : '—'}</strong><span class="trend">según tus entradas</span></div>
    </div>
    <div class="card rise rise-4"><p class="card-kicker">Historial de membresías</p>
      <ul class="timeline">${hist.map(h => `<li class="${h.id === m.id ? 'now' : ''}"><div class="row row-between"><strong>${esc(h.plan)}</strong>${badge(h.estado)}</div><span class="hint mono">${fechaMx(h.fecha_inicio)} → ${fechaMx(h.fecha_fin)}</span></li>`).join('')}</ul></div>
  </div>
  <section class="card rise rise-4" style="grid-column:1/-1"><div class="card-head"><div><p class="card-kicker">Registro de asistencia</p><h3 class="card-title">Entradas y salidas recientes</h3></div></div>
    ${rec.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>Fecha</th><th>Entrada</th><th>Salida</th><th class="num">Duración</th></tr></thead><tbody>
      ${rec.map(v => `<tr><td>${fechaMx(v.entrada)}</td><td class="mono">${horaDe(v.entrada)}</td><td class="mono">${v.salida ? horaDe(v.salida) : '<span class="badge badge-ok">DENTRO</span>'}</td><td class="num">${durTxt(v)}</td></tr>`).join('')}</tbody></table></div>` : `<div class="empty">${icon('clock', 32)}Aún no tienes visitas registradas.</div>`}
  </section>
</div>`);
}));

route('/portal/asignacion', conSocio(s => {
  const m = Repo.membresias.actual(s.id), pago = m ? Repo.pagos.porSocio(s.id).find(p => p.membresia_id === m.id) : null;
  return portal('Asignación y tipo de membresía', 'asignacion', s, `
<div class="grid g-3" style="margin-bottom:18px">
  <div class="card kpi rise"><span class="label">Tipo de socio</span><strong style="font-size:22px">${s.tipo_socio === 'menor' ? 'Menor de edad' : 'Mayor de edad'}</strong><span class="trend">${s.tipo_socio === 'menor' ? 'Tutor: ' + esc(s.tutor_nombre) : 'Titular de la cuenta'}</span></div>
  <div class="card kpi rise rise-2"><span class="label">Membresía asignada</span><strong style="font-size:22px">${esc(m ? m.plan : 'Sin asignar')}</strong><span class="trend">${m ? 'Desde ' + fechaMx(m.fecha_inicio) : 'Elige un plan'}</span></div>
  <div class="card kpi rise rise-3"><span class="label">Asignada mediante</span><strong style="font-size:22px">${pago ? METODO_NOMBRE[pago.metodo] : '—'}</strong><span class="trend">${pago ? (pago.cajero ? 'Cobró: ' + esc(pago.cajero.split(' ')[0]) : 'Pago en línea') : 'Pendiente'}</span></div>
</div>
<section class="card rise rise-3"><div class="card-head"><div><p class="card-kicker">Catálogo</p><h2 class="card-title">Tipos de membresía FIT CODE</h2></div></div>
  ${planesHTML(m)}
  <p class="hint" style="margin-top:18px">La membresía se asigna automáticamente cuando se confirma tu pago (tarjeta en línea o efectivo cobrado en recepción).</p></section>`);
}));
function planesHTML(m, conBoton = false) {
  return `<div class="plans">${Repo.planes.listar().map(p => `<article class="plan${m && m.tipo_membresia_id === p.id && m.estado === 'activa' ? ' current' : ''}"><h4>${esc(p.nombre)}</h4>
    <div class="price">$${p.precio.toLocaleString('en-US')} <small>/ ${p.duracion_dias === 1 ? 'día' : p.duracion_dias + ' días'}</small></div><p class="hint" style="margin:0">${esc(p.descripcion)}</p>
    <ul>${p.beneficios.map(b => `<li>${esc(b)}</li>`).join('')}</ul>
    ${conBoton ? `<a class="btn btn-sm ${m && m.tipo_membresia_id === p.id ? '' : 'btn-primary'}" style="margin-top:auto" href="#/portal/pagar?plan=${p.id}">${m && m.tipo_membresia_id === p.id && m.estado === 'activa' ? 'Renovar' : m && m.estado === 'activa' ? 'Cambiar a este plan' : 'Contratar'}</a>` : ''}</article>`).join('')}</div>`;
}

route('/portal/pagos', conSocio(s => {
  const pagos = Repo.pagos.porSocio(s.id), m = Repo.membresias.actual(s.id), ficha = Repo.pagos.fichaPendiente(s.id);
  const pagados = pagos.filter(p => p.estado === 'pagado'), total = pagados.reduce((a, p) => a + p.monto, 0);
  return portal('Pagos, recibos y cambio de plan', 'pagos', s, `
${ficha ? `<div class="alert alert-warn rise" style="margin-bottom:18px">${icon('receipt', 18)}<span style="flex:1">Ficha de pago en efectivo <strong class="mono">${esc(ficha.referencia_pago)}</strong> por <strong>${dinero(ficha.monto)}</strong> (${esc(ficha.plan)}). Vence el ${fechaMx(ficha.expira_en, true)}.</span><a class="btn btn-sm" href="#/portal/ficha">Ver ficha</a></div>` : ''}
<div class="grid g-3" style="margin-bottom:18px">
  <div class="card kpi rise"><span class="label">Pagos confirmados</span><strong>${pagados.length}</strong><span class="trend">desde tu ingreso</span></div>
  <div class="card kpi rise rise-2"><span class="label">Total invertido</span><strong class="mono" style="font-size:24px">${dinero(total)}</strong><span class="trend">en tu entrenamiento</span></div>
  <div class="card kpi rise rise-3"><span class="label">Próximo pago</span><strong class="mono" style="font-size:24px">${m ? fechaMx(m.fecha_fin) : 'Hoy'}</strong><span class="trend">${m ? dinero(m.precio) + ' · ' + esc(m.plan) : 'Elige tu plan'}</span></div>
</div>
<section class="card rise rise-2" style="margin-bottom:18px"><div class="card-head"><div><p class="card-kicker">Pagar o cambiar de plan</p><h2 class="card-title">Elige un plan · paga con tarjeta o en efectivo</h2></div></div>
  ${planesHTML(m, true)}
  <p class="hint" style="margin-top:14px">${m && m.estado === 'activa' ? `Si ya tienes una membresía activa, el plan nuevo empieza al terminar la actual (${fechaMx(m.fecha_fin)}).` : 'Tu membresía se activa en cuanto se confirma el pago.'}</p></section>
<section class="card rise rise-3"><div class="card-head"><div><p class="card-kicker">Historial</p><h2 class="card-title">Pagos y recibos</h2></div></div>
  ${pagos.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>Folio</th><th>Concepto</th><th>Fecha</th><th>Método</th><th>Estado</th><th class="num">Monto</th><th></th></tr></thead><tbody>
    ${pagos.map(p => `<tr><td class="mono">${esc(p.folio)}</td><td>${esc(p.concepto)}</td><td class="mono">${fechaMx(p.pagado_en || p.creado_en)}</td><td>${METODO_NOMBRE[p.metodo] || p.metodo}${p.tarjeta_ultimos4 ? ' ···· ' + p.tarjeta_ultimos4 : ''}</td><td>${badge(p.estado)}</td><td class="num">${dinero(p.monto)}</td>
      <td>${p.estado === 'pagado' ? `<a class="btn btn-sm btn-ghost" href="#/portal/recibo/${p.folio}">${icon('file', 16)} Recibo</a>` : p.estado === 'pendiente' ? `<a class="btn btn-sm btn-ghost" href="#/portal/ficha">Ficha</a>` : ''}</td></tr>`).join('')}
  </tbody></table></div>` : `<div class="empty">${icon('receipt', 32)}Aún no tienes pagos registrados.</div>`}</section>`);
}));

let pagoErr = null;
const marcaTarjeta = n => /^4/.test(n) ? 'VISA' : /^(5[1-5]|2[2-7])/.test(n) ? 'MASTERCARD' : /^3[47]/.test(n) ? 'AMEX' : null;
route('/portal/pagar', conSocio((s, { query }) => {
  const p = Repo.planes.porId(query.plan); if (!p) return redirect('/portal/pagos');
  const m = Repo.membresias.actual(s.id), err = pagoErr; pagoErr = null;
  const ini = m && m.estado === 'activa' ? addDays(parseISO(m.fecha_fin), 1) : hoy(), fin = addDays(ini, p.duracion_dias - 1);
  const tipo = !m || m.estado !== 'activa' ? (m ? 'Renovación' : 'Nueva membresía') : m.tipo_membresia_id === p.id ? 'Renovación anticipada' : 'Cambio de plan';
  const metodo = query.metodo === 'efectivo' ? 'efectivo' : 'tarjeta';
  after(root => {
    const num = $('#cc-num', root), exp = $('#cc-exp', root), cvv = $('#cc-cvv', root), brand = $('#cc-brand', root);
    if (!num) return;
    num.addEventListener('input', () => { const d = num.value.replace(/\D/g, '').slice(0, 16); num.value = d.replace(/(.{4})/g, '$1 ').trim(); const b = marcaTarjeta(d); brand.textContent = b || 'TARJETA'; brand.classList.toggle('on', !!b); cvv.maxLength = b === 'AMEX' ? 4 : 3; });
    exp.addEventListener('input', () => { let d = exp.value.replace(/\D/g, '').slice(0, 4); if (d.length > 2) d = d.slice(0, 2) + '/' + d.slice(2); exp.value = d; });
    cvv.addEventListener('input', () => { cvv.value = cvv.value.replace(/\D/g, ''); });
  });
  return portal('Pagar membresía', 'pagos', s, `
<a href="#/portal/pagos" class="btn btn-ghost btn-sm" style="margin-bottom:18px">${icon('back', 16)} Volver a planes</a>
<div class="grid g-main">
  <section class="card rise">
    <p class="card-kicker">Método de pago</p>
    <div class="paytabs" role="tablist">
      <a href="#/portal/pagar?plan=${p.id}&metodo=tarjeta" class="${metodo === 'tarjeta' ? 'on' : ''}">${icon('card', 20)}<span><strong>Tarjeta</strong><small>Débito o crédito · se activa al instante</small></span></a>
      <a href="#/portal/pagar?plan=${p.id}&metodo=efectivo" class="${metodo === 'efectivo' ? 'on' : ''}">${icon('receipt', 20)}<span><strong>Efectivo</strong><small>Paga en recepción con tu ficha</small></span></a>
    </div>
    ${err ? `<div class="alert alert-bad" role="alert" style="margin:18px 0 0">${icon('alert', 18)}<span>${esc(err)}</span></div>` : ''}
    ${metodo === 'tarjeta' ? `
    <form class="form" data-form="pagoTarjeta" style="margin-top:20px" novalidate autocomplete="off">
      <input type="hidden" name="plan" value="${p.id}">
      <div class="field"><label for="cc-name">Nombre del titular</label><input class="input upper" id="cc-name" name="titular" placeholder="COMO APARECE EN LA TARJETA"></div>
      <div class="field"><label for="cc-num">Número de tarjeta</label><div class="input-wrap">${icon('card', 18)}<input class="input mono" id="cc-num" name="numero" inputmode="numeric" placeholder="0000 0000 0000 0000" maxlength="19"><span class="cc-brand mono" id="cc-brand">TARJETA</span></div></div>
      <div class="form-grid"><div class="field col-6"><label for="cc-exp">Vencimiento</label><input class="input mono" id="cc-exp" name="exp" inputmode="numeric" placeholder="MM/AA" maxlength="5"></div>
        <div class="field col-6"><label for="cc-cvv">CVV</label><input class="input mono" id="cc-cvv" name="cvv" inputmode="numeric" placeholder="123" maxlength="3" type="password"></div></div>
      <button class="btn btn-primary btn-block" type="submit">${icon('lock', 18)} Pagar ${dinero(p.precio)}</button>
      <div class="alert" style="font-size:13px">${icon('shield', 18)}<span class="muted">Pago simulado (prototipo). En producción los datos de la tarjeta se envían cifrados directo a Mercado Pago y <strong>nunca</strong> se guardan en FIT CODE; solo se guarda la marca y los últimos 4 dígitos.<br>Prueba: <span class="mono">4242 4242 4242 4242</span> aprobada · <span class="mono">4000 0000 0000 0002</span> rechazada.</span></div>
    </form>` : `
    <form class="form" data-form="pagoEfectivo" style="margin-top:20px"><input type="hidden" name="plan" value="${p.id}">
      <ol class="steps-list"><li>Genera tu ficha con una referencia única.</li><li>Preséntala en recepción (impresa o en tu celular) dentro de las próximas <strong>72 horas</strong>.</li><li>Recepción escanea la referencia, recibe el efectivo y tu membresía se activa al momento.</li></ol>
      <button class="btn btn-primary btn-block" type="submit">${icon('receipt', 18)} Generar ficha de pago</button>
      <p class="hint" style="margin:0">Si ya tenías una ficha pendiente, se reemplaza por esta.</p>
    </form>`}
  </section>
  <aside class="card corners rise rise-2" style="align-self:start">
    <p class="card-kicker">Resumen</p><h2 class="plan-name" style="font-size:34px">${esc(p.nombre)}</h2><p class="muted" style="margin:0 0 18px">${esc(p.descripcion)}</p>
    <div class="r-row"><span class="muted">Operación</span><span>${tipo}</span></div>
    <div class="r-row"><span class="muted">Vigencia</span><span class="mono">${fechaMx(isoDate(ini))} → ${fechaMx(isoDate(fin))}</span></div>
    <div class="r-row"><span class="muted">Duración</span><span>${p.duracion_dias} día(s)</span></div>
    <div class="row row-between" style="margin-top:20px"><span class="label">Total</span><span class="r-total">${dinero(p.precio)}</span></div>
    ${tipo === 'Cambio de plan' ? `<p class="hint" style="margin-top:14px">Tu plan actual (${esc(m.plan)}) sigue vigente hasta el ${fechaMx(m.fecha_fin)}; el nuevo empieza al día siguiente.</p>` : ''}
  </aside>
</div>
<div class="processing hidden" id="processing"><div class="card corners"><div class="spinner"></div><p>Procesando con el banco…</p></div></div>`);
}));
FORMS.pagoTarjeta = (d, form) => {
  const s = socioActual(), n = (d.numero || '').replace(/\D/g, ''), marca = marcaTarjeta(n);
  const [mm, aa] = (d.exp || '').split('/').map(Number), venc = new Date(2000 + aa, mm, 0);
  let e = null;
  if (mayus(d.titular).length < 5) e = 'Escribe el nombre del titular como aparece en la tarjeta.';
  else if (!marca || n.length < 15 || luhnValido(n) === false) e = 'El número de tarjeta no es válido.';
  else if (!mm || mm > 12 || !aa || venc < hoy()) e = 'La fecha de vencimiento no es válida o la tarjeta ya venció.';
  else if (!/^\d{3,4}$/.test(d.cvv || '') || (marca === 'AMEX' ? d.cvv.length !== 4 : d.cvv.length !== 3)) e = 'El CVV no es válido.';
  if (e) { pagoErr = e; return render(); }
  $('#processing').classList.remove('hidden'); form.querySelector('[type=submit]').disabled = true;
  setTimeout(() => {
    const r = Repo.pagos.pagarTarjetaEnLinea(s.id, +d.plan, { marca, ultimos4: n.slice(-4), aprobada: n !== '4000000000000002' });
    if (!r.ok) { pagoErr = r.error; return render(); }
    flash('ok', `Pago aprobado. Tu membresía ${r.pago.plan} quedó activa.`); go('/portal/recibo/' + r.pago.folio);
  }, 1400);
};
const luhnValido = n => { let s = 0; [...n].reverse().forEach((c, i) => { let x = +c; if (i % 2) { x *= 2; if (x > 9) x -= 9; } s += x; }); return s % 10 === 0; };
FORMS.pagoEfectivo = d => { const s = socioActual(); Repo.pagos.crearFichaEfectivo(s.id, +d.plan); flash('ok', 'Ficha generada. Preséntala en recepción para activar tu membresía.'); go('/portal/ficha'); };
ACTIONS.cancelarFicha = a => { if (confirm('¿Cancelar esta ficha de pago?')) { Repo.pagos.cancelarFicha(socioActual().id, a.dataset.id); flash('ok', 'Ficha cancelada.'); go('/portal/pagos'); } };

route('/portal/ficha', conSocio(s => {
  const f = Repo.pagos.fichaPendiente(s.id);
  if (!f) return portal('Ficha de pago', 'pagos', s, `<div class="card empty rise">${icon('receipt', 32)}No tienes fichas pendientes.<br><a class="btn btn-primary" style="margin-top:14px" href="#/portal/pagos">Ir a pagos</a></div>`);
  return portal('Ficha de pago en efectivo', 'pagos', s, `
<section class="card corners receipt rise">
  <div class="row row-between" style="margin-bottom:20px">${logo()}<span class="mono dim">FICHA DE PAGO</span></div>
  <p class="card-kicker">Referencia</p><h2 class="title mono" style="letter-spacing:.12em">${esc(f.referencia_pago)}</h2>
  <div style="background:#f4f6f2;padding:14px;border-radius:10px;margin:8px 0 18px">${barcodeSVG(f.referencia_pago, 70, 1.8)}</div>
  <div class="r-row"><span class="muted">Socio</span><span>${esc(s.nombre_completo)}</span></div>
  <div class="r-row"><span class="muted">Concepto</span><span>${esc(f.concepto)}</span></div>
  <div class="r-row"><span class="muted">Generada</span><span class="mono">${fechaMx(f.creado_en, true)}</span></div>
  <div class="r-row"><span class="muted">Vence</span><span class="mono" style="color:var(--warn)">${fechaMx(f.expira_en, true)}</span></div>
  <div class="row row-between" style="margin-top:22px"><span class="label">Total a pagar en recepción</span><span class="r-total">${dinero(f.monto)}</span></div>
  <div class="alert" style="margin-top:20px">${icon('alert', 18)}<span class="muted">Tu membresía se activa en cuanto recepción registre el pago. Si la ficha vence, genera una nueva.</span></div>
  <div class="actions no-print"><button class="btn btn-ghost btn-danger" data-action="cancelarFicha" data-id="${f.id}">Cancelar ficha</button><button class="btn btn-primary" data-action="print">${icon('print', 18)} Imprimir</button></div>
</section>`);
}));

route('/portal/recibo/:folio', conSocio((s, { params }) => {
  const r = Repo.pagos.recibo(s.id, params[0]);
  if (!r) return redirect('/portal/pagos');
  return portal('Recibo de pago', 'pagos', s, reciboHTML(r, s, '#/portal/pagos'));
}));
function reciboHTML(r, s, volver) {
  return `<section class="card corners receipt rise">
  <div class="row row-between" style="margin-bottom:20px">${logo()}<span class="mono dim">RECIBO</span></div>
  <p class="card-kicker">Folio</p><h2 class="title mono">${esc(r.folio)}</h2>
  <div class="r-row"><span class="muted">Socio</span><span>${esc(r.socio)}</span></div>
  <div class="r-row"><span class="muted">Usuario</span><span class="mono">${esc(r.socio_usuario)}</span></div>
  <div class="r-row"><span class="muted">Concepto</span><span>${esc(r.concepto)}</span></div>
  ${r.fecha_inicio ? `<div class="r-row"><span class="muted">Vigencia</span><span class="mono">${fechaMx(r.fecha_inicio)} → ${fechaMx(r.fecha_fin)}</span></div>` : ''}
  <div class="r-row"><span class="muted">Fecha de pago</span><span class="mono">${fechaMx(r.pagado_en, true)}</span></div>
  <div class="r-row"><span class="muted">Método</span><span>${METODO_NOMBRE[r.metodo] || r.metodo}${r.tarjeta_ultimos4 ? ` · ${r.tarjeta_marca} ···· ${r.tarjeta_ultimos4}` : ''}</span></div>
  ${r.referencia_pago ? `<div class="r-row"><span class="muted">Ficha</span><span class="mono">${esc(r.referencia_pago)}</span></div>` : ''}
  <div class="r-row"><span class="muted">Atendió</span><span>${esc(r.cajero || 'Pago en línea')}</span></div>
  <div class="row row-between" style="margin-top:22px"><span class="label">Total pagado</span><span class="r-total">${dinero(r.monto)}</span></div>
  <div style="margin-top:26px;background:#f4f6f2;padding:12px;border-radius:10px">${barcodeSVG(r.folio, 48, 1.4)}</div>
  <div class="actions no-print"><a class="btn btn-ghost" href="${volver}">${icon('back', 18)} Volver</a><button class="btn btn-primary" data-action="print">${icon('print', 18)} Imprimir / PDF</button></div>
</section>`;
}

function lineaSVG(series, fechas) {
  const W = 600, H = 170, P = 26, todos = series.flatMap(s => s.v.filter(x => x != null));
  if (fechas.length < 2 || !todos.length) return '<p class="hint">Registra al menos dos mediciones para ver tu gráfica.</p>';
  return `<svg viewBox="0 0 ${W} ${H}" class="linechart" role="img" aria-label="Evolución de mediciones">${series.map(s => {
    const vals = s.v.filter(x => x != null); if (vals.length < 2) return '';
    const mn = Math.min(...vals), mx = Math.max(...vals), r = mx - mn || 1;
    const pts = s.v.map((v, i) => v == null ? null : [P + i * (W - 2 * P) / (fechas.length - 1), H - P - (v - mn) / r * (H - 2 * P)]).filter(Boolean);
    return `<polyline fill="none" stroke="${s.c}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" points="${pts.map(p => p.join(',')).join(' ')}"/>${pts.map(p => `<circle cx="${p[0]}" cy="${p[1]}" r="3.5" fill="${s.c}"/>`).join('')}`;
  }).join('')}</svg><div class="legend">${series.map(s => `<span><i style="background:${s.c}"></i>${s.n}</span>`).join('')}</div>`;
}
function datosFitness(s) {
  const exp = Repo.expedientes.obtener(s.id), meds = Repo.mediciones.porSocio(s.id), u = meds[meds.length - 1];
  if (!exp || !exp.objetivo_principal || !u) return null;
  return { exp, meds, u, objetivo: exp.objetivo_principal, nivel: exp.nivel, dias: exp.dias_entrenamiento, edad: s.edad, sexo: s.sexo, peso: u.peso_kg, estatura: u.estatura_cm };
}
function formMedicion(u, formName, extraHidden = '') {
  return `<form class="form" data-form="${formName}" novalidate>${extraHidden}
    <div class="form-grid">
      <div class="field col-6"><label for="m-peso">Peso (kg) <span class="req">*</span></label><input class="input mono" id="m-peso" name="peso" inputmode="decimal" value="${u ? u.peso_kg : ''}" data-imc></div>
      <div class="field col-6"><label for="m-est">Estatura (cm) <span class="req">*</span></label><input class="input mono" id="m-est" name="estatura" inputmode="decimal" value="${u ? u.estatura_cm : ''}" data-imc></div>
      <div class="field col-6"><label for="m-gr">% de grasa</label><input class="input mono" id="m-gr" name="grasa" inputmode="decimal" placeholder="Opcional" value=""></div>
      <div class="field col-6"><label for="m-mu">% muscular</label><input class="input mono" id="m-mu" name="musculo" inputmode="decimal" placeholder="Opcional" value=""></div>
    </div>
    <div class="imc-live"><span class="label">IMC calculado</span><strong class="mono" data-imc-out>—</strong><span class="hint" data-imc-cat></span></div>
    <button class="btn btn-primary btn-block" type="submit">${icon('check', 18)} Guardar medición</button></form>`;
}
function initIMC(root, edad) {
  const p = $('#m-peso', root), e = $('#m-est', root); if (!p) return;
  const run = () => { const v = imc(parseFloat(p.value), parseFloat(e.value)); const c = categoriaIMC(v, edad); $('[data-imc-out]', root).textContent = v && isFinite(v) ? v : '—'; $('[data-imc-cat]', root).textContent = v && isFinite(v) ? c.txt : ''; };
  p.addEventListener('input', run); e.addEventListener('input', run); run();
}
function validarMedicion(d) {
  const peso = parseFloat(d.peso), est = parseFloat(d.estatura), g = d.grasa === '' ? '' : parseFloat(d.grasa), mu = d.musculo === '' ? '' : parseFloat(d.musculo);
  if (!(peso >= 25 && peso <= 300)) return 'El peso debe estar entre 25 y 300 kg.';
  if (!(est >= 100 && est <= 230)) return 'La estatura debe estar entre 100 y 230 cm.';
  if (g !== '' && !(g >= 3 && g <= 70)) return 'El % de grasa debe estar entre 3 y 70.';
  if (mu !== '' && !(mu >= 10 && mu <= 70)) return 'El % muscular debe estar entre 10 y 70.';
  return null;
}
function semanaHTML(plan) {
  return `<div class="week">${plan.semanaCompleta.map(d => `<article class="day${d.descanso ? ' rest' : ''}">
    <header><span class="mono dim">${d.dia.slice(0, 3).toUpperCase()}</span><strong>${esc(d.enfoque)}</strong>${d.minutos ? `<span class="chip mono">${d.minutos} min</span>` : ''}</header>
    ${d.descanso ? `<p class="hint" style="margin:0">${esc(d.nota)}</p>` : `<ul class="exlist">${d.ejercicios.map(e => `<li><span>${esc(e.nombre)}</span><span class="mono">${e.series}×${esc(e.reps)}<small>${e.descanso}s</small></span></li>`).join('')}</ul><p class="hint cardio">${icon('bolt', 14)} ${esc(d.cardio)}</p>`}
  </article>`).join('')}</div>`;
}
function nutricionHTML(n, objetivo) {
  if (n.menor) return `<div class="alert alert-warn">${icon('alert', 18)}<span>Para menores de 18 años no generamos metas de calorías: su alimentación debe indicarla su pediatra o un nutriólogo. Guía general: plato del bien comer (½ verduras y frutas, ¼ cereales integrales, ¼ proteína), agua simple y 3 comidas + 2 colaciones.</span></div>`;
  const tot = n.prot * 4 + n.grasa * 9 + n.carb * 4;
  const NOM = { cereal: 'Cereales', proteina: 'Proteína (AOA)', leguminosa: 'Leguminosas', verdura: 'Verduras', fruta: 'Frutas', leche: 'Lácteos', grasa: 'Grasas' };
  return `<div class="alert alert-warn" style="margin-bottom:18px">${icon('alert', 18)}<span><strong>Plan SUGERIDO, no es una prescripción médica.</strong> Se calcula con fórmulas generales (Mifflin-St Jeor y equivalentes SMAE). Si tienes una enfermedad crónica, estás embarazada o tomas medicamentos, valídalo con un nutriólogo.</span></div>
  <div class="grid g-4" style="margin-bottom:18px">
    <div class="card kpi"><span class="label">Meta diaria</span><strong>${n.kcal.toLocaleString('en-US')}<small>kcal</small></strong><span class="trend">gasto estimado ${n.gasto.toLocaleString('en-US')} kcal</span></div>
    <div class="card kpi"><span class="label">Proteína</span><strong>${n.prot}<small>g</small></strong><span class="trend">${Math.round(n.prot * 4 / tot * 100)}% de la energía</span></div>
    <div class="card kpi"><span class="label">Carbohidratos</span><strong>${n.carb}<small>g</small></strong><span class="trend">${Math.round(n.carb * 4 / tot * 100)}% de la energía</span></div>
    <div class="card kpi"><span class="label">Grasas</span><strong>${n.grasa}<small>g</small></strong><span class="trend">${Math.round(n.grasa * 9 / tot * 100)}% de la energía</span></div>
  </div>
  ${n.limitado ? `<p class="hint">Se aplicó un mínimo seguro de calorías para no bajar de tu metabolismo basal.</p>` : ''}
  <div class="grid g-main">
    <section class="card"><p class="card-kicker">Distribución por comida (equivalentes)</p>
      ${n.comidas.map(c => `<div class="meal"><div class="row row-between"><strong>${c.nombre}</strong><span class="mono dim">${c.hora} · ≈${c.kcal} kcal</span></div>
        <div class="eqs">${Object.entries(c.eq).map(([g, x]) => `<span class="eq">${x} ${NOM[g]}</span>`).join('')}</div><p class="hint" style="margin:6px 0 0">Ejemplo: ${esc(c.ejemplo)}</p></div>`).join('')}
    </section>
    <div class="grid" style="align-content:start">
      <section class="card"><p class="card-kicker">¿Qué es 1 equivalente?</p><dl class="dl" style="grid-template-columns:1fr">${Object.entries(EJEMPLOS).map(([g, t]) => `<div><dt>${NOM[g]} · ${n.eqDia[g]} al día</dt><dd style="font-weight:400;font-size:13.5px">${esc(t)}</dd></div>`).join('')}</dl></section>
      <section class="card"><p class="card-kicker">Para tu objetivo</p><ul class="benefits">${n.tips.map(t => `<li>${icon('check', 16)}${esc(t)}</li>`).join('')}<li>${icon('check', 16)}Agua: ≈ ${n.agua} L al día.</li></ul></section>
    </div>
  </div>`;
}
function onboardingHTML(exp, u, formName, extraHidden = '', titulo = 'Configura tu plan') {
  const sel = exp?.objetivo_principal;
  return `<section class="card corners rise"><p class="card-kicker">${titulo}</p><h2 class="title" style="font-size:24px">¿Cuál es tu objetivo?</h2>
  <p class="lead">Con tu objetivo, edad, peso y estatura generamos tu rutina semanal y un plan nutricional sugerido. Puedes cambiarlo cuando quieras.</p>
  <form class="form" data-form="${formName}" novalidate>${extraHidden}
    <div class="goals">${Object.entries(OBJETIVOS).map(([k, o]) => `<label class="goal"><input type="radio" name="objetivo" value="${k}"${k === sel ? ' checked' : ''}><span>${icon(o.icono, 22)}<strong>${o.nombre}</strong><small>${o.desc}</small></span></label>`).join('')}</div>
    <div class="form-grid">
      <div class="field col-6"><label for="o-nivel">Nivel de experiencia</label><select class="input" id="o-nivel" name="nivel">${Object.entries(NIVELES).map(([k, n]) => `<option value="${k}"${k === (exp?.nivel || 'principiante') ? ' selected' : ''}>${n}</option>`).join('')}</select></div>
      <div class="field col-6"><label for="o-dias">Días por semana para entrenar</label><select class="input" id="o-dias" name="dias">${[3, 4, 5, 6].map(n => `<option${n === (exp?.dias_entrenamiento || 3) ? ' selected' : ''}>${n}</option>`).join('')}</select></div>
      <div class="field col-6"><label for="m-peso">Peso actual (kg)</label><input class="input mono" id="m-peso" name="peso" inputmode="decimal" value="${u ? u.peso_kg : ''}" data-imc></div>
      <div class="field col-6"><label for="m-est">Estatura (cm)</label><input class="input mono" id="m-est" name="estatura" inputmode="decimal" value="${u ? u.estatura_cm : ''}" data-imc></div>
      ${u ? '' : `<div class="field col-6"><label for="m-gr">% de grasa (opcional)</label><input class="input mono" id="m-gr" name="grasa" inputmode="decimal"></div><div class="field col-6"><label for="m-mu">% muscular (opcional)</label><input class="input mono" id="m-mu" name="musculo" inputmode="decimal"></div>`}
    </div>
    <div class="imc-live"><span class="label">IMC calculado</span><strong class="mono" data-imc-out>—</strong><span class="hint" data-imc-cat></span></div>
    <button class="btn btn-primary btn-block" type="submit">${icon('bolt', 18)} Generar mi plan</button>
  </form></section>`;
}
function guardarPerfil(socioId, d, usuarioId) {
  if (!d.objetivo) return 'Elige un objetivo.';
  const e = validarMedicion({ peso: d.peso, estatura: d.estatura, grasa: d.grasa ?? '', musculo: d.musculo ?? '' }); if (e) return e;
  Repo.expedientes.guardar(socioId, d, usuarioId);
  const u = Repo.mediciones.porSocio(socioId).pop();
  if (!u || u.peso_kg !== +d.peso || u.estatura_cm !== +d.estatura || d.grasa || d.musculo) Repo.mediciones.registrar(socioId, { peso: d.peso, estatura: d.estatura, grasa: d.grasa ?? (u?.porcentaje_grasa ?? ''), musculo: d.musculo ?? (u?.porcentaje_musculo ?? '') }, usuarioId);
  return null;
}
function progresoHTML(F, edad, formName, extra = '') {
  const { meds, u } = F, p0 = meds[0], c = categoriaIMC(u.imc, edad);
  const delta = (k, un) => { const a = meds.filter(m => m[k] != null); if (a.length < 2) return '<span class="trend">Sin comparación</span>'; const d = Math.round((a[a.length - 1][k] - a[0][k]) * 10) / 10; const bueno = k === 'porcentaje_musculo' ? d >= 0 : d <= 0; return `<span class="trend" style="color:${bueno ? 'var(--ok)' : 'var(--warn)'}">${d > 0 ? '▲ +' : '▼ '}${d}${un} desde ${fechaMx(a[0].fecha_medicion)}</span>`; };
  const ult = k => [...meds].reverse().find(m => m[k] != null)?.[k];
  return `<div class="grid g-4" style="margin-bottom:18px">
    <div class="card kpi"><span class="label">Peso</span><strong>${u.peso_kg}<small>kg</small></strong>${delta('peso_kg', ' kg')}</div>
    <div class="card kpi"><span class="label">IMC</span><strong>${u.imc}</strong><span class="trend"><span class="badge badge-${c.cls}">${esc(c.txt)}</span></span></div>
    <div class="card kpi"><span class="label">% grasa</span><strong>${ult('porcentaje_grasa') ?? '—'}<small>%</small></strong>${delta('porcentaje_grasa', '%')}</div>
    <div class="card kpi"><span class="label">% muscular</span><strong>${ult('porcentaje_musculo') ?? '—'}<small>%</small></strong>${delta('porcentaje_musculo', '%')}</div>
  </div>
  <div class="grid g-main">
    <section class="card"><p class="card-kicker">Evolución</p>${lineaSVG([{ n: 'Peso', c: '#c8ff2e', v: meds.map(m => m.peso_kg) }, { n: '% grasa', c: '#ffb547', v: meds.map(m => m.porcentaje_grasa) }, { n: '% muscular', c: '#3fe0a1', v: meds.map(m => m.porcentaje_musculo) }], meds.map(m => m.fecha_medicion))}
      <div class="table-wrap" style="margin-top:14px"><table class="t"><thead><tr><th>Fecha</th><th class="num">Peso</th><th class="num">IMC</th><th class="num">Grasa</th><th class="num">Músculo</th><th>Registró</th></tr></thead><tbody>
      ${[...meds].reverse().map(m => `<tr><td>${fechaMx(m.fecha_medicion)}</td><td class="num">${m.peso_kg} kg</td><td class="num">${m.imc}</td><td class="num">${m.porcentaje_grasa ?? '—'}${m.porcentaje_grasa != null ? '%' : ''}</td><td class="num">${m.porcentaje_musculo ?? '—'}${m.porcentaje_musculo != null ? '%' : ''}</td><td class="hint">${m.registrado_por ? esc(Repo.personal.porUsuario(m.registrado_por)?.nombre_corto || 'Coach') : 'Tú'}</td></tr>`).join('')}</tbody></table></div></section>
    <section class="card" style="align-self:start"><p class="card-kicker">Registrar cambios</p><h3 class="card-title" style="margin-bottom:14px">Nueva medición</h3>${formMedicion(u, formName, extra)}
      <p class="hint" style="margin-bottom:0">El IMC se recalcula automáticamente con peso y estatura.</p></section>
  </div>`;
}

route('/portal/avance', conSocio((s, { query }) => {
  const F = datosFitness(s);
  after(root => initIMC(root, s.edad));
  if (!F || query.tab === 'objetivo') return portal('Avance, rutina y nutrición', 'avance', s, (F ? tabsAvance('objetivo') : '') + onboardingHTML(F?.exp || Repo.expedientes.obtener(s.id), F?.u, 'perfilSocio', '', F ? 'Ajustar objetivo' : 'Primer paso'));
  const tab = ['resumen', 'rutina', 'nutricion'].includes(query.tab) ? query.tab : 'resumen';
  const plan = generarPlan(F), asignada = Repo.rutinas.asignada(s.id), o = OBJETIVOS[F.objetivo];
  let html = '';
  if (tab === 'resumen') html = `<div class="goalbar card rise">${icon(o.icono, 24)}<div><span class="label">Objetivo</span><strong>${o.nombre}</strong></div><div><span class="label">Nivel</span><strong>${NIVELES[F.nivel]}</strong></div><div><span class="label">Entrena</span><strong>${F.dias} días/sem</strong></div><div><span class="label">Edad</span><strong>${s.edad} años</strong></div><div><span class="label">Estatura</span><strong>${F.estatura} cm</strong></div><a class="btn btn-sm" href="#/portal/avance?tab=objetivo">Cambiar</a></div>` + progresoHTML(F, s.edad, 'medicionSocio');
  if (tab === 'rutina') html = (asignada ? `<section class="card corners rise" style="margin-bottom:18px"><div class="card-head"><div><p class="card-kicker">Asignada por tu coach</p><h3 class="card-title">${esc(asignada.nombre)}</h3><p class="hint" style="margin:4px 0 0">Coach ${esc(asignada.coach)} · desde ${fechaMx(asignada.desde)}</p></div>${badge('activa')}</div>
      <div class="week">${asignada.dias.map(d => `<article class="day"><header><span class="mono dim">DÍA ${d.dia_numero}</span><strong>${esc(d.enfoque || '')}</strong></header><ul class="exlist">${d.ejercicios.map(e => `<li><span>${esc(e.nombre)}</span><span class="mono">${e.series}×${esc(e.repeticiones)}<small>${e.descanso}s</small></span></li>`).join('')}</ul></article>`).join('')}</div></section>` : '')
    + `<section class="card rise"><div class="card-head"><div><p class="card-kicker">Rutina semanal sugerida</p><h3 class="card-title">${esc(plan.nombre)} · ${NIVELES[F.nivel]}</h3></div></div>
      ${plan.notas.map(n => `<div class="alert" style="margin-bottom:10px">${icon('alert', 16)}<span class="muted">${esc(n)}</span></div>`).join('')}
      ${semanaHTML(plan)}<p class="hint" style="margin-top:16px">${icon('chart', 14)} Progresión: ${esc(plan.progresion)} Calienta 5-10 min antes de cada sesión.</p></section>`;
  if (tab === 'nutricion') html = nutricionHTML(planNutricional(F), F.objetivo);
  return portal('Avance, rutina y nutrición', 'avance', s, tabsAvance(tab) + html);
}));
const tabsAvance = t => `<nav class="tabs">${[['resumen', 'Progreso e IMC'], ['rutina', 'Rutina semanal'], ['nutricion', 'Plan nutricional sugerido'], ['objetivo', 'Objetivo']].map(([k, n]) => `<a href="#/portal/avance?tab=${k}" class="${k === t ? 'on' : ''}">${n}</a>`).join('')}</nav>`;
FORMS.perfilSocio = d => { const s = socioActual(), e = guardarPerfil(s.id, d, null); if (e) return toast('error', e); flash('ok', 'Listo: tu rutina y tu plan nutricional se generaron con tus datos.'); go('/portal/avance?tab=rutina'); };
FORMS.medicionSocio = d => { const s = socioActual(), e = validarMedicion(d); if (e) return toast('error', e); const m = Repo.mediciones.registrar(s.id, d, null); flash('ok', `Medición guardada. Tu IMC ahora es ${m.imc}.`); render(); };

route('/portal/maquinas', conSocio(s => {
  const zonas = [...new Set(Repo.equipos.listar().map(m => m.zona))];
  after(root => {
    const box = $('[data-machines]', root);
    const pintar = () => {
      const L = Repo.equipos.listar(), f = box.dataset.filter, c = { LIBRE: 0, OCUPADA: 0, MANTENIMIENTO: 0 }; L.forEach(m => c[m.disponibilidad]++);
      $('.machine-grid', box).innerHTML = L.filter(m => f === 'TODAS' || m.zona === f).map(m => `<div class="machine ${m.disponibilidad}"><div class="machine-top"><span class="zone">${esc(m.zona)}</span>${badge(m.disponibilidad)}</div><strong>${esc(m.nombre)}</strong></div>`).join('');
      $('[data-libres]', box).textContent = c.LIBRE; $('[data-ocupadas]', box).textContent = c.OCUPADA; $('[data-mant]', box).textContent = c.MANTENIMIENTO;
      $('.occupancy', box).innerHTML = `<i style="width:${c.LIBRE / L.length * 100}%;background:var(--ok)"></i><i style="width:${c.OCUPADA / L.length * 100}%;background:var(--warn)"></i><i style="width:${c.MANTENIMIENTO / L.length * 100}%;background:var(--dim)"></i>`;
      $('[data-updated]', box).textContent = new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    };
    $$('.filters button', box).forEach(b => b.onclick = () => { $$('.filters button', box).forEach(x => x.classList.toggle('on', x === b)); box.dataset.filter = b.dataset.f; pintar(); });
    $('[data-refresh]', box).onclick = pintar;
    pintar(); const t = setInterval(() => { Repo.equipos.simularMovimiento(); pintar(); }, 8000); cleanup.push(() => clearInterval(t));
  });
  return portal('Máquinas disponibles', 'maquinas', s, `<section data-machines data-filter="TODAS">
  <div class="grid g-3" style="margin-bottom:18px"><div class="card kpi rise"><span class="label">Libres</span><strong style="color:var(--ok)" data-libres>0</strong></div><div class="card kpi rise rise-2"><span class="label">Ocupadas</span><strong style="color:var(--warn)" data-ocupadas>0</strong></div><div class="card kpi rise rise-3"><span class="label">En mantenimiento</span><strong class="muted" data-mant>0</strong></div></div>
  <div class="card rise rise-3"><div class="card-head"><div class="filters" role="group" aria-label="Filtrar por zona"><button class="on" data-f="TODAS">Todas</button>${zonas.map(z => `<button data-f="${esc(z)}">${esc(z)}</button>`).join('')}</div>
    <div class="row"><span class="hint mono"><span class="dot dot-live"></span> En vivo · <span data-updated></span></span><button class="icon-btn" data-refresh title="Actualizar" aria-label="Actualizar">${icon('refresh', 18)}</button></div></div>
    <div class="occupancy" style="margin-bottom:18px"></div><div class="machine-grid"></div></div></section>`);
}));
