function staffShell(titulo, activo, st, contenido) {
  const menu = st.rol === 'instructor'
    ? [['coach', '/coach', 'users', 'Mis socios']]
    : [['panel', '/staff', 'grid', 'Inicio'], ['usuarios', '/staff/usuarios', 'users', 'Información del usuario'], ['cobros', '/staff/cobros', 'receipt', 'Cobros en efectivo']];
  if (['administrador', 'dueno'].includes(st.rol)) menu.push(['admin', '/staff/admin', 'shield', 'Acceso administración']);
  return `<div class="shell">
  <aside class="side"><a href="#${menu[0][1]}" class="side-logo">${logo()}<span class="tag mono">${st.rol === 'instructor' ? 'COACH' : 'STAFF'}</span></a>
    <nav class="side-nav" aria-label="Menú del personal">${menu.map(([k, h, ic, t]) => `<a href="#${h}" class="${k === activo ? 'on' : ''}">${icon(ic)}<span>${t}</span></a>`).join('')}</nav>
    <div class="side-user"><div class="avatar">${esc(st.nombre[0])}</div><div class="side-user-txt"><strong>${esc(st.nombre_corto)}</strong><small class="mono">${ROL_NOMBRE[st.rol]} · ${esc(st.numero_empleado)}</small></div>
      <button class="icon-btn" data-action="logoutStaff" title="Cerrar sesión" aria-label="Cerrar sesión">${icon('logout')}</button></div></aside>
  <main class="main"><header class="topbar"><h1>${esc(titulo)}</h1><span class="chip mono"><span class="dot dot-live"></span>${new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' })}</span></header>${contenido}</main>
</div>`;
}
const conStaff = (fn, roles = ['recepcion', 'administrador', 'dueno']) => ctx => {
  const st = staffActual();
  if (!st) { flash('error', 'Inicia sesión como personal del gimnasio.'); return redirect('/personal'); }
  if (!roles.includes(st.rol)) { flash('error', 'Tu rol no tiene acceso a esa sección.'); return redirect(st.rol === 'instructor' ? '/coach' : '/staff'); }
  return fn(st, ctx);
};
const inicioStaff = st => st.rol === 'instructor' ? '/coach' : '/staff';

let staffLogin = { error: null, v: {} };
route('/personal', ({ query }) => {
  const st0 = staffActual(); if (st0) return redirect(inicioStaff(st0));
  const modo = query.modo === 'admin' ? 'admin' : 'staff', st = staffLogin; staffLogin = { error: null, v: {} };
  return `<div class="reg-page"><header class="reg-head"><a href="#/">${logo()}</a><span class="tag mono">ACCESO DEL PERSONAL</span></header>
  <div class="reg-body" style="align-items:center"><div class="panel rise">
    <p class="kicker">Personal FIT CODE</p><h2 class="title">Inicia sesión</h2>
    <p class="lead">${modo === 'admin' ? 'Administración y dirección: número de empleado, correo institucional y contraseña.' : 'Recepción y coaches: número de empleado o correo y tu contraseña.'}</p>
    <div class="tabs" role="tablist"><a href="#/personal?modo=staff" class="${modo === 'staff' ? 'on' : ''}">${icon('users', 16)} Recepción y coaches</a><a href="#/personal?modo=admin" class="${modo === 'admin' ? 'on' : ''}">${icon('shield', 16)} Administración</a></div>
    ${st.error ? `<div class="alert alert-bad" role="alert" style="margin-bottom:18px">${icon('alert', 18)}<span>${esc(st.error)}</span></div>` : ''}
    <form class="form card corners" data-form="${modo === 'admin' ? 'adminLogin' : 'staffLogin'}" novalidate>
      ${modo === 'admin' ? `
      <div class="field"><label for="num">Número de empleado</label><div class="input-wrap">${icon('id', 18)}<input class="input mono" id="num" name="numero" value="${esc(st.v.numero || '')}" placeholder="ADM-0001" style="text-transform:uppercase" autofocus></div></div>
      <div class="field"><label for="mail">Correo institucional</label><div class="input-wrap">${icon('file', 18)}<input class="input" type="email" id="mail" name="email" value="${esc(st.v.email || '')}" placeholder="nombre@fitcode.mx" autocomplete="username"></div></div>` : `
      <div class="field"><label for="sid">Número de empleado o correo</label><div class="input-wrap">${icon('user', 18)}<input class="input" id="sid" name="identificador" value="${esc(st.v.identificador || '')}" placeholder="REC-0001 · nombre@fitcode.mx" autocomplete="username" autofocus></div></div>`}
      <div class="field"><label for="spw">Contraseña</label><div class="input-wrap">${icon('lock', 18)}<input class="input" type="password" id="spw" name="password" autocomplete="current-password"><button type="button" class="peek" aria-label="Mostrar contraseña">${icon('eye', 18)}</button></div></div>
      <button class="btn btn-primary btn-block" type="submit">Entrar al panel ${icon('arrow', 18)}</button>
    </form>
    ${modo === 'staff' ? `<div class="divider" style="margin:24px 0 16px">¿Eres nuevo?</div>
    <div class="grid g-2"><a class="btn btn-ghost" href="#/personal/registro/recepcion">${icon('user', 16)} Registro de recepción</a><a class="btn btn-ghost" href="#/personal/registro/coach">${icon('dumbbell', 16)} Registro de coach</a></div>
    <p class="hint" style="text-align:center;margin-top:12px">Tu cuenta se activa cuando verifiques tu correo y administración la apruebe.</p>`
    : `<p class="hint" style="text-align:center;margin-top:16px">Las cuentas de administración las da de alta la dirección del gimnasio.</p>`}
    <details class="demo-box"><summary>Cuentas de demostración</summary><p>
      Administración: <span class="mono">ADM-0001</span> · <span class="mono">admin@fitcode.mx</span> · <span class="mono">Admin#2026</span><br>
      Dueño: <span class="mono">DUE-0001</span> · <span class="mono">dueno@fitcode.mx</span> · <span class="mono">Dueno#2026</span><br>
      Recepción: <span class="mono">REC-0001</span> · <span class="mono">Recep#2026</span><br>Coach: <span class="mono">COA-0001</span> · <span class="mono">Coach#2026</span></p></details>
  </div></div></div>`;
});
function trasLoginStaff(r, v) {
  if (r.ok) { SS.set('staff', r.staff.usuario_id); flash('ok', `Hola, ${r.staff.nombre_corto}. Sesión de ${ROL_NOMBRE[r.staff.rol]} iniciada.`); return go(inicioStaff(r.staff)); }
  if (r.sinVerificar) { SS.set('verif', { tipo: 'usuario', id: r.usuario.id }); flash('error', 'Primero verifica tu correo.'); return go('/verificar'); }
  staffLogin = { error: r.error, v }; render();
}
FORMS.staffLogin = d => { if (!d.identificador || !d.password) { staffLogin = { error: 'Completa ambos campos.', v: d }; return render(); } trasLoginStaff(Repo.personal.login(d.identificador, d.password), d); };
FORMS.adminLogin = d => { if (!d.numero || !d.email || !d.password) { staffLogin = { error: 'Completa los tres campos.', v: d }; return render(); } trasLoginStaff(Repo.personal.loginAdmin(d.numero, d.email, d.password), d); };

let staffReg = { E: {}, v: {}, docs: {} };
function registroStaffHTML(puesto) {
  const coach = puesto === 'instructor', { E, v, docs } = staffReg; staffReg = { E: {}, v: {}, docs: staffReg.docs };
  const val = k => esc(v[k] || ''), inv = k => E[k] ? ' invalid' : '', n = Object.keys(E).length;
  return `<div class="reg-page"><header class="reg-head"><a href="#/">${logo()}</a><a href="#/personal" class="btn btn-ghost btn-sm">${icon('back', 16)} Volver</a></header>
  <div class="reg-body"><div class="panel panel-wide rise">
    <p class="kicker">${coach ? 'Coaches y entrenadores' : 'Recepción'}</p><h2 class="title">Registro de ${coach ? 'coach' : 'recepcionista'}</h2>
    <p class="lead">Datos en <strong>MAYÚSCULAS</strong>. Tu cuenta se activa después de verificar tu correo y de que administración la apruebe.</p>
    ${n ? `<div class="alert alert-bad" role="alert" style="margin-bottom:22px">${icon('alert', 18)}<span>Revisa ${n} campo(s) marcados abajo.</span></div>` : ''}
    <form class="form" data-form="registroStaff" novalidate><input type="hidden" name="puesto" value="${puesto}">
      ${coach ? bloqueIdentidad(v, E, '01 · Identidad', 'coach', `<div class="field col-6${inv('rfc')}"><label for="rfc">RFC <span class="req">*</span></label><input class="input mono" id="rfc" name="rfc" value="${val('rfc')}" maxlength="10" style="text-transform:uppercase" placeholder="ABCD000000">${errP(E, 'rfc') || '<p class="hint">4 letras y 6 números, sin homoclave.</p>'}</div>`) : `
      <fieldset class="fieldset"><legend>01 · Identidad</legend><div class="form-grid">
        <div class="field col-4${inv('nombre')}"><label for="nombre">Nombre(s) <span class="req">*</span></label><input class="input upper" id="nombre" name="nombre" value="${val('nombre')}" maxlength="60">${errP(E, 'nombre')}</div>
        <div class="field col-4${inv('apellido_paterno')}"><label for="ap">Apellido paterno <span class="req">*</span></label><input class="input upper" id="ap" name="apellido_paterno" value="${val('apellido_paterno')}" maxlength="60">${errP(E, 'apellido_paterno')}</div>
        <div class="field col-4${inv('apellido_materno')}"><label for="am">Apellido materno <span class="req">*</span></label><input class="input upper" id="am" name="apellido_materno" value="${val('apellido_materno')}" maxlength="60">${errP(E, 'apellido_materno')}</div>
        <div class="field col-6${inv('rfc')}"><label for="rfc">RFC <span class="req">*</span></label><input class="input mono" id="rfc" name="rfc" value="${val('rfc')}" maxlength="10" style="text-transform:uppercase" placeholder="ABCD000000">${errP(E, 'rfc')}</div>
      </div></fieldset>`}
      <fieldset class="fieldset"><legend>02 · Contacto</legend><div class="form-grid">
        <div class="field col-${coach ? 4 : 6}${inv('email')}"><label for="email">Correo <span class="req">*</span></label><input class="input" type="email" id="email" name="email" value="${val('email')}" autocomplete="email">${errP(E, 'email')}</div>
        <div class="field col-${coach ? 4 : 6}${inv('telefono')}"><label for="tel">Número de contacto <span class="req">*</span></label><input class="input mono" id="tel" name="telefono" value="${val('telefono')}" inputmode="tel" data-digits="10" placeholder="10 dígitos">${errP(E, 'telefono')}</div>
        ${coach ? `<div class="field col-4${inv('telefono_emergencia')}"><label for="tem">Número de emergencia <span class="req">*</span></label><input class="input mono" id="tem" name="telefono_emergencia" value="${val('telefono_emergencia')}" inputmode="tel" data-digits="10" placeholder="10 dígitos">${errP(E, 'telefono_emergencia')}</div>` : ''}
      </div></fieldset>
      ${coach ? bloqueSalud(v, E, docs, 'Adjunta un documento en el que un médico avale que puedes ejercer y laborar como coach.') : ''}
      <fieldset class="fieldset"><legend>${coach ? '04' : '03'} · Documentos y firma</legend><div class="form-grid">
        <div class="col-12">${uploadField('id_oficial', 'Foto de identificación oficial', 'INE, pasaporte o cédula · JPG, PNG o PDF', docs.id_oficial)}${errP(E, 'id_oficial')}</div>
        <div class="col-12">${firmaField('Firma electrónica', docs.firma)}${errP(E, 'firma')}</div>
      </div></fieldset>
      <fieldset class="fieldset"><legend>${coach ? '05' : '04'} · Contraseña</legend><div class="form-grid">
        <div class="col-6">${pwField('pw')}${errP(E, 'password')}</div>
        <div class="field col-6"><label for="pw2">Confirmar contraseña <span class="req">*</span></label><div class="input-wrap">${icon('lock', 18)}<input class="input" type="password" id="pw2" name="password2" autocomplete="new-password" data-match="pw"></div><p class="hint"></p>${errP(E, 'password2')}</div>
      </div></fieldset>
      <div class="actions"><span class="hint">Recibirás un código de verificación en tu correo.</span><button class="btn btn-primary" type="submit">Enviar registro ${icon('arrow', 18)}</button></div>
    </form></div></div></div>`;
}
route('/personal/registro/recepcion', () => registroStaffHTML('recepcion'));
route('/personal/registro/coach', () => registroStaffHTML('instructor'));
FORMS.registroStaff = async (d, form) => {
  const coach = d.puesto === 'instructor', E = {}, docs = staffReg.docs || {};
  const v = validarPersona(d, E, 'coach', { sinFecha: !coach, sinGenero: true, sinSalud: !coach });
  v.rfc = (d.rfc || '').trim().toUpperCase(); v.email = (d.email || '').trim().toLowerCase(); v.telefono = (d.telefono || '').replace(/\D/g, ''); v.telefono_emergencia = (d.telefono_emergencia || '').replace(/\D/g, '');
  if (!validarRFC(v.rfc)) E.rfc = 'RFC no válido: 4 letras y 6 números, sin homoclave (ej. GOTL900215).';
  else if (Repo.personal.existeRFC(v.rfc)) E.rfc = 'Ese RFC ya está registrado.';
  if (!RE_EMAIL.test(v.email)) E.email = 'Correo no válido.'; else if (Repo.personal.existeEmail(v.email)) E.email = 'Ese correo ya está registrado.';
  if (!/^\d{10}$/.test(v.telefono)) E.telefono = 'Número a 10 dígitos.';
  if (coach) { if (!/^\d{10}$/.test(v.telefono_emergencia)) E.telefono_emergencia = 'Número a 10 dígitos.'; else if (v.telefono_emergencia === v.telefono) E.telefono_emergencia = 'Debe ser distinto al de contacto.'; }
  const f = validarPassword(d.password || ''); if (f.length) E.password = 'La contraseña necesita: ' + f.join(', ') + '.'; else if (d.password !== d.password2) E.password2 = 'Las contraseñas no coinciden.';
  const btn = form.querySelector('[type=submit]'); btn.disabled = true; btn.textContent = 'Procesando…';
  const req = { id_oficial: 'Identificación oficial' };
  if (coach && v.enfermedad_cronica && v.enfermedad_cronica !== 'NINGUNA') req.cert_medico = 'Constancia médica'; else delete docs.cert_medico;
  await leerDocumentos(form, req, docs, E, 'firma electrónica');
  if (Object.keys(E).length) { staffReg = { E, v: { ...v, fecha_nacimiento: d.fecha_nacimiento }, docs }; return render(); }
  const r = Repo.personal.registrar(d.puesto, { ...v, fecha_nacimiento: v.fecha_iso || null, password: d.password }, docs);
  staffReg = { E: {}, v: {}, docs: {} };
  SS.set('verif', { tipo: 'usuario', id: r.usuario_id });
  flash('ok', `Registro recibido. Tu número de empleado es ${r.numero_empleado}. Verifica tu correo.`);
  go('/verificar');
};

let ultimoScan = null, codigoNuevo = null, cobroRes = null;
route('/staff', conStaff(st => {
  const k = Repo.asistencias.kpisHoy(), pend = Repo.pagos.pendientesEfectivo(), esAdmin = ['administrador', 'dueno'].includes(st.rol);
  const venc = Repo.socios.buscar('').map(s => Repo.membresias.actual(s.id)).filter(m => m && m.por_vencer).length;
  const sc = ultimoScan, cn = codigoNuevo; ultimoScan = null; codigoNuevo = null;
  after(root => $('#scan', root).focus());
  const scanHtml = !sc ? '' : `<div class="alert ${sc.ok ? 'alert-ok' : 'alert-bad'} rise" style="margin-bottom:22px;padding:16px 18px">${icon(sc.ok ? 'check' : 'alert', 22)}<div style="flex:1">
    ${sc.ok ? `<strong style="font:500 17px/1.3 var(--f-display)">${sc.tipo} · ${esc(sc.socio.nombre_completo)}</strong><div class="muted mono" style="font-size:13px;margin-top:4px">${sc.hora.slice(11)} · ${esc(sc.m.plan)} · vence ${fechaMx(sc.m.fecha_fin)}${sc.minutos !== undefined ? ' · estancia ' + sc.minutos + ' min' : ''}</div>`
    : `<strong style="font:500 17px/1.3 var(--f-display)">ACCESO DENEGADO${sc.socio ? ' · ' + esc(sc.socio.nombre_completo) : ''}</strong><div class="muted" style="font-size:13.5px;margin-top:4px">${esc(sc.motivo)}</div>`}</div>
    ${sc.socio ? `<a class="btn btn-sm" href="#/staff/usuario/${sc.socio.id}">Ver ficha</a>` : ''}</div>`;
  return staffShell('Panel de recepción', 'panel', st, `
<form class="scanbar rise" data-form="scan"><span class="scan-ico">${icon('scan', 22)}</span>
  <div style="flex:1;min-width:200px"><label class="label" for="scan">Entrada / salida de socios</label><input class="input" id="scan" name="codigo" placeholder="Escanea o escribe el código · FC2600000…" autocomplete="off" style="margin-top:8px"></div>
  <button class="btn btn-primary" type="submit">${icon('check', 18)} Registrar</button></form>
${scanHtml}
<div class="grid g-4" style="margin-bottom:22px">
  <div class="card kpi rise"><span class="label">Dentro ahora</span><strong>${k.dentro}</strong></div>
  <div class="card kpi rise rise-2"><span class="label">Entradas hoy</span><strong>${k.entradas}</strong><span class="trend">${k.rechazos} rechazo(s)</span></div>
  <div class="card kpi rise rise-3"><span class="label">Vencen en 7 días</span><strong style="color:var(--warn)">${venc}</strong></div>
  <a href="#/staff/cobros" class="card kpi rise rise-4"><span class="label">Cobros en efectivo pendientes</span><strong style="color:${pend.length ? 'var(--accent)' : 'inherit'}">${pend.length}</strong><span class="trend">ver fichas →</span></a>
</div>
<div class="big-choice" style="margin-bottom:22px">
  <a href="#/staff/usuarios" class="rise rise-2"><span class="ico-box">${icon('users', 26)}</span><h3>Información del usuario</h3><p>Busca socios por nombre: datos, membresía, asistencias, pagos y documentos. Cobra en mostrador.</p><span class="go">Buscar socio ${icon('arrow', 16)}</span></a>
  <a href="#/staff/admin" class="rise rise-3${esAdmin ? '' : ' locked'}"><span class="ico-box">${icon(esAdmin ? 'shield' : 'lock', 26)}</span><h3>Acceso administración</h3><p>${esAdmin ? 'Ingresos, corte de caja, personal, máquinas, códigos y bitácora.' : 'Solo para administración y dirección.'}</p><span class="go">${esAdmin ? 'Entrar' : 'Restringido'} ${icon('arrow', 16)}</span></a>
</div>
<div class="grid g-2">
  <section class="card rise rise-3"><div class="card-head"><div><p class="card-kicker">Registro</p><h3 class="card-title">Código para nuevo socio</h3></div></div>
    ${cn ? `<div class="user-reveal corners"><span class="label">Entrega este código al cliente</span><span class="mono" style="letter-spacing:.3em">${cn}</span></div>` : ''}
    <form data-form="genCodigo"><button class="btn btn-block" type="submit">${icon('key', 18)} Generar código de 6 dígitos</button></form>
    <p class="hint" style="margin-bottom:0">Vigente 72 horas. El cliente lo usa en “Registrarme con mi código de recepción”.</p></section>
  <section class="card rise rise-4"><p class="card-kicker">Actividad reciente</p>
    ${Repo.asistencias.recientes(6).map(a => `<a href="#/staff/usuario/${a.socio_id}" class="row row-between" style="padding:9px 0;border-bottom:1px solid var(--line)"><span>${esc(a.socio)}</span><span class="mono dim" style="font-size:12.5px">${a.tipo_movimiento === 'entrada' ? '<span class="accent">ENTRADA</span>' : 'SALIDA'} ${fechaMx(a.creado_en).slice(0, 6)} ${horaDe(a.creado_en)}</span></a>`).join('') || '<div class="empty">Sin movimientos.</div>'}</section>
</div>
<p class="hint" style="margin-top:22px">Prueba el escáner: <span class="mono">FC260000013</span> (Ana · activa) · <span class="mono">FC260000039</span> (Sofía · vencida)</p>`);
}));
FORMS.scan = d => { ultimoScan = Repo.asistencias.escanear(d.codigo || '', staffActual().usuario_id); render(); };
FORMS.genCodigo = () => { codigoNuevo = Repo.codigos.generar(staffActual().usuario_id); render(); };

route('/staff/cobros', conStaff(st => {
  const pend = Repo.pagos.pendientesEfectivo(), r = cobroRes; cobroRes = null;
  after(root => $('#ref', root).focus());
  return staffShell('Cobros en efectivo', 'cobros', st, `
<form class="scanbar rise" data-form="cobrarFicha"><span class="scan-ico">${icon('receipt', 22)}</span>
  <div style="flex:1;min-width:200px"><label class="label" for="ref">Referencia de la ficha</label><input class="input" id="ref" name="referencia" placeholder="Escanea o escribe · EF-XXXXXXXX" autocomplete="off" style="margin-top:8px"></div>
  <button class="btn btn-primary" type="submit">${icon('check', 18)} Cobrar</button></form>
${r ? `<div class="alert ${r.ok ? 'alert-ok' : 'alert-bad'} rise" style="margin-bottom:22px">${icon(r.ok ? 'check' : 'alert', 20)}<span style="flex:1">${r.ok ? `<strong>Cobro registrado · ${dinero(r.pago.monto)}</strong> · ${esc(r.pago.socio)} · ${esc(r.pago.plan)} activa ${fechaMx(r.pago.fecha_inicio)} → ${fechaMx(r.pago.fecha_fin)} · folio <span class="mono">${esc(r.pago.folio)}</span>` : esc(r.error)}</span>${r.ok ? `<a class="btn btn-sm" href="#/staff/recibo/${r.pago.folio}">Recibo</a>` : ''}</div>` : ''}
<section class="card rise rise-2"><div class="card-head"><div><p class="card-kicker">Fichas generadas por los socios</p><h3 class="card-title">${pend.length} pendiente(s) de cobro</h3></div></div>
  ${pend.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>Referencia</th><th>Socio</th><th>Plan</th><th>Vence</th><th class="num">Monto</th><th></th></tr></thead><tbody>
  ${pend.map(p => `<tr><td class="mono">${esc(p.referencia_pago)}</td><td>${esc(p.socio)}<br><span class="hint mono">${esc(p.socio_usuario)}</span></td><td>${esc(p.plan)}</td><td class="mono">${fechaMx(p.expira_en, true)}</td><td class="num">${dinero(p.monto)}</td>
    <td><button class="btn btn-sm btn-primary" data-action="cobrarRef" data-ref="${esc(p.referencia_pago)}">Recibí el efectivo</button></td></tr>`).join('')}</tbody></table></div>` : `<div class="empty">${icon('receipt', 32)}No hay fichas pendientes.</div>`}
  <p class="hint">Confirma el cobro solo cuando tengas el efectivo en mano. La membresía se activa al instante y queda tu usuario como cajero.</p></section>`);
}));
FORMS.cobrarFicha = d => { cobroRes = Repo.pagos.cobrarFicha(d.referencia || '', staffActual().usuario_id); render(); };
ACTIONS.cobrarRef = a => { if (confirm(`¿Confirmas que recibiste el efectivo de la ficha ${a.dataset.ref}?`)) { cobroRes = Repo.pagos.cobrarFicha(a.dataset.ref, staffActual().usuario_id); render(); } };
route('/staff/recibo/:folio', conStaff((st, { params }) => { const r = Repo.pagos.recibo(null, params[0]); if (!r) return redirect('/staff'); return staffShell('Recibo de pago', 'cobros', st, reciboHTML(r, null, '#/staff/cobros')); }));

route('/staff/usuarios', conStaff((st, { query }) => usuariosHTML(st, query.q || '', '/staff/usuario/', 'usuarios')));
function usuariosHTML(st, q, base, activo) {
  const res = Repo.socios.buscar(q.trim());
  after(root => { const i = $('#q', root); i.focus(); i.setSelectionRange(i.value.length, i.value.length); let t; i.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => { location.hash = location.hash.split('?')[0] + '?q=' + encodeURIComponent(i.value); }, 350); }); });
  return staffShell(activo === 'coach' ? 'Mis socios' : 'Información del usuario', activo, st, `
<form class="search-big rise" data-form="buscar" role="search" style="margin-bottom:22px">${icon('search', 20)}<input class="input" id="q" name="q" value="${esc(q)}" placeholder="Buscar por nombre, apellidos, usuario o código…" aria-label="Buscar socio"></form>
<section class="card rise rise-2"><div class="card-head"><div><p class="card-kicker">${q ? 'Resultados para “' + esc(q) + '”' : 'Todos los socios'}</p><h3 class="card-title">${res.length} socio(s)</h3></div></div>
  ${res.length ? `<div class="table-wrap"><table class="t"><thead><tr><th>Socio</th>${activo === 'coach' ? '<th>Objetivo</th><th>IMC</th><th>Rutina</th>' : '<th>Código</th><th>Tipo</th><th>Membresía</th>'}<th></th></tr></thead><tbody>
  ${res.map(s => { const m = Repo.membresias.actual(s.id), u = Repo.mediciones.porSocio(s.id).pop(), e = Repo.expedientes.obtener(s.id);
    return `<tr><td><div class="person"><span class="avatar">${esc(s.nombre[0] + s.apellido_paterno[0])}</span><div><strong>${esc(s.nombre_completo)}</strong><small class="mono">${esc(s.usuario)} · ${s.edad} años</small></div></div></td>
    ${activo === 'coach' ? `<td>${e?.objetivo_principal ? OBJETIVOS[e.objetivo_principal].nombre : '<span class="hint">Sin definir</span>'}</td><td class="mono">${u ? u.imc : '—'}</td><td>${Repo.rutinas.asignada(s.id) ? badge('activa', 'asignada') : '<span class="hint">—</span>'}</td>`
    : `<td class="mono">${esc(s.codigo_credencial)}</td><td>${s.tipo_socio === 'menor' ? 'Menor' : 'Mayor'}</td><td>${m ? badge(m.estado) + (m.estado === 'activa' ? ` <span class="hint mono">→ ${fechaMx(m.fecha_fin)}</span>` : '') : badge('sin membresía')}</td>`}
    <td><a class="btn btn-sm" href="#${base}${s.id}">Ver ficha ${icon('arrow', 14)}</a></td></tr>`; }).join('')}</tbody></table></div>` : `<div class="empty">${icon('search', 32)}No se encontraron socios con ese nombre.</div>`}</section>`);
}
FORMS.buscar = d => { location.hash = location.hash.split('?')[0] + '?q=' + encodeURIComponent(d.q || ''); };

const DOC_NOMBRE = { id_oficial: 'Identificación oficial', id_tutor: 'Identificación del tutor', cert_medico: 'Constancia médica', firma: 'Firma electrónica' };
route('/staff/usuario/:id', conStaff((st, { params }) => {
  const s = Repo.socios.porId(params[0]); if (!s) return redirect('/staff/usuarios');
  const m = Repo.membresias.actual(s.id), dentro = Repo.asistencias.dentro(s.id), vis = Repo.asistencias.visitas(s.id, 10), pagos = Repo.pagos.porSocio(s.id).slice(0, 10), docs = Repo.socios.documentos(s.id), ficha = Repo.pagos.fichaPendiente(s.id);
  after(root => $$('[data-doc]', root).forEach(a => a.onclick = e => { e.preventDefault(); const d = docs.find(x => x.id === +a.dataset.doc); verDocumento({ nombre: d.nombre_archivo, mime: d.mime, data: d.data }); }));
  return staffShell('Información del usuario', 'usuarios', st, `
<a href="#/staff/usuarios" class="btn btn-ghost btn-sm" style="margin-bottom:18px">${icon('back', 16)} Volver a la búsqueda</a>
<div class="grid g-main">
  <section class="card corners rise">
    <div class="card-head"><div class="person"><span class="avatar" style="width:56px;height:56px;font-size:18px">${esc(s.nombre[0] + s.apellido_paterno[0])}</span><div><h2 class="card-title" style="font-size:20px">${esc(s.nombre_completo)}</h2><small class="mono">${esc(s.usuario)} · socio desde ${fechaMx(s.creado_en)}</small></div></div>
      ${dentro ? '<span class="badge badge-ok">DENTRO</span>' : '<span class="badge badge-mute">FUERA</span>'}</div>
    <dl class="dl">
      <div><dt>Edad / nacimiento</dt><dd>${s.edad} años · <span class="mono">${s.fecha_nacimiento.split('-').reverse().join('/')}</span></dd></div>
      <div><dt>Tipo</dt><dd>${s.tipo_socio === 'menor' ? 'Menor · tutor: ' + esc(s.tutor_nombre) : 'Mayor de edad'}</dd></div>
      <div><dt>Género / sexo</dt><dd>${esc(s.genero)} · ${esc(s.sexo)}</dd></div><div><dt>Servicio médico</dt><dd>${esc(s.servicio_medico)}</dd></div>
      <div><dt>Contacto</dt><dd class="mono">${esc(s.telefono)}</dd></div><div><dt>Emergencia</dt><dd class="mono">${esc(s.telefono_emergencia)}</dd></div>
      <div><dt>Correo</dt><dd>${esc(s.email)} ${s.email_verificado_en ? badge('activo', 'verificado') : badge('pendiente', 'sin verificar')}</dd></div>
      <div><dt>Enfermedad crónica</dt><dd>${s.enfermedad_cronica === 'NINGUNA' ? 'Ninguna' : `<span style="color:var(--warn)">${esc(s.enfermedad_cronica === 'OTRA' ? s.enfermedad_otra : s.enfermedad_cronica)}</span>`}</dd></div>
    </dl>
    <div style="margin-top:22px;background:#f4f6f2;border-radius:10px;padding:14px 16px">${barcodeSVG(s.codigo_credencial, 60, 1.6)}<div class="mono" style="text-align:center;font-size:12px;letter-spacing:.3em;margin-top:8px;color:#07080a">${esc(s.codigo_credencial)}</div></div>
    <button class="btn btn-block" style="margin-top:14px" data-action="accesoManual" data-id="${s.id}">${icon('scan', 18)} Registrar ${dentro ? 'salida' : 'entrada'} manual</button>
  </section>
  <div class="grid" style="align-content:start">
    <section class="card rise rise-2">
      <div class="card-head"><div><p class="card-kicker">Membresía</p><h3 class="card-title">${esc(m ? m.plan : 'Sin membresía')}</h3></div>${m ? badge(m.estado) : ''}</div>
      ${m ? `<p class="mono muted" style="margin:0 0 16px;font-size:13px">${fechaMx(m.fecha_inicio)} → ${fechaMx(m.fecha_fin)} · ${m.dias_restantes} días restantes</p>` : ''}
      ${ficha ? `<div class="alert alert-warn" style="margin-bottom:12px">${icon('receipt', 18)}<span style="flex:1">Ficha en efectivo <strong class="mono">${esc(ficha.referencia_pago)}</strong> · ${dinero(ficha.monto)} (${esc(ficha.plan)})</span><button class="btn btn-sm btn-primary" data-action="cobrarRef" data-ref="${esc(ficha.referencia_pago)}">Cobrar</button></div>` : ''}
      <form class="form" data-form="cobroMostrador"><input type="hidden" name="socio" value="${s.id}">
        <div class="form-grid">
          <div class="field col-6"><label for="pl">Plan a cobrar</label><select class="input" id="pl" name="plan">${Repo.planes.listar().map(p => `<option value="${p.id}"${m && p.id === m.tipo_membresia_id ? ' selected' : ''}>${esc(p.nombre)} · $${p.precio.toLocaleString('en-US')}</option>`).join('')}</select></div>
          <div class="field col-6"><label for="mt">Método</label><select class="input" id="mt" name="metodo"><option value="efectivo">Efectivo</option><option value="tarjeta">Tarjeta (terminal)</option></select></div>
        </div>
        <button class="btn btn-primary btn-block" type="submit">${icon('check', 18)} Cobrar en mostrador y asignar</button>
        <p class="hint" style="margin:0">Si tiene membresía activa, la nueva empieza al terminar la actual.</p></form>
    </section>
    <section class="card rise rise-3"><p class="card-kicker">Documentos</p>
      ${docs.length ? `<div class="doc-list">${docs.map(x => `<a href="#" data-doc="${x.id}">${icon('file', 16)}${DOC_NOMBRE[x.tipo] || x.tipo}<span class="hint mono" style="margin-left:auto">${esc((x.mime || '').split('/')[1]?.toUpperCase() || '')}</span></a>`).join('')}</div>` : '<p class="hint">Sin documentos (socio de demostración).</p>'}</section>
  </div>
  <section class="card rise rise-3"><p class="card-kicker">Asistencia</p><div class="table-wrap"><table class="t"><thead><tr><th>Fecha</th><th>Entrada</th><th>Salida</th></tr></thead><tbody>
    ${vis.map(v => `<tr><td>${fechaMx(v.entrada)}</td><td class="mono">${horaDe(v.entrada)}</td><td class="mono">${v.salida ? horaDe(v.salida) : '<span class="badge badge-ok">DENTRO</span>'}</td></tr>`).join('') || '<tr><td colspan="3" class="empty">Sin visitas.</td></tr>'}</tbody></table></div></section>
  <section class="card rise rise-4"><p class="card-kicker">Pagos</p><div class="table-wrap"><table class="t"><thead><tr><th>Folio</th><th>Concepto</th><th>Estado</th><th class="num">Monto</th></tr></thead><tbody>
    ${pagos.map(p => `<tr><td class="mono">${esc(p.folio)}<br><span class="hint">${fechaMx(p.pagado_en || p.creado_en)} · ${METODO_NOMBRE[p.metodo] || p.metodo}</span></td><td>${esc(p.concepto)}</td><td>${badge(p.estado)}</td><td class="num">${dinero(p.monto)}</td></tr>`).join('') || '<tr><td colspan="4" class="empty">Sin pagos.</td></tr>'}</tbody></table></div></section>
</div>`);
}));
FORMS.cobroMostrador = d => { const p = Repo.pagos.cobroMostrador(+d.socio, +d.plan, d.metodo, staffActual().usuario_id); flash('ok', `Cobro registrado (${METODO_NOMBRE[p.metodo]}). ${p.plan}: ${fechaMx(p.fecha_inicio)} → ${fechaMx(p.fecha_fin)}. Folio ${p.folio}.`); render(); };
ACTIONS.accesoManual = a => { const s = Repo.socios.porId(a.dataset.id), r = Repo.asistencias.escanear(s.codigo_credencial, staffActual().usuario_id); flash(r.ok ? 'ok' : 'error', r.ok ? `${r.tipo} registrada a las ${horaDe(r.hora)}.` : r.motivo); render(); };

route('/coach', conStaff((st, { query }) => usuariosHTML(st, query.q || '', '/coach/socio/', 'coach'), ['instructor']));
route('/coach/socio/:id', conStaff((st, { params, query }) => {
  const s = Repo.socios.porId(params[0]); if (!s) return redirect('/coach');
  const F = datosFitness(s), tab = query.tab || 'progreso', hid = `<input type="hidden" name="socio" value="${s.id}">`, asignada = Repo.rutinas.asignada(s.id);
  after(root => initIMC(root, s.edad));
  const tabs = `<nav class="tabs">${[['progreso', 'Progreso e IMC'], ['rutina', 'Rutina'], ['nutricion', 'Nutrición sugerida'], ['objetivo', 'Objetivo']].map(([k, n]) => `<a href="#/coach/socio/${s.id}?tab=${k}" class="${k === tab ? 'on' : ''}">${n}</a>`).join('')}</nav>`;
  const cab = `<a href="#/coach" class="btn btn-ghost btn-sm" style="margin-bottom:18px">${icon('back', 16)} Mis socios</a>
    <div class="goalbar card rise"><span class="avatar">${esc(s.nombre[0] + s.apellido_paterno[0])}</span><div><span class="label">Socio</span><strong>${esc(s.nombre_completo)}</strong></div><div><span class="label">Edad / sexo</span><strong>${s.edad} · ${esc(s.sexo)}</strong></div>
      <div><span class="label">Salud</span><strong style="color:${s.enfermedad_cronica === 'NINGUNA' ? 'inherit' : 'var(--warn)'}">${esc(s.enfermedad_cronica === 'OTRA' ? s.enfermedad_otra : s.enfermedad_cronica)}</strong></div>
      <div><span class="label">Objetivo</span><strong>${F ? OBJETIVOS[F.objetivo].nombre : 'Sin definir'}</strong></div></div>`;
  if (!F || tab === 'objetivo') return staffShell('Expediente del socio', 'coach', st, cab + (F ? tabs : '') + onboardingHTML(F?.exp || Repo.expedientes.obtener(s.id), F?.u, 'perfilCoach', hid, F ? 'Ajustar objetivo' : 'El socio aún no define su objetivo'));
  let html = '';
  if (tab === 'progreso') html = progresoHTML(F, s.edad, 'medicionCoach', hid);
  if (tab === 'rutina') {
    const plan = generarPlan(F);
    html = (asignada ? `<div class="alert alert-ok" style="margin-bottom:18px">${icon('check', 18)}<span style="flex:1">Rutina asignada: <strong>${esc(asignada.nombre)}</strong> por ${esc(asignada.coach)} desde ${fechaMx(asignada.desde)}.</span><button class="btn btn-sm btn-ghost" data-action="quitarRutina" data-id="${asignada.id}">Quitar</button></div>` : '')
      + `<section class="card rise"><div class="card-head"><div><p class="card-kicker">Rutina semanal sugerida</p><h3 class="card-title">${esc(plan.nombre)} · ${NIVELES[F.nivel]}</h3></div>
        <button class="btn btn-primary btn-sm" data-action="asignarRutina" data-id="${s.id}">${icon('check', 16)} Asignar al socio</button></div>
        ${plan.notas.map(n => `<div class="alert" style="margin-bottom:10px">${icon('alert', 16)}<span class="muted">${esc(n)}</span></div>`).join('')}${semanaHTML(plan)}</section>`;
  }
  if (tab === 'nutricion') html = nutricionHTML(planNutricional(F), F.objetivo);
  return staffShell('Expediente del socio', 'coach', st, cab + tabs + html);
}, ['instructor']));
FORMS.perfilCoach = d => { const e = guardarPerfil(+d.socio, d, staffActual().usuario_id); if (e) return toast('error', e); flash('ok', 'Objetivo actualizado. El plan se recalculó.'); go(`/coach/socio/${d.socio}?tab=rutina`); };
FORMS.medicionCoach = d => { const e = validarMedicion(d); if (e) return toast('error', e); const m = Repo.mediciones.registrar(+d.socio, d, staffActual().usuario_id); flash('ok', `Medición registrada. IMC: ${m.imc}.`); render(); };
ACTIONS.asignarRutina = a => { const s = Repo.socios.porId(a.dataset.id), F = datosFitness(s); Repo.rutinas.asignarPlan(s.id, generarPlan(F), staffActual()); flash('ok', `Rutina asignada a ${s.nombre}. Ya la ve en su portal.`); render(); };
ACTIONS.quitarRutina = a => { Repo.rutinas.finalizar(a.dataset.id); flash('ok', 'Rutina retirada.'); render(); };

const TABS_ADMIN = { resumen: 'Resumen', personal: 'Personal', pagos: 'Pagos y corte de caja', maquinas: 'Máquinas', codigos: 'Códigos de registro', bitacora: 'Bitácora de acceso' };
route('/staff/admin', conStaff((st, { query }) => {
  const tab = TABS_ADMIN[query.tab] ? query.tab : 'resumen', ymd = hoyISO();
  let html = '';
  if (tab === 'resumen') {
    const socios = Repo.socios.buscar(''), ms = socios.map(s => Repo.membresias.actual(s.id)).filter(Boolean), act = ms.filter(m => m.estado === 'activa');
    const ing = Repo.pagos.listar(ymd.slice(0, 8) + '01').filter(p => p.estado === 'pagado').reduce((a, p) => a + p.monto, 0);
    const horas = Repo.asistencias.afluenciaPorHora(), mx = Math.max(1, ...Object.values(horas));
    const porPlan = {}; act.forEach(m => porPlan[m.plan] = (porPlan[m.plan] || 0) + 1);
    const pendStaff = Repo.personal.listar().filter(p => p.estado === 'pendiente').length;
    html = `<div class="grid g-4" style="margin-bottom:18px">
      <div class="card kpi rise"><span class="label">Ingresos del mes</span><strong class="mono" style="font-size:24px">${dinero(ing)}</strong></div>
      <div class="card kpi rise rise-2"><span class="label">Socios activos</span><strong>${act.length}<small>/ ${socios.length}</small></strong></div>
      <div class="card kpi rise rise-3"><span class="label">Cobros en efectivo pendientes</span><strong>${Repo.pagos.pendientesEfectivo().length}</strong></div>
      <a class="card kpi rise rise-4" href="#/staff/admin?tab=personal"><span class="label">Personal por aprobar</span><strong style="color:${pendStaff ? 'var(--accent)' : 'inherit'}">${pendStaff}</strong></a></div>
    <div class="grid g-main">
      <section class="card rise rise-2"><p class="card-kicker">Afluencia por hora · 30 días</p><div class="bars" style="height:140px">${Object.entries(horas).map(([h, n]) => `<i class="${n ? 'on' : ''}" style="height:${Math.max(3, n / mx * 100)}%" title="${h}:00 · ${n}"></i>`).join('')}</div><div class="bars-x"><span>05:00</span><span>14:00</span><span>22:00</span></div></section>
      <section class="card rise rise-3"><p class="card-kicker">Membresías activas por plan</p>${Object.entries(porPlan).map(([p, n]) => `<div style="margin-bottom:12px"><div class="row row-between" style="font-size:14px"><span>${esc(p)}</span><span class="mono">${n}</span></div><div class="occupancy" style="margin-top:6px"><i style="width:${n / act.length * 100}%;background:var(--accent)"></i></div></div>`).join('') || '<p class="hint">Sin membresías activas.</p>'}</section>
      <section class="card rise rise-4" style="grid-column:1/-1"><p class="card-kicker">Vencen en los próximos 7 días</p>${socios.filter(s => Repo.membresias.actual(s.id)?.por_vencer).map(s => { const m = Repo.membresias.actual(s.id); return `<a class="row row-between" href="#/staff/usuario/${s.id}" style="padding:10px 0;border-bottom:1px solid var(--line)"><span>${esc(s.nombre_completo)} · <span class="muted">${esc(m.plan)}</span></span><span class="mono" style="color:var(--warn)">${fechaMx(m.fecha_fin)}</span></a>`; }).join('') || '<p class="hint">Ninguna.</p>'}</section>
    </div>`;
  } else if (tab === 'personal') {
    after(root => $$('[data-edoc]', root).forEach(a => a.onclick = e => { e.preventDefault(); const d = Repo.personal.documentos(a.dataset.emp).find(x => x.id === +a.dataset.edoc); verDocumento({ nombre: d.nombre_archivo, mime: d.mime, data: d.data }); }));
    html = `<section class="card rise"><div class="table-wrap"><table class="t"><thead><tr><th>Empleado</th><th>RFC</th><th>Rol</th><th>Correo</th><th>Documentos</th><th>Estado</th><th></th></tr></thead><tbody>
      ${Repo.personal.listar().map(x => { const docs = Repo.personal.documentos(x.empleado_id); return `<tr><td><strong style="font-weight:500">${esc(x.nombre)}</strong><br><span class="hint mono">${esc(x.numero_empleado)}</span></td><td class="mono">${esc(x.rfc)}</td><td>${ROL_NOMBRE[x.rol]}</td>
        <td>${esc(x.email)}<br>${x.verificado ? badge('activo', 'verificado') : badge('pendiente', 'sin verificar')}</td>
        <td>${docs.length ? docs.map(d => `<a href="#" class="link" data-emp="${x.empleado_id}" data-edoc="${d.id}">${DOC_NOMBRE[d.tipo]}</a>`).join('<br>') : '<span class="hint">—</span>'}</td>
        <td>${badge(x.estado)}</td>
        <td>${x.usuario_id !== st.usuario_id && x.rol !== 'dueno' ? (x.estado === 'activo' ? `<button class="btn btn-sm btn-ghost btn-danger" data-action="estadoStaff" data-id="${x.empleado_id}" data-estado="inactivo">Desactivar</button>` : `<button class="btn btn-sm btn-primary" data-action="estadoStaff" data-id="${x.empleado_id}" data-estado="activo"${x.verificado ? '' : ' disabled title="Debe verificar su correo primero"'}>Aprobar</button>`) : ''}</td></tr>`; }).join('')}
    </tbody></table></div><p class="hint">Solo se puede aprobar a quien ya verificó su correo. Revisa la identificación y la firma antes de aprobar.</p></section>`;
  } else if (tab === 'pagos') {
    const dia = /^\d{4}-\d{2}-\d{2}$/.test(query.dia || '') ? query.dia : ymd, corte = Repo.pagos.corte(dia), tot = corte.reduce((a, c) => a + c.total, 0);
    html = `<form class="row" style="margin-bottom:16px" data-form="diaAdmin"><input type="hidden" name="tab" value="pagos"><input class="input" type="date" name="dia" value="${dia}" style="max-width:220px"><button class="btn" type="submit">Ver día</button></form>
    <div class="grid g-4" style="margin-bottom:18px">${corte.map(c => `<div class="card kpi"><span class="label">${METODO_NOMBRE[c.metodo] || c.metodo}</span><strong class="mono" style="font-size:22px">${dinero(c.total)}</strong><span class="trend">${c.pagos} pago(s)</span></div>`).join('')}<div class="card kpi"><span class="label">Corte de caja · ${fechaMx(dia)}</span><strong class="mono" style="font-size:22px;color:var(--accent)">${dinero(tot)}</strong><span class="trend">por fecha de cobro</span></div></div>
    <section class="card"><div class="table-wrap"><table class="t"><thead><tr><th>Folio</th><th>Socio</th><th>Concepto</th><th>Método</th><th>Estado</th><th>Cajero</th><th class="num">Monto</th></tr></thead><tbody>
      ${Repo.pagos.listar().slice(0, 60).map(p => `<tr><td class="mono">${esc(p.folio)}<br><span class="hint">${fechaMx(p.pagado_en || p.creado_en, true)}</span></td><td>${esc(p.socio)}</td><td>${esc(p.concepto)}</td><td>${METODO_NOMBRE[p.metodo] || p.metodo}${p.referencia_pago ? `<br><span class="hint mono">${esc(p.referencia_pago)}</span>` : ''}</td><td>${badge(p.estado)}</td><td class="hint">${esc(p.cajero || (p.metodo === 'mercadopago' ? 'En línea' : '—'))}</td><td class="num">${dinero(p.monto)}</td></tr>`).join('')}</tbody></table></div></section>`;
  } else if (tab === 'maquinas') {
    html = `<section class="card rise"><div class="machine-grid">${Repo.equipos.listar().map(x => `<div class="machine ${x.disponibilidad}" style="opacity:1"><div class="machine-top"><span class="zone">${esc(x.zona)}</span>${badge(x.disponibilidad)}</div><strong>${esc(x.nombre)}</strong>
      <div class="row" style="gap:6px">${[['operativo', 'Operativa'], ['mantenimiento', 'Mantenimiento']].map(([k, t]) => `<button class="btn btn-sm ${x.estado === k ? 'btn-primary' : 'btn-ghost'}" style="flex:1;padding:0 6px;font-size:12px" data-action="equipo" data-id="${x.id}" data-estado="${k}">${t}</button>`).join('')}</div></div>`).join('')}</div>
      <p class="hint">“Ocupada” se calcula con los usos abiertos (tabla uso_equipos); aquí solo se cambia el estado físico del equipo.</p></section>`;
  } else if (tab === 'codigos') {
    html = `<section class="card rise"><div class="alert" style="margin-bottom:16px">${icon('shield', 18)}<span class="muted">Prototipo: el registro acepta cualquier código de 6 dígitos y lo asienta aquí. En producción solo serán válidos los generados en recepción, vigentes y de un solo uso.</span></div>
      <div class="table-wrap"><table class="t"><thead><tr><th>Código</th><th>Generado por</th><th>Fecha</th><th>Vence</th><th>Usado por</th></tr></thead><tbody>
      ${Repo.codigos.listar().map(c => `<tr><td class="mono" style="letter-spacing:.2em">${esc(c.codigo)}</td><td>${esc(c.generado_por_nombre || 'Cliente (prototipo)')}</td><td class="mono">${fechaMx(c.creado_en, true)}</td><td class="mono">${fechaMx(c.expira_en)}</td><td class="mono">${esc(c.usado_por || '—')}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">Sin códigos.</td></tr>'}</tbody></table></div></section>`;
  } else {
    const dia = /^\d{4}-\d{2}-\d{2}$/.test(query.dia || '') ? query.dia : ymd, bit = Repo.asistencias.delDia(dia);
    html = `<section class="card rise"><form class="row" style="margin-bottom:16px" data-form="diaAdmin"><input type="hidden" name="tab" value="bitacora"><input class="input" type="date" name="dia" value="${dia}" style="max-width:220px"><button class="btn" type="submit">Ver día</button></form>
      <div class="table-wrap"><table class="t"><thead><tr><th>Hora</th><th>Socio</th><th>Código leído</th><th>Movimiento</th><th>Resultado</th><th>Registró</th></tr></thead><tbody>
      ${bit.map(b => `<tr><td class="mono">${horaDe(b.creado_en)}</td><td>${esc(b.socio)}</td><td class="mono">${esc(b.codigo_leido)}</td><td>${esc(b.tipo_movimiento || '—')}</td><td>${badge(b.resultado)}${b.motivo ? `<br><span class="hint">${esc(b.motivo)}</span>` : ''}</td><td class="hint">${esc(b.registro)}</td></tr>`).join('') || '<tr><td colspan="6" class="empty">Sin lecturas ese día.</td></tr>'}</tbody></table></div>
      <p class="hint">Se guardan también los intentos rechazados (código inválido, membresía vencida), como lo define la tabla asistencias del diseño.</p></section>`;
  }
  return staffShell('Acceso administración', 'admin', st, `<nav class="tabs">${Object.entries(TABS_ADMIN).map(([k, t]) => `<a href="#/staff/admin?tab=${k}" class="${k === tab ? 'on' : ''}">${t}</a>`).join('')}</nav>${html}
  <p class="hint" style="margin-top:22px"><button class="btn btn-sm btn-ghost" data-action="reset">${icon('refresh', 14)} Reiniciar datos de la demo</button></p>`);
}, ['administrador', 'dueno']));
ACTIONS.estadoStaff = a => { Repo.personal.cambiarEstado(+a.dataset.id, a.dataset.estado, staffActual().usuario_id); flash('ok', a.dataset.estado === 'activo' ? 'Cuenta aprobada: ya puede iniciar sesión.' : 'Cuenta desactivada.'); render(); };
ACTIONS.equipo = a => { Repo.equipos.cambiarEstado(+a.dataset.id, a.dataset.estado, staffActual().usuario_id); flash('ok', 'Estado del equipo actualizado.'); render(); };
FORMS.diaAdmin = d => go(`/staff/admin?tab=${d.tab}&dia=${d.dia}`);

cargar();
render();
