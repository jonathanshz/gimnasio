'use strict';

const LS_KEY = 'fitcode_gimnasio_integral_db_v2';
let T = null;

const CAT_GENERO = ['MASCULINO', 'FEMENINO', 'NO BINARIO', 'OTRO', 'PREFIERO NO DECIRLO'];
const CAT_SEXO = ['HOMBRE', 'MUJER', 'INTERSEXUAL'];
const CAT_SERVICIO = ['IMSS', 'ISSSTE', 'IMSS-BIENESTAR', 'PEMEX', 'SEDENA', 'SEMAR', 'SEGURO DE GASTOS MÉDICOS PRIVADO', 'NINGUNO'];
const CAT_ENF = ['NINGUNA', 'DIABETES TIPO 1', 'DIABETES TIPO 2', 'HIPERTENSIÓN ARTERIAL', 'ASMA', 'OBESIDAD', 'CARDIOPATÍA', 'ENFERMEDAD PULMONAR OBSTRUCTIVA CRÓNICA (EPOC)', 'ARTRITIS / ARTROSIS', 'HIPOTIROIDISMO / HIPERTIROIDISMO', 'EPILEPSIA', 'INSUFICIENCIA RENAL CRÓNICA', 'ESCOLIOSIS / HERNIA DISCAL', 'OTRA'];
const ROL_NOMBRE = { dueno: 'Dueño', administrador: 'Administración', recepcion: 'Recepción', instructor: 'Coach' };
const METODO_NOMBRE = { efectivo: 'Efectivo', tarjeta: 'Tarjeta (terminal)', mercadopago: 'Tarjeta en línea', transferencia: 'Transferencia' };

function guardar() {
  try { localStorage.setItem(LS_KEY, JSON.stringify(T)); }
  catch (e) { toast('error', 'El almacenamiento del navegador está lleno. Usa archivos más ligeros o reinicia la demo.'); }
}
function cargar() {
  try { T = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); } catch (_) { T = null; }
  if (!T || !T.socios) { T = semilla(); guardar(); }
}
const nid = t => T[t].reduce((m, r) => Math.max(m, r.id || 0), 0) + 1;
function ins(t, row) { row.id = nid(t); T[t].push(row); return row; }
const uno = (t, id) => T[t].find(r => r.id === +id) || null;
const nombreDe = p => [p.nombre, p.apellido_paterno, p.apellido_materno].filter(Boolean).join(' ');
const minutosDesde = (iso, min) => isoDateTime(new Date(parseISO(iso).getTime() + min * 60000));

const Repo = {};
Repo.reiniciar = () => { localStorage.removeItem(LS_KEY); cargar(); };

Repo.sesion = {
  abrir(tipo, id) {
    ins('sesiones', { usuario_id: tipo === 'usuario' ? id : null, socio_id: tipo === 'socio' ? id : null, token_hash: hashPw(String(Math.random())), creada_en: ahoraISO(), expira_en: minutosDesde(ahoraISO(), 480), cerrada_en: null });
    if (tipo === 'usuario') uno('usuarios', id).ultimo_acceso = ahoraISO();
    guardar();
  },
  cerrar(tipo, id) {
    T.sesiones.filter(s => (tipo === 'socio' ? s.socio_id : s.usuario_id) === id && !s.cerrada_en).forEach(s => s.cerrada_en = ahoraISO());
    guardar();
  },
};

function bitacora(actor, id, accion, modulo, detalle = null) {
  ins('bitacora', { usuario_id: actor === 'staff' ? id : null, socio_id: actor === 'socio' ? id : null, actor, accion, modulo, detalle, creado_en: ahoraISO() });
}

function estaBloqueado(row) { return row && row.bloqueado_hasta && row.bloqueado_hasta > ahoraISO(); }
function marcarIntento(row, ok) {
  if (!row) return;
  if (ok) { row.intentos_fallidos = 0; row.bloqueado_hasta = null; }
  else { row.intentos_fallidos = (row.intentos_fallidos || 0) + 1; if (row.intentos_fallidos >= 5) { row.bloqueado_hasta = minutosDesde(ahoraISO(), 10); row.intentos_fallidos = 0; } }
  guardar();
}

Repo.socios = {
  porId(id) {
    const s = uno('socios', id);
    return s ? { ...s, edad: edadDesde(parseISO(s.fecha_nacimiento)), nombre_completo: nombreDe(s) } : null;
  },

  login(identificador, password) {
    const tel = identificador.replace(/\D/g, '');
    const s = T.socios.find(x => x.usuario.toUpperCase() === identificador.toUpperCase() || x.email.toLowerCase() === identificador.toLowerCase() || (tel.length === 10 && x.telefono === tel));
    if (estaBloqueado(s)) return { ok: false, error: 'Demasiados intentos fallidos. Por seguridad, espera 10 minutos o acude a recepción.' };
    const ok = !!s && s.activo && s.password_hash === hashPw(password);
    marcarIntento(s, ok);
    if (!ok) return { ok: false, error: 'Usuario o contraseña incorrectos.' };
    if (!s.email_verificado_en) return { ok: false, sinVerificar: true, socio: s };
    Repo.sesion.abrir('socio', s.id); bitacora('socio', s.id, 'login', 'auth');
    return { ok: true, socio: s };
  },

  existeEmail: e => T.socios.some(s => s.email.toLowerCase() === e.toLowerCase()) || T.usuarios.some(u => u.email.toLowerCase() === e.toLowerCase()),
  existeTelefono: t => T.socios.some(s => s.telefono === t),

  generarUsuario(nombre, ap, am, fechaIso) {
    const n = quitarAcentos(nombre).trim().split(' ')[0], d = parseISO(fechaIso);
    const base = (n + quitarAcentos(ap).slice(0, 1) + quitarAcentos(am).slice(0, 1)).toUpperCase() + '-' + pad(d.getDate()) + pad(d.getMonth() + 1) + String(d.getFullYear()).slice(2);
    let u = base, i = 2; while (T.socios.some(s => s.usuario === u)) u = base + '-' + i++;
    return u;
  },

  crear(d, docs, codigoRegistroId) {
    const s = ins('socios', {
      codigo_credencial: null, usuario: d.usuario, nombre: d.nombre, apellido_paterno: d.apellido_paterno, apellido_materno: d.apellido_materno,
      apellidos: `${d.apellido_paterno} ${d.apellido_materno}`, email: d.email, telefono: d.telefono, fecha_nacimiento: d.fecha_nacimiento,
      genero: d.genero, sexo: d.sexo, tipo_socio: d.tipo_socio, tutor_nombre: d.tutor_nombre || null, servicio_medico: d.servicio_medico,
      enfermedad_cronica: d.enfermedad_cronica, enfermedad_otra: d.enfermedad_otra || null, contacto_emergencia: d.tutor_nombre || null,
      telefono_emergencia: d.telefono_emergencia, tel_contacto: d.tel_contacto, password_hash: hashPw(d.password), email_verificado_en: null,
      intentos_fallidos: 0, bloqueado_hasta: null, activo: 1, creado_en: ahoraISO(),
    });
    s.codigo_credencial = generarCodigoBarras(s.id, hoyISO());
    Object.entries(docs).forEach(([tipo, f]) => ins('socio_documentos', { socio_id: s.id, tipo, nombre_archivo: f.nombre, mime: f.mime, data: f.data, creado_en: ahoraISO() }));
    ins('expedientes', { socio_id: s.id, objetivo_principal: null, nivel: null, dias_entrenamiento: null, alergias: null, observaciones: null, actualizado_por: null, creado_en: ahoraISO(), actualizado_en: ahoraISO() });
    const c = uno('codigos_registro', codigoRegistroId); if (c) { c.usado_por_socio_id = s.id; c.usado_en = ahoraISO(); }
    bitacora('socio', s.id, 'registro', 'socios'); guardar();
    return s;
  },

  buscar(q) {
    const w = q ? quitarAcentos(q).toUpperCase().split(/\s+/).filter(Boolean) : [];
    return T.socios.filter(s => { const t = quitarAcentos(`${nombreDe(s)} ${s.usuario} ${s.codigo_credencial}`).toUpperCase(); return w.every(x => t.includes(x)); })
      .map(s => Repo.socios.porId(s.id)).sort((a, b) => a.nombre_completo.localeCompare(b.nombre_completo));
  },

  documentos: id => T.socio_documentos.filter(d => d.socio_id === +id),
};

Repo.codigos = {
  validar(codigo) {
    T.intentos_codigo = (T.intentos_codigo || []).filter(t => t > Date.now() - 600000);
    if (T.intentos_codigo.length >= 5) return { ok: false, error: 'Demasiados códigos inválidos. Espera 10 minutos o solicita uno nuevo en recepción.' };
    if (!/^\d{6}$/.test(codigo)) { T.intentos_codigo.push(Date.now()); guardar(); return { ok: false, error: 'El código debe tener exactamente 6 dígitos (0-9).' }; }
    let c = T.codigos_registro.find(x => x.codigo === codigo && !x.usado_en && x.expira_en > ahoraISO());
    if (!c) c = ins('codigos_registro', { codigo, generado_por: null, usado_por_socio_id: null, creado_en: ahoraISO(), expira_en: minutosDesde(ahoraISO(), 60 * 72), usado_en: null });
    guardar();
    return { ok: true, id: c.id };
  },
  generar(usuarioId) {
    const codigo = pad(Math.floor(Math.random() * 1e6), 6);
    ins('codigos_registro', { codigo, generado_por: usuarioId, usado_por_socio_id: null, creado_en: ahoraISO(), expira_en: minutosDesde(ahoraISO(), 60 * 72), usado_en: null });
    bitacora('staff', usuarioId, 'generar_codigo', 'registro'); guardar();
    return codigo;
  },
  listar: () => [...T.codigos_registro].reverse().slice(0, 40).map(c => ({ ...c, generado_por_nombre: c.generado_por ? uno('usuarios', c.generado_por).nombre : null, usado_por: c.usado_por_socio_id ? uno('socios', c.usado_por_socio_id).usuario : null })),
};

Repo.verificacion = {
  enviar(tipo, id) {
    const cuenta = uno(tipo === 'socio' ? 'socios' : 'usuarios', id);
    const previa = T.verificaciones_correo.filter(v => v.tipo === tipo && v.cuenta_id === +id).pop();
    if (previa && previa.creado_en > minutosDesde(ahoraISO(), -1) && !previa.invalidado_en) return { ok: false, error: 'Espera un minuto antes de pedir otro código.', email: cuenta.email };
    T.verificaciones_correo.filter(v => v.tipo === tipo && v.cuenta_id === +id && !v.verificado_en).forEach(v => v.invalidado_en = ahoraISO());
    const codigo = pad(Math.floor(Math.random() * 1e6), 6);
    ins('verificaciones_correo', { tipo, cuenta_id: +id, email: cuenta.email, codigo_hash: hashPw(codigo), intentos: 0, creado_en: ahoraISO(), expira_en: minutosDesde(ahoraISO(), 15), verificado_en: null, invalidado_en: null, _codigo_demo: codigo });
    guardar();
    return { ok: true, email: cuenta.email, codigoDemo: codigo };
  },
  ultimo(tipo, id) { const v = T.verificaciones_correo.filter(x => x.tipo === tipo && x.cuenta_id === +id && !x.invalidado_en && !x.verificado_en).pop(); return v ? { email: v.email, codigoDemo: v._codigo_demo, expira_en: v.expira_en } : null; },

  confirmar(tipo, id, codigo) {
    const v = T.verificaciones_correo.filter(x => x.tipo === tipo && x.cuenta_id === +id && !x.verificado_en && !x.invalidado_en).pop();
    if (!v) return { ok: false, error: 'No hay un código vigente. Pide uno nuevo.' };
    if (v.expira_en < ahoraISO()) { v.invalidado_en = ahoraISO(); guardar(); return { ok: false, error: 'El código expiró (15 min). Pide uno nuevo.' }; }
    if (v.codigo_hash !== hashPw(codigo)) {
      v.intentos++; if (v.intentos >= 5) v.invalidado_en = ahoraISO(); guardar();
      return { ok: false, error: v.invalidado_en ? 'Demasiados intentos. Pide un código nuevo.' : `Código incorrecto. Te quedan ${5 - v.intentos} intento(s).` };
    }
    v.verificado_en = ahoraISO();
    uno(tipo === 'socio' ? 'socios' : 'usuarios', id).email_verificado_en = ahoraISO();
    guardar();
    return { ok: true };
  },
};

function staffVista(u) {
  if (!u) return null;
  const e = uno('empleados', u.empleado_id), r = uno('roles', u.rol_id), ins_ = T.instructores.find(i => i.empleado_id === u.empleado_id);
  return { id: u.id, usuario_id: u.id, empleado_id: e.id, instructor_id: ins_ ? ins_.id : null, rol: r.nombre, nombre: nombreDe(e), nombre_corto: e.nombre.split(' ')[0], numero_empleado: e.numero_empleado, email: u.email, rfc: e.rfc, estado: e.estado, verificado: !!u.email_verificado_en, activo: u.activo };
}
Repo.personal = {
  login(identificador, password) {
    const id = identificador.trim().toLowerCase();
    const u = T.usuarios.find(x => { const e = uno('empleados', x.empleado_id); return (e.numero_empleado.toLowerCase() === id || x.email.toLowerCase() === id) && ['recepcion', 'instructor'].includes(uno('roles', x.rol_id).nombre); });
    return Repo.personal._validar(u, password, 'Número de empleado, correo o contraseña incorrectos.');
  },

  loginAdmin(numero, email, password) {
    const u = T.usuarios.find(x => { const e = uno('empleados', x.empleado_id); return e.numero_empleado.toUpperCase() === numero.trim().toUpperCase() && x.email.toLowerCase() === email.trim().toLowerCase() && ['administrador', 'dueno'].includes(uno('roles', x.rol_id).nombre); });
    return Repo.personal._validar(u, password, 'Los datos de acceso no coinciden.');
  },
  _validar(u, password, msg) {
    if (estaBloqueado(u)) return { ok: false, error: 'Cuenta bloqueada temporalmente por intentos fallidos. Espera 10 minutos.' };
    const ok = !!u && u.password_hash === hashPw(password); marcarIntento(u, ok);
    if (!ok) return { ok: false, error: msg };
    if (!u.email_verificado_en) return { ok: false, sinVerificar: true, usuario: u };
    const e = uno('empleados', u.empleado_id);
    if (e.estado === 'pendiente') return { ok: false, error: 'Tu cuenta está pendiente de aprobación por administración.' };
    if (e.estado !== 'activo' || !u.activo) return { ok: false, error: 'Tu cuenta está desactivada. Contacta a administración.' };
    Repo.sesion.abrir('usuario', u.id); bitacora('staff', u.id, 'login', 'auth');
    return { ok: true, staff: staffVista(u) };
  },
  sesionActiva(usuarioId) { const v = staffVista(uno('usuarios', usuarioId)); return v && v.activo && v.estado === 'activo' && v.verificado ? v : null; },
  porUsuario: id => staffVista(uno('usuarios', id)),

  existeRFC: r => T.empleados.some(e => e.rfc === r),
  existeEmail: e => T.usuarios.some(u => u.email.toLowerCase() === e.toLowerCase()) || T.socios.some(s => s.email.toLowerCase() === e.toLowerCase()),

  registrar(puesto, d, docs) {
    const pref = puesto === 'instructor' ? 'COA' : 'REC';
    const pId = T.puestos.find(p => p.clave === puesto).id;
    const n = T.empleados.filter(e => e.puesto_id === pId).length + 1;
    const e = ins('empleados', {
      numero_empleado: `${pref}-${pad(n, 4)}`, puesto_id: pId, nombre: d.nombre, apellido_paterno: d.apellido_paterno, apellido_materno: d.apellido_materno,
      apellidos: `${d.apellido_paterno} ${d.apellido_materno}`, email: d.email, telefono: d.telefono, rfc: d.rfc, fecha_nacimiento: d.fecha_nacimiento || null,
      contacto_emergencia: null, telefono_emergencia: d.telefono_emergencia || null, servicio_medico: d.servicio_medico || null,
      enfermedad_cronica: d.enfermedad_cronica || null, enfermedad_otra: d.enfermedad_otra || null, fecha_ingreso: hoyISO(), estado: 'pendiente', creado_en: ahoraISO(),
    });
    const u = ins('usuarios', { nombre: nombreDe(e), email: d.email, password_hash: hashPw(d.password), rol_id: T.roles.find(r => r.nombre === puesto).id, empleado_id: e.id, activo: 0, intentos_fallidos: 0, bloqueado_hasta: null, ultimo_acceso: null, email_verificado_en: null, creado_en: ahoraISO() });
    if (puesto === 'instructor') ins('instructores', { empleado_id: e.id, especialidad: null, activo: 1 });
    Object.entries(docs).forEach(([tipo, f]) => ins('empleado_documentos', { empleado_id: e.id, tipo, nombre_archivo: f.nombre, mime: f.mime, data: f.data, creado_en: ahoraISO() }));
    guardar();
    return { usuario_id: u.id, numero_empleado: e.numero_empleado };
  },

  listar: () => T.usuarios.map(staffVista).sort((a, b) => ['pendiente', 'activo', 'inactivo'].indexOf(a.estado) - ['pendiente', 'activo', 'inactivo'].indexOf(b.estado) || a.numero_empleado.localeCompare(b.numero_empleado)),

  cambiarEstado(empleadoId, estado, adminId) {
    const e = uno('empleados', empleadoId); e.estado = estado;
    const u = T.usuarios.find(x => x.empleado_id === e.id); u.activo = estado === 'activo' ? 1 : 0;
    bitacora('staff', adminId, 'personal_' + estado, 'personal', e.numero_empleado); guardar();
  },
  documentos: id => T.empleado_documentos.filter(d => d.empleado_id === +id),
  empleado: id => uno('empleados', id),
};

Repo.planes = {
  listar: () => T.tipos_membresia.filter(p => p.activo).sort((a, b) => a.precio - b.precio).map(p => ({ ...p, beneficios: p.beneficios_descripcion.split('\n') })),
  porId: id => { const p = uno('tipos_membresia', id); return p ? { ...p, beneficios: p.beneficios_descripcion.split('\n') } : null; },
};
function enriquecerM(m) {
  const p = Repo.planes.porId(m.tipo_membresia_id), H = hoy(), ini = parseISO(m.fecha_inicio), fin = parseISO(m.fecha_fin);
  let estado = m.estado;
  if (estado === 'activa' && H > fin) estado = 'vencida';
  if (estado === 'activa' && H < ini) estado = 'pendiente';
  const total = Math.max(1, diasEntre(ini, fin) + 1), restan = H > fin ? 0 : diasEntre(H < ini ? ini : H, fin) + 1;
  return { ...m, estado, plan: p.nombre, precio: p.precio, beneficios: p.beneficios, descripcion: p.descripcion, dias_totales: total, dias_restantes: restan, porcentaje: Math.round(Math.min(100, restan / total * 100)), por_vencer: estado === 'activa' && restan <= 7 };
}
Repo.membresias = {
  actual(socioId) {
    const ms = T.membresias.filter(m => m.socio_id === +socioId && m.estado !== 'cancelada').map(enriquecerM);
    if (!ms.length) return null;
    return ms.find(m => m.estado === 'activa') || ms.sort((a, b) => b.fecha_fin.localeCompare(a.fecha_fin))[0];
  },
  siguiente: socioId => T.membresias.filter(m => m.socio_id === +socioId && m.estado === 'activa' && m.fecha_inicio > hoyISO()).map(enriquecerM).sort((a, b) => a.fecha_inicio.localeCompare(b.fecha_inicio))[0] || null,
  historial: socioId => T.membresias.filter(m => m.socio_id === +socioId).map(enriquecerM).sort((a, b) => b.fecha_inicio.localeCompare(a.fecha_inicio)),

  _crear(socioId, tipoId) {
    const p = uno('tipos_membresia', tipoId);
    const vig = T.membresias.filter(m => m.socio_id === +socioId && m.estado === 'activa' && m.fecha_fin >= hoyISO()).map(m => m.fecha_fin).sort().pop();
    const ini = vig ? addDays(parseISO(vig), 1) : hoy();
    const m = ins('membresias', { socio_id: +socioId, tipo_membresia_id: p.id, fecha_inicio: isoDate(ini), fecha_fin: isoDate(addDays(ini, p.duracion_dias - 1)), estado: 'activa', congelada_desde: null, precio_aplicado: p.precio, observaciones: null, creado_en: ahoraISO() });
    return m;
  },
};

function nuevoFolio() {
  let f; do { const d = new Date(); f = 'R' + String(d.getFullYear()).slice(2) + pad(d.getMonth() + 1) + pad(d.getDate()) + Math.floor(Math.random() * 0xffffff).toString(16).toUpperCase().padStart(6, '0'); } while (T.pagos.some(p => p.folio === f));
  return f;
}
function nuevaReferencia() { const c = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; let r; do { r = 'EF-' + Array.from({ length: 8 }, () => c[Math.floor(Math.random() * c.length)]).join(''); } while (T.pagos.some(p => p.referencia_pago === r)); return r; }
function pagoVista(p) {
  const s = uno('socios', p.socio_id), m = p.membresia_id ? uno('membresias', p.membresia_id) : null, u = p.usuario_id ? uno('usuarios', p.usuario_id) : null;
  return { ...p, socio: s ? nombreDe(s) : '—', socio_usuario: s?.usuario, plan: uno('tipos_membresia', p.tipo_membresia_id)?.nombre, fecha_inicio: m?.fecha_inicio, fecha_fin: m?.fecha_fin, cajero: u ? u.nombre : null };
}
function liquidar(p, usuarioId, extra = {}) {
  Object.assign(p, { estado: 'pagado', pagado_en: ahoraISO(), usuario_id: usuarioId ?? p.usuario_id }, extra);
  const m = Repo.membresias._crear(p.socio_id, p.tipo_membresia_id); p.membresia_id = m.id;
  ins('detalle_pagos', { pago_id: p.id, servicio_id: null, descripcion: p.concepto, cantidad: 1, precio_unitario: p.monto, descuento: 0, subtotal: p.monto });
  ins('movimientos_contables', { tipo: 'ingreso', categoria: 'Membresías', concepto: p.concepto, monto: p.monto, pago_id: p.id, usuario_id: usuarioId, referencia: p.folio, fecha_movimiento: ahoraISO() });
  bitacora(usuarioId ? 'staff' : 'socio', usuarioId || p.socio_id, 'pago_' + p.metodo, 'pagos', p.folio);
  guardar();
  return pagoVista(p);
}
function expirarFichas() {
  let cambio = false;
  T.pagos.filter(p => p.estado === 'pendiente' && p.expira_en && p.expira_en < ahoraISO()).forEach(p => { p.estado = 'expirado'; cambio = true; });
  if (cambio) guardar();
}
Repo.pagos = {
  porSocio(socioId) { expirarFichas(); return T.pagos.filter(p => p.socio_id === +socioId).sort((a, b) => b.creado_en.localeCompare(a.creado_en)).map(pagoVista); },
  recibo(socioId, folio) { const p = T.pagos.find(x => x.folio === folio && (socioId === null || x.socio_id === +socioId)); return p ? pagoVista(p) : null; },
  fichaPendiente(socioId) { expirarFichas(); const p = T.pagos.find(x => x.socio_id === +socioId && x.estado === 'pendiente' && x.metodo === 'efectivo'); return p ? pagoVista(p) : null; },

  pagarTarjetaEnLinea(socioId, tipoId, tarjeta) {
    const plan = uno('tipos_membresia', tipoId);
    const p = ins('pagos', { folio: nuevoFolio(), socio_id: +socioId, membresia_id: null, tipo_membresia_id: plan.id, concepto: 'Membresía ' + plan.nombre, monto: plan.precio, metodo: 'mercadopago', usuario_id: null, estado: 'pendiente', referencia_externa: null, referencia_pago: null, expira_en: null, tarjeta_marca: tarjeta.marca, tarjeta_ultimos4: tarjeta.ultimos4, observaciones: null, creado_en: ahoraISO(), pagado_en: null });
    if (!tarjeta.aprobada) { p.estado = 'rechazado'; p.observaciones = 'Rechazado por el banco (simulación)'; guardar(); return { ok: false, error: 'El banco rechazó la tarjeta. Prueba con otra o paga en efectivo.' }; }
    return { ok: true, pago: liquidar(p, null, { referencia_externa: 'MP-SIM-' + Date.now() }) };
  },

  crearFichaEfectivo(socioId, tipoId) {
    T.pagos.filter(p => p.socio_id === +socioId && p.metodo === 'efectivo' && p.estado === 'pendiente').forEach(p => p.estado = 'cancelado');
    const plan = uno('tipos_membresia', tipoId);
    const p = ins('pagos', { folio: nuevoFolio(), socio_id: +socioId, membresia_id: null, tipo_membresia_id: plan.id, concepto: 'Membresía ' + plan.nombre, monto: plan.precio, metodo: 'efectivo', usuario_id: null, estado: 'pendiente', referencia_externa: null, referencia_pago: nuevaReferencia(), expira_en: minutosDesde(ahoraISO(), 72 * 60), tarjeta_marca: null, tarjeta_ultimos4: null, observaciones: null, creado_en: ahoraISO(), pagado_en: null });
    bitacora('socio', socioId, 'ficha_efectivo', 'pagos', p.referencia_pago); guardar();
    return pagoVista(p);
  },
  cancelarFicha(socioId, pagoId) { const p = T.pagos.find(x => x.id === +pagoId && x.socio_id === +socioId && x.estado === 'pendiente'); if (p) { p.estado = 'cancelado'; guardar(); } },

  pendientesEfectivo() { expirarFichas(); return T.pagos.filter(p => p.estado === 'pendiente' && p.metodo === 'efectivo').map(pagoVista); },

  cobrarFicha(referencia, usuarioId) {
    expirarFichas();
    const ref = referencia.trim().toUpperCase();
    const p = T.pagos.find(x => x.referencia_pago === ref);
    if (!p) return { ok: false, error: 'No existe una ficha con esa referencia.' };
    if (p.estado !== 'pendiente') return { ok: false, error: `La ficha ${ref} está ${p.estado}.` };
    return { ok: true, pago: liquidar(p, usuarioId) };
  },

  cobroMostrador(socioId, tipoId, metodo, usuarioId) {
    const plan = uno('tipos_membresia', tipoId);
    const p = ins('pagos', { folio: nuevoFolio(), socio_id: +socioId, membresia_id: null, tipo_membresia_id: plan.id, concepto: 'Membresía ' + plan.nombre, monto: plan.precio, metodo, usuario_id: usuarioId, estado: 'pendiente', referencia_externa: null, referencia_pago: null, expira_en: null, tarjeta_marca: null, tarjeta_ultimos4: null, observaciones: null, creado_en: ahoraISO(), pagado_en: null });
    T.pagos.filter(x => x.socio_id === +socioId && x.metodo === 'efectivo' && x.estado === 'pendiente').forEach(x => x.estado = 'cancelado');
    return liquidar(p, usuarioId);
  },

  listar(desde, hasta) { expirarFichas(); return T.pagos.filter(p => (!desde || p.creado_en >= desde) && (!hasta || p.creado_en.slice(0, 10) <= hasta)).sort((a, b) => b.creado_en.localeCompare(a.creado_en)).slice(0, 300).map(pagoVista); },
  corte(fecha) {
    const r = {}; T.pagos.filter(p => p.estado === 'pagado' && (p.pagado_en || '').startsWith(fecha)).forEach(p => { r[p.metodo] = r[p.metodo] || { metodo: p.metodo, pagos: 0, total: 0 }; r[p.metodo].pagos++; r[p.metodo].total += p.monto; });
    return Object.values(r);
  },
};

function visitasDe(socioId) {
  const ev = T.asistencias.filter(a => a.socio_id === +socioId && a.resultado === 'permitido').sort((a, b) => a.creado_en.localeCompare(b.creado_en));
  const v = []; let abierta = null;
  ev.forEach(a => { if (a.tipo_movimiento === 'entrada') { abierta = { entrada: a.creado_en, salida: null, registrado_por: a.registrado_por }; v.push(abierta); } else if (abierta) { abierta.salida = a.creado_en; abierta = null; } });
  return v.reverse();
}
Repo.asistencias = {
  escanear(codigo, usuarioId) {
    codigo = String(codigo).trim().toUpperCase();
    const log = (socioId, resultado, motivo, tipo) => { ins('asistencias', { socio_id: socioId, codigo_leido: codigo, resultado, motivo, tipo_movimiento: tipo, registrado_por: usuarioId, creado_en: ahoraISO() }); guardar(); };
    if (!codigoValido(codigo)) { log(null, 'codigo_invalido', 'Dígito verificador incorrecto', null); return { ok: false, motivo: 'Código de barras no válido o mal leído.' }; }
    const s = T.socios.find(x => x.codigo_credencial === codigo);
    if (!s) { log(null, 'codigo_invalido', 'No pertenece a ningún socio', null); return { ok: false, motivo: 'El código no pertenece a ningún socio.' }; }
    const m = Repo.membresias.actual(s.id), dentro = Repo.asistencias.dentro(s.id), socio = Repo.socios.porId(s.id);
    if (dentro) { log(s.id, 'permitido', null, 'salida'); return { ok: true, tipo: 'SALIDA', socio, m, hora: ahoraISO(), minutos: Math.round((Date.now() - parseISO(dentro.entrada)) / 60000) }; }
    if (!m || m.estado !== 'activa') {
      const motivo = !m ? 'El socio no tiene membresía asignada.' : `Membresía ${m.estado} (vence ${fechaMx(m.fecha_fin)}).`;
      log(s.id, !m ? 'sin_membresia' : 'membresia_vencida', motivo, 'entrada'); return { ok: false, socio, m, motivo };
    }
    log(s.id, 'permitido', null, 'entrada');
    return { ok: true, tipo: 'ENTRADA', socio, m, hora: ahoraISO() };
  },
  visitas: (socioId, n = 999) => visitasDe(socioId).slice(0, n),
  dentro: socioId => { const v = visitasDe(socioId)[0]; return v && !v.salida ? v : null; },
  contarDesde: (socioId, dias) => { const lim = isoDate(addDays(hoy(), -dias)); return visitasDe(socioId).filter(v => v.entrada >= lim).length; },
  delDia: fecha => T.asistencias.filter(a => a.creado_en.startsWith(fecha)).sort((a, b) => b.creado_en.localeCompare(a.creado_en)).map(a => ({ ...a, socio: a.socio_id ? nombreDe(uno('socios', a.socio_id)) : '—', registro: a.registrado_por ? uno('usuarios', a.registrado_por).nombre : '—' })),
  recientes: n => T.asistencias.filter(a => a.resultado === 'permitido').sort((a, b) => b.creado_en.localeCompare(a.creado_en)).slice(0, n).map(a => ({ ...a, socio: nombreDe(uno('socios', a.socio_id)) })),
  kpisHoy() { const h = hoyISO(); return { dentro: T.socios.filter(s => Repo.asistencias.dentro(s.id) && Repo.asistencias.dentro(s.id).entrada >= h).length, entradas: T.asistencias.filter(a => a.resultado === 'permitido' && a.tipo_movimiento === 'entrada' && a.creado_en >= h).length, rechazos: T.asistencias.filter(a => a.resultado !== 'permitido' && a.creado_en >= h).length }; },
  afluenciaPorHora() { const h = {}; for (let i = 5; i <= 22; i++) h[i] = 0; const lim = isoDate(addDays(hoy(), -30)); T.asistencias.filter(a => a.tipo_movimiento === 'entrada' && a.resultado === 'permitido' && a.creado_en >= lim).forEach(a => { const x = parseISO(a.creado_en).getHours(); if (x in h) h[x]++; }); return h; },
};

Repo.equipos = {
  listar() {
    return T.equipos.filter(e => e.estado !== 'baja').map(e => ({ ...e, zona: e.ubicacion, disponibilidad: e.estado === 'mantenimiento' ? 'MANTENIMIENTO' : T.uso_equipos.some(u => u.equipo_id === e.id && !u.fin) ? 'OCUPADA' : 'LIBRE' }));
  },
  alternarUso(id, usuarioId = null) {
    const abierto = T.uso_equipos.find(u => u.equipo_id === +id && !u.fin);
    if (abierto) abierto.fin = ahoraISO(); else ins('uso_equipos', { equipo_id: +id, socio_id: null, inicio: ahoraISO(), fin: null, actividad: null, registrado_por: usuarioId });
    guardar();
  },
  simularMovimiento() { const ok = T.equipos.filter(e => e.estado === 'operativo'); Repo.equipos.alternarUso(ok[Math.floor(Math.random() * ok.length)].id); },
  cambiarEstado(id, estado, usuarioId) {
    const e = uno('equipos', id); e.estado = estado;
    if (estado === 'mantenimiento') T.uso_equipos.filter(u => u.equipo_id === e.id && !u.fin).forEach(u => u.fin = ahoraISO());
    bitacora('staff', usuarioId, 'equipo_' + estado, 'equipos', e.nombre); guardar();
  },
};

Repo.expedientes = {
  obtener: socioId => T.expedientes.find(e => e.socio_id === +socioId) || null,
  guardar(socioId, d, usuarioId = null) {
    let e = Repo.expedientes.obtener(socioId);
    if (!e) e = ins('expedientes', { socio_id: +socioId, creado_en: ahoraISO() });
    Object.assign(e, { objetivo_principal: d.objetivo, nivel: d.nivel, dias_entrenamiento: +d.dias, actualizado_por: usuarioId, actualizado_en: ahoraISO() });
    guardar(); return e;
  },
};
Repo.mediciones = {
  porSocio(socioId) { const e = Repo.expedientes.obtener(socioId); return e ? T.mediciones.filter(m => m.expediente_id === e.id).sort((a, b) => a.fecha_medicion.localeCompare(b.fecha_medicion)) : []; },
  registrar(socioId, d, usuarioId = null) {
    let e = Repo.expedientes.obtener(socioId); if (!e) e = ins('expedientes', { socio_id: +socioId, creado_en: ahoraISO() });
    const m = ins('mediciones', { expediente_id: e.id, fecha_medicion: ahoraISO(), peso_kg: +d.peso, estatura_cm: +d.estatura, imc: imc(+d.peso, +d.estatura), porcentaje_grasa: d.grasa === '' || d.grasa == null ? null : +d.grasa, porcentaje_musculo: d.musculo === '' || d.musculo == null ? null : +d.musculo, registrado_por: usuarioId, observaciones: null });
    guardar(); return m;
  },
};
Repo.rutinas = {
  asignada(socioId) {
    const rs = T.rutinas_socio.filter(x => x.socio_id === +socioId && x.estado === 'activa').sort((a, b) => b.fecha_inicio.localeCompare(a.fecha_inicio))[0];
    if (!rs) return null;
    const r = uno('rutinas', rs.rutina_id), i = rs.instructor_id ? uno('instructores', rs.instructor_id) : null, e = i ? uno('empleados', i.empleado_id) : null;
    const dias = {};
    T.rutina_ejercicios.filter(x => x.rutina_id === r.id).sort((a, b) => a.dia_numero - b.dia_numero || a.orden - b.orden).forEach(x => {
      (dias[x.dia_numero] = dias[x.dia_numero] || { dia_numero: x.dia_numero, enfoque: x.enfoque, ejercicios: [] }).ejercicios.push({ nombre: uno('ejercicios', x.ejercicio_id).nombre, series: x.series, repeticiones: x.repeticiones, descanso: x.descanso_segundos });
    });
    return { id: rs.id, nombre: r.nombre, objetivo: r.objetivo, desde: rs.fecha_inicio, coach: e ? `${e.nombre} ${e.apellido_paterno}` : 'Coach', dias: Object.values(dias) };
  },
  asignarPlan(socioId, plan, staff) {
    T.rutinas_socio.filter(x => x.socio_id === +socioId && x.estado === 'activa').forEach(x => { x.estado = 'finalizada'; x.fecha_fin = hoyISO(); });
    const r = ins('rutinas', { nombre: plan.nombre, objetivo: plan.objetivo, nivel: plan.nivel, dias_por_semana: plan.diasEntreno, creador_usuario_id: staff.usuario_id, es_plantilla: 0, activo: 1, creada_en: ahoraISO() });
    plan.semana.forEach((d, i) => d.ejercicios.forEach((x, o) => {
      let ej = T.ejercicios.find(e => e.nombre === x.nombre); if (!ej) ej = ins('ejercicios', { nombre: x.nombre, nivel: null, activo: 1 });
      ins('rutina_ejercicios', { rutina_id: r.id, ejercicio_id: ej.id, dia_numero: i + 1, enfoque: d.enfoque, orden: o + 1, series: x.series, repeticiones: x.reps, descanso_segundos: x.descanso });
    }));
    ins('rutinas_socio', { socio_id: +socioId, rutina_id: r.id, instructor_id: staff.instructor_id, fecha_inicio: hoyISO(), fecha_fin: null, estado: 'activa', asignada_en: ahoraISO() });
    bitacora('staff', staff.usuario_id, 'asignar_rutina', 'rutinas', String(socioId)); guardar();
  },
  finalizar(id) { const rs = uno('rutinas_socio', id); if (rs) { rs.estado = 'finalizada'; rs.fecha_fin = hoyISO(); guardar(); } },
};

function semilla() {
  T = { roles: [], puestos: [], empleados: [], instructores: [], usuarios: [], empleado_documentos: [], socios: [], socio_documentos: [], codigos_registro: [], verificaciones_correo: [], tipos_membresia: [], membresias: [], pagos: [], detalle_pagos: [], movimientos_contables: [], asistencias: [], equipos: [], uso_equipos: [], expedientes: [], mediciones: [], ejercicios: [], rutinas: [], rutina_ejercicios: [], rutinas_socio: [], bitacora: [], sesiones: [], intentos_codigo: [] };
  const now = ahoraISO(), H = hoy(), f = n => isoDate(addDays(H, n));
  ['dueno', 'administrador', 'recepcion', 'instructor', 'socio'].forEach(n => ins('roles', { nombre: n, activo: 1 }));
  [['dueno', 'Dueño'], ['administrador', 'Administrador'], ['recepcion', 'Recepcionista'], ['instructor', 'Coach']].forEach(([c, n]) => ins('puestos', { clave: c, nombre: n, activo: 1 }));
  const staff = [
    ['dueno', 'DUE-0001', 'ROBERTO', 'MÉNDEZ', 'SALAS', 'dueno@fitcode.mx', 'MESR800101', 'Dueno#2026'],
    ['administrador', 'ADM-0001', 'LAURA', 'GÓMEZ', 'TREJO', 'admin@fitcode.mx', 'GOTL900215', 'Admin#2026'],
    ['recepcion', 'REC-0001', 'DIANA', 'CRUZ', 'VEGA', 'recepcion@fitcode.mx', 'CUVD980712', 'Recep#2026'],
    ['instructor', 'COA-0001', 'CARLOS', 'RUIZ', 'ORTEGA', 'coach@fitcode.mx', 'RUOC920304', 'Coach#2026'],
  ];
  staff.forEach(([rol, num, n, ap, am, mail, rfc, pw]) => {
    const e = ins('empleados', { numero_empleado: num, puesto_id: T.puestos.find(p => p.clave === rol).id, nombre: n, apellido_paterno: ap, apellido_materno: am, apellidos: `${ap} ${am}`, email: mail, telefono: '5550000000', rfc, fecha_nacimiento: null, telefono_emergencia: null, servicio_medico: null, enfermedad_cronica: null, enfermedad_otra: null, fecha_ingreso: '2025-01-15', estado: 'activo', creado_en: now });
    ins('usuarios', { nombre: `${n} ${ap} ${am}`, email: mail, password_hash: hashPw(pw), rol_id: T.roles.find(r => r.nombre === rol).id, empleado_id: e.id, activo: 1, intentos_fallidos: 0, bloqueado_hasta: null, ultimo_acceso: null, email_verificado_en: now, creado_en: now });
    if (rol === 'instructor') ins('instructores', { empleado_id: e.id, especialidad: 'Hipertrofia y fuerza', activo: 1 });
  });
  [['Visita', 1, 80, 'Acceso por un día.', 'Acceso a piso de pesas\nRegaderas'],
   ['Mensual', 30, 549, 'El plan base para entrenar todo el mes.', 'Acceso ilimitado\nEvaluación inicial\nApp FIT CODE'],
   ['Trimestral', 90, 1499, 'Tres meses con precio preferente.', 'Todo lo del Mensual\n1 rutina personalizada\nMedición mensual'],
   ['Anual', 365, 5490, 'Doce meses al mejor precio.', 'Todo lo del Trimestral\nClases grupales\nCasillero fijo\n2 pases de invitado al mes'],
   ['Estudiante', 30, 399, 'Mensual con credencial vigente.', 'Acceso L–V 6:00–16:00\nApp FIT CODE']]
    .forEach(p => ins('tipos_membresia', { nombre: p[0], duracion_dias: p[1], precio: p[2], descripcion: p[3], beneficios_descripcion: p[4], activo: 1 }));
  const pwS = hashPw('Socio#2026');
  [['ANAPP-150398', 'ana@demo.mx', '5512345678', 'mayor', 'ANA', 'PÉREZ', 'PÉREZ', '1998-03-15', 'FEMENINO', 'MUJER', 'IMSS', 'NINGUNA', null, '2026-03-01'],
   ['LUISRM-020901', 'luis@demo.mx', '5587654321', 'mayor', 'LUIS', 'RAMÍREZ', 'MORA', '2001-09-02', 'MASCULINO', 'HOMBRE', 'ISSSTE', 'ASMA', null, '2026-06-10'],
   ['SOFIAHL-110510', 'sofia@demo.mx', '5511122233', 'menor', 'SOFÍA', 'HERNÁNDEZ', 'LUNA', '2010-05-11', 'FEMENINO', 'MUJER', 'IMSS', 'NINGUNA', 'MARTHA LUNA RÍOS', '2026-08-20']]
    .forEach(s => { const r = ins('socios', { codigo_credencial: null, usuario: s[0], email: s[1], telefono: s[2], tel_contacto: s[2], tipo_socio: s[3], nombre: s[4], apellido_paterno: s[5], apellido_materno: s[6], apellidos: `${s[5]} ${s[6]}`, fecha_nacimiento: s[7], genero: s[8], sexo: s[9], servicio_medico: s[10], enfermedad_cronica: s[11], enfermedad_otra: null, tutor_nombre: s[12], contacto_emergencia: s[12], telefono_emergencia: '5500000000', password_hash: pwS, email_verificado_en: now, intentos_fallidos: 0, bloqueado_hasta: null, activo: 1, creado_en: s[13] + ' 10:00:00' }); r.codigo_credencial = generarCodigoBarras(r.id, s[13]); ins('expedientes', { socio_id: r.id, objetivo_principal: null, nivel: null, dias_entrenamiento: null, creado_en: now, actualizado_en: now }); });
  const pago = (sid, tipo, ini, metodo, usr) => {
    const p = uno('tipos_membresia', tipo), fin = isoDate(addDays(parseISO(ini), p.duracion_dias - 1));
    const m = ins('membresias', { socio_id: sid, tipo_membresia_id: tipo, fecha_inicio: ini, fecha_fin: fin, estado: fin < hoyISO() ? 'vencida' : 'activa', precio_aplicado: p.precio, creado_en: ini + ' 09:30:00' });
    const pg = ins('pagos', { folio: 'R' + ini.slice(2).replace(/-/g, '') + (0xA1B2C0 + sid * 7 + tipo).toString(16).toUpperCase(), socio_id: sid, membresia_id: m.id, tipo_membresia_id: tipo, concepto: 'Membresía ' + p.nombre, monto: p.precio, metodo, usuario_id: usr, estado: 'pagado', referencia_externa: null, referencia_pago: null, expira_en: null, tarjeta_marca: metodo === 'tarjeta' ? 'VISA' : null, tarjeta_ultimos4: metodo === 'tarjeta' ? '4242' : null, creado_en: ini + ' 09:30:00', pagado_en: ini + ' 09:30:00' });
    ins('detalle_pagos', { pago_id: pg.id, descripcion: pg.concepto, cantidad: 1, precio_unitario: p.precio, descuento: 0, subtotal: p.precio });
  };
  pago(1, 2, f(-90), 'efectivo', 3); pago(1, 3, f(-60), 'tarjeta', 3); pago(2, 2, f(-26), 'efectivo', 3); pago(3, 5, f(-40), 'transferencia', 3);
  [[1, 18], [2, 9], [3, 4]].forEach(([sid, n]) => {
    const cod = uno('socios', sid).codigo_credencial;
    for (let i = n; i >= 1; i--) {
      const e = addDays(H, -(i * 2 - (sid % 2))); e.setHours(6 + ((i * 3 + sid) % 12), (i * 7) % 60, 0);
      const s = new Date(e.getTime() + (55 + (i * 11) % 50) * 60000);
      ins('asistencias', { socio_id: sid, codigo_leido: cod, resultado: 'permitido', motivo: null, tipo_movimiento: 'entrada', registrado_por: 3, creado_en: isoDateTime(e) });
      ins('asistencias', { socio_id: sid, codigo_leido: cod, resultado: 'permitido', motivo: null, tipo_movimiento: 'salida', registrado_por: 3, creado_en: isoDateTime(s) });
    }
  });
  [['Caminadora 01', 'Cardio', 1], ['Caminadora 02', 'Cardio', 0], ['Caminadora 03', 'Cardio', 0], ['Elíptica 01', 'Cardio', 1], ['Bicicleta fija 01', 'Cardio', 0], ['Remo 01', 'Cardio', 2],
   ['Rack de sentadilla 01', 'Pesas libres', 1], ['Rack de sentadilla 02', 'Pesas libres', 0], ['Banco plano 01', 'Pesas libres', 0], ['Banco inclinado 01', 'Pesas libres', 1],
   ['Prensa de pierna', 'Máquinas', 0], ['Polea alta', 'Máquinas', 1], ['Extensión de pierna', 'Máquinas', 0], ['Smith', 'Máquinas', 0], ['Peck deck', 'Máquinas', 0], ['Remo sentado', 'Máquinas', 1]]
    .forEach(([n, z, st]) => { const e = ins('equipos', { nombre: n, ubicacion: z, estado: st === 2 ? 'mantenimiento' : 'operativo', marca: null, numero_serie: null }); if (st === 1) ins('uso_equipos', { equipo_id: e.id, socio_id: null, inicio: now, fin: null, registrado_por: 3 }); });
  Object.assign(T.expedientes[0], { objetivo_principal: 'recomposicion', nivel: 'intermedio', dias_entrenamiento: 4, actualizado_por: 4 });
  [[-60, 70.1, 25.4, 30.1], [-30, 68.5, 24.1, 30.9], [-3, 67.2, 23.0, 31.6]].forEach(([d, p, g, mu]) => ins('mediciones', { expediente_id: 1, fecha_medicion: f(d) + ' 08:00:00', peso_kg: p, estatura_cm: 165, imc: imc(p, 165), porcentaje_grasa: g, porcentaje_musculo: mu, registrado_por: 4 }));
  const coach = { usuario_id: 4, instructor_id: 1 };
  Repo.rutinas.asignarPlan(1, generarPlan({ objetivo: 'recomposicion', nivel: 'intermedio', dias: 4, edad: 28, sexo: 'MUJER', peso: 67.2, estatura: 165 }), coach);
  T.rutinas_socio[0].fecha_inicio = f(-14);
  [['482915', 3, -1], ['731004', 3, -2]].forEach(([c, u, d]) => ins('codigos_registro', { codigo: c, generado_por: u, usado_por_socio_id: null, creado_en: f(d) + ' 12:00:00', expira_en: f(d + 3) + ' 12:00:00', usado_en: null }));
  T.bitacora = [];
  return T;
}
