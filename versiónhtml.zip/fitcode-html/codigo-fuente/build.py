import os
D = os.path.dirname(os.path.abspath(__file__))
css = open(os.path.join(D, 'assets', 'css', 'style.css')).read() + open(os.path.join(D, 'extra.css')).read()
orden = ['core.js', 'fitness.js', 'repo.js', 'pages_auth.js', 'pages_portal.js', 'pages_staff.js']
js = '\n'.join(open(os.path.join(D, f)).read() for f in orden)
html = f'''<!doctype html>
<html lang="es-MX">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#08090b">
<title>FIT CODE</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;500;800&family=Space+Grotesk:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><rect width='24' height='24' rx='6' fill='%23c8ff2e'/><path d='M13 3 5 14h6l-1 7 8-11h-6z' fill='%2308090b'/></svg>">
<style>
{css}
</style>
</head>
<body>
<div class="bg-grid" aria-hidden="true"></div>
<div id="app"></div>
<noscript><p style="padding:40px;color:#fff">Activa JavaScript para usar FIT CODE.</p></noscript>
<script>
{js}
</script>
</body>
</html>
'''
out = os.path.join(D, '..', 'FIT-CODE.html')
open(out, 'w').write(html)
print(os.path.abspath(out), len(html))
